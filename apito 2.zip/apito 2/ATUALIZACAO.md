# Grande atualização: Etapas 1 a 8 (ver ENTREGA.md)

## Como rodar
    npm install
    npm run dev
    npm test

## O que há nesta versão
Etapa 5 (notícias, e-mails e rede social), progressão, objetivos, calendário, durações configuráveis, VAR em partida e, novo nesta entrega, a conclusão da Etapa 6:
- VAR com histórico auditável (decisão inicial, final e motivo) que chega à carreira, às notícias, e-mails, publicações e estatísticas.
- Pressão do jogo (clássicos, finais, última rodada, prestígio, jogo anterior polêmico, imprensa crítica), mostrada nas convocações. Não altera nota nem recompensas.
- Eventos da carreira (aba Eventos): jogo de pressão, revisão técnica, reconhecimento, críticas públicas e convocação especial.

## Durações
Rápida: 2 a 3 min · Padrão: 4 a 5 min · Longa: 6 a 7 min (o prompt mestre sugere 4 opções; mantive as 3 já implementadas e testadas).

## VAR
Tecla R ou botão `VAR [R]`. É possível rever um lance, manter a decisão ou corrigi-la.

## Etapa 7
- Prêmios de temporada (aba Prêmios): Revelação, Avaliação Técnica, Destaque Regional, Eliminatórias e Árbitro da Temporada, por critérios verificáveis, +40 XP uma vez.
- Novo objetivo de carreira: usar o VAR e acertar a decisão final em 3 lances típicos.
- Salvamento versão 7 (migração segura). Durações das partidas não foram alteradas.
