# Apito do Jogo: arquitetura e auditoria (Etapa 1)

Documento escrito a partir do código do `apito.zip` recebido e atualizado nesta etapa. Serve de mapa para as próximas etapas.

## 1. Estrutura

```
index.html            título "Apito"; carrega src/main.js
src/main.js           configuração do Phaser (320x180, escala FIT, física Arcade) e lista de cenas
src/config.js         campo, equipes, durações das partidas, lista de eventos do jogo
src/scenes/           BootScene, MenuScene (HTML), MatchScene (Phaser), ResultScene (HTML)
src/entities/         Character (base), Player, Referee, Ball
src/systems/          MatchSimulation, PlayerAI, MatchRules, RefereeDecisionSystem,
                      RefereeGrading, CareerSystem, Controls
src/ui/               HUD, Effects, DecisionPanel (HTML)
src/data/             competitions, formations, names, referees (novo)
src/utils/            pixelTextures, audio, storage, rng, labels
tests/                testes automáticos (npm test)
```

Fluxo de cenas: `BootScene -> MenuScene -> MatchScene -> ResultScene -> MenuScene`.

## 2. Fases de gameplay: estado real no código recebido

| Fase | O que é | Onde está | Estado |
|---|---|---|---|
| 1 | Projeto e campo | `MatchScene.drawField`, `config.js` | completa |
| 2 | Árbitro e câmera | `Character`, `Referee`, `Controls`, `MatchScene` | completa |
| 3 | Jogadores, bola, IA | `Player`, `Ball`, `PlayerAI`, `MatchSimulation` | completa |
| 4 | Faltas, apito, cartões, painel | `MatchRules`, `RefereeDecisionSystem`, `DecisionPanel` | completa |
| 5 | Placar, relógio, gols, bola fora, tempos | `MatchSimulation`, `HUD`, `ResultScene` | completa |
| 6 | Nota do árbitro | `RefereeGrading`, `ResultScene` | completa |
| 7 | Menu e carreira | `MenuScene`, `CareerSystem`, `storage` | completa |
| 8 | Melhorias gráficas, áudio, novas regras | `pixelTextures` (poses), `Character.setPose`, `MatchScene.drawStands`, `Ball` (rastro), `utils/audio`, `Effects`, `PlayerAI.offsideInfo`, `MatchSimulation` | completa (concluída depois do `apito.zip` recebido, que só tinha o nome e o "Como jogar") |

## 3. Controles (inalterados)

WASD/setas mover, Espaço apitar, V vantagem (falta leve), N liga/desliga o som, Esc pausar, M (na pausa) menu, F2 debug. No painel: 1 amarelo, 2 vermelho (no autor), F marcar falta, I ignorar. Na tela de resultado: 1 a 4 trocam de aba, Espaço ou R continuam, M menu.

## 4. Regras de arbitragem

Lances gerados por `MatchSimulation` (`incident`), classificados em `MatchRules` e avaliados contra a decisão do jogador (`evaluateDecision`). Tipos: disputa legal, falta leve, falta pesada, pênalti, simulação, impedimento e posição legal.

Gravidade da falta = número de agravantes (entrada por trás, alta velocidade, entrada imprudente):

| Agravantes | Gravidade | Cartão |
|---|---|---|
| 0 ou 1 | falta leve | nenhum (advertência verbal aceita; vantagem permitida) |
| 2 | falta pesada | amarelo |
| 3 | força excessiva | vermelho |

**Mudança desta etapa:** antes, a gravidade vinha de uma pontuação contínua e as evidências eram só pistas (uma falta "por trás" era leve em 97% das vezes). Agora a regra é a contagem acima, igual à explicada no "Como jogar". Teste automático: `tests/sim.test.mjs`.

### Impedimento (Fase 8)

No momento de cada passe em jogo corrido ou tiro livre, `PlayerAI.offsideInfo` lista os atacantes em posição de impedimento (metade adversária, à frente da bola e do penúltimo defensor; o goleiro conta) e os que estão "no limite" (legais, até 7 px atrás da linha). A infração só existe se um deles for o próximo a tocar na bola (`MatchSimulation.checkOffsideTouch`). Impedimento marcado dá tiro livre indireto ao adversário, sem cartão. Não vale em lateral, escanteio, tiro de meta, pênalti nem saída de bola. Marcar impedimento numa posição legal é erro. Em 20 partidas de teste: cerca de 1,3 impedimentos e 1,2 posições legais por partida.

### Visual e áudio (Fase 8)

Poses por código: chute, comemoração (time que marca), reclamação (jogadores perto de uma decisão) e sinal do árbitro (apito e cartões). Arquibancadas com torcida nas cores dos clubes, placas de publicidade, rastro da bola rápida e tremor de câmera no gol. Áudio sintetizado (Web Audio, sem arquivos): apito longo, curto e triplo, chute, gol, cartão e torcida de fundo que reage aos lances. Tecla N liga e desliga o som (preferência salva).

## 5. Eventos (`CUSTOM_EVENTS` em `config.js`)

`incident`, `incident-registered`, `whistle`, `decision-needed`, `card`, `advantage`, `decision-result`, `feedback`, `player-touch`, `referee-bump` (sem uso), `play-stopped`, `play-resumed`, `setpiece-start`, `player-sent-off`, `goal`, `halftime`, `fulltime`. São removidos ao sair da partida para não acumular ao reiniciar.

## 6. Fim de partida (fonte única de verdade)

`MatchScene.finishMatch` envia `{ mode, fixture, score, stats, cards, log }` à `ResultScene`. O `log` (um registro por lance, vindo de `RefereeDecisionSystem`) é a única fonte da nota (`gradeMatch`). A `ResultScene` aplica o resultado à carreira com `applyMatch`, que agora é **idempotente** (`matchId`): o mesmo jogo nunca soma experiência, reputação ou histórico duas vezes.

## 7. Persistência

| Chave (localStorage) | Conteúdo |
|---|---|
| `refwhistle:career:v1` | carreira (formato versão 2; a chave antiga foi mantida) |
| `refwhistle:career:backup` | cópia da carreira original, criada na primeira migração |
| `refwhistle:career:previous` | cópia da carreira antes de ser substituída ou apagada |
| `apitodojogo:settings` | preferências (duração das partidas) |

Carreira versão 5: `version, name, profile{name, look, region}, seed, xp, rep, totalMatches, unlocked[], season{}, history[], processed[], skipped, champions[], division, strikes, restricted, seasons[], objectives[], inbox[], news[], social[], comms{seq}, world{season, week, competitions{}, offers{week, items[], restriction}}` (e `invitations[]`, campo legado das versões anteriores). As versões 1 a 4 são migradas automaticamente em cadeia (campos antigos preservados, padrões para os novos, backup antes); na migração para a 3, o calendário é montado a partir do progresso da temporada e as semanas anteriores são simuladas. Dados ilegíveis nunca são apagados: o menu avisa e a carreira fica intacta.

## 8. Pontos de integração para as próximas etapas

- Calendário e convocações: **feitos na Etapa 3** (seção 10).
- Novas competições: `data/competitions.js` (estrutura de dados, sem lógica). Faltam a Supercopa e a Liga Continental.
- Notícias, e-mails e rede social: gerados a partir de `result.log` e do registro de partida em `applyMatch`.
- VAR: ponto natural em `RefereeDecisionSystem.resolveDecision` (decisão inicial) antes de `finalize`.
- Tabelas: **feitas na Etapa 3**; os jogos que o jogador não apita são simulados com a semente da carreira.

## 9. Testes

`npm test` roda 66 testes: regras de gravidade, avaliação de decisões, perfil e migração da carreira, idempotência, convocações, calendário e tabelas, copas, progressão (promoção, rebaixamento, reputação, suspensão, objetivos), notícias, e-mails e rede social, impedimento, partidas completas (várias sementes e durações), reprodutibilidade da nota. Não cobrem a interface (HTML/Phaser), que precisa de teste manual.

## 10. Etapa 3: central da carreira, calendário e competições

**Competições** (`data/competitions.js`, só dados): 6 ligas em pontos corridos, turno único, as mesmas de antes (Várzea até Continental, que formam a escada de divisões), mais 6 copas em mata-mata: Copa Nacional (8 clubes sorteados das ligas a cada temporada, quartas, semifinais e final) e as copas Norte, Nordeste, Centro-Oeste, Sudeste e Sul (4 clubes cada, semifinais e final). Cada competição declara `format`, `stages`, `importance` e a reputação para liberar. Copas não contam como divisão (`division: false`). Competições regionais exigem 15 de reputação a mais de quem é de outra região: a região influencia a oportunidade, mas nunca bloqueia a progressão.

**Calendário** (`systems/CalendarSystem.js`, funções puras): a temporada tem 5 rodadas (uma por semana; eram 6 jogos antes). Cada jogo tem `id`, rodada, competição, fase, mandante, visitante, estádio fictício, importância, `status` e resultado. As ligas usam o método do círculo; as copas criam a fase seguinte quando a anterior termina, e empates vão aos pênaltis (sorteados com a semente). Tudo vem da semente da carreira: o calendário não muda ao recarregar.

**Convocações:** a cada rodada o árbitro recebe até 3 jogos das competições liberadas (um seguro, um intermediário e um importante). Aceitar inicia a partida; recusar não custa nada; "Passar a rodada sem apitar" simula todos os jogos e não custa experiência nem reputação. Um jogo concluído ou recusado não pode ser iniciado de novo (`startableFixture`), e o resultado de uma partida só conta uma vez (`matchId`).

**Fluxo de uma rodada (`CareerSystem.applyMatch`):** registra o resultado real no jogo do calendário, fecha as convocações da semana, simula os demais jogos da rodada, atualiza as copas e avança a semana. Ao fim da quinta rodada: objetivos, bônus de reputação (só com 3 jogos apitados ou mais), campeões da temporada (`career.champions`), novas competições liberadas e novo calendário.

**Interface (`MenuScene`):** central com navegação lateral (Visão geral, Convocações, Calendário, Classificação, Estatísticas, Objetivos, Histórico, Competições), indicadores de convocações abertas e objetivos concluídos, detalhes de cada jogo, tabelas de liga e chaves de copa. Notícias, e-mails e rede social ficam para a Etapa 5, e prêmios para a Etapa 7 (sem botões vazios até lá).

## 11. Etapa 4: progressão e avaliação

**Três atributos, três funções** (`systems/ProgressionSystem.js`, funções puras):
- **Avaliação técnica**: a nota da partida (`RefereeGrading`). É a mesma da tela de resultado e a carreira nunca a altera nem cria uma pontuação paralela.
- **Experiência (XP)**: prática acumulada; define nível e título. Nunca diminui.
- **Reputação (0 a 100)**: confiança do comitê. Nota acima de 6,0 sobe e abaixo desce, multiplicada pela importância do jogo, com teto por partida (+5 / -5). Cada erro grave (gravidade 3 ou mais na lista de erros da partida) desconta 0,5, até 3. Libera as copas e é um requisito de promoção. Uma partida ruim isolada não apaga a progressão.

**Divisão** (`career.division`, índice na escada de ligas): muda só por promoção ou rebaixamento. As ligas passaram a ser liberadas pela divisão (antes, pela reputação); as copas continuam liberadas por reputação.

**Promoção** no fim da temporada, só se **todos** os requisitos forem atendidos: reputação mínima da divisão seguinte (15, 35, 55, 75, 90), média da temporada igual ou acima da meta (6,0 na Várzea, +0,4 por divisão), pelo menos 3 jogos apitados, no máximo 3 erros graves e pelo menos 2 dos 4 objetivos da temporada. Dá 100 XP. O jogador vê cada requisito (✓ ou ✗, com o valor) durante a temporada (aba Objetivos) e o motivo no fim.

**Rebaixamento**: só após 2 temporadas seguidas com média abaixo de 5,0 (a primeira gera aviso; média de 6,0 ou mais zera os avisos). Perde uma divisão e 5 de reputação, nunca abaixo da divisão mais baixa. Temporada sem 3 jogos apitados não gera aviso.

**Suspensão de oportunidades**: com 4 ou mais erros graves numa partida, ou duas notas abaixo de 4,0 seguidas, a próxima rodada só oferece jogos de importância 1. Dura uma rodada, o motivo aparece na tela e a progressão não é afetada.

**Objetivos de carreira** (8, definidos em `ProgressionSystem`): só o estado é salvo; o progresso é calculado a partir do histórico. A recompensa (XP ou reputação) é entregue uma única vez. "Concluir uma temporada" exige 3 jogos apitados (passar todas as rodadas não vale). Na migração, objetivos já cumpridos são marcados sem recompensa.

**Registros**: cada partida guarda erros graves e competição; cada temporada concluída guarda divisão, média, jogos, erros graves, objetivos, bônus e a decisão (promoção, aviso, rebaixamento ou mantido) com o motivo. As estatísticas (aba Estatísticas) saem desses registros.

**Idempotência**: o resultado de uma partida (matchId) e a recompensa de cada objetivo só contam uma vez.

## 12. Etapa 5: notícias, e-mails e rede social

**Fonte única dos fatos** (`RefereeGrading.matchFacts`): a partir do registro de decisões da partida, conta cartões, pênaltis marcados e não marcados, faltas indevidas, impedimentos, simulações e vantagens. Os mesmos números alimentam as estatísticas da carreira e todo o conteúdo de comunicação. Notícia, e-mail e publicação não calculam nem alteram a nota.

**Geração** (`systems/CommsSystem.js`, funções puras e determinísticas pela semente da carreira e pelo `matchId`):
- **Notícias** (categorias arbitragem, lance, resultado, carreira, competição): tom positivo (nota 7,5 ou mais sem erro grave), negativo (nota abaixo de 5 ou 2 erros graves ou mais) ou neutro. Notícias de lance só existem se o fato ocorreu (no máximo 2 por partida). Manchetes e variantes não se repetem em sequência. Cada notícia guarda data, competição, jogo de origem e fonte fictícia.
- **E-mails** (avaliação, convocação, objetivo, disciplinar, convite, reconhecimento, promoção, comunicado): relatório da supervisão após cada jogo (nota, pontos fortes e fracos, principal erro e acerto), escala semanal com as convocações, objetivo concluído, suspensão com o motivo, convite ao liberar uma competição, decisão do comitê no fim da temporada. Cada mensagem tem id, remetente, assunto, texto, data, categoria e situação de leitura.
- **Rede social** (clube, jornalista, comentarista, torcedor, perfil oficial): cada publicação tem etiqueta (dado oficial, comunicado do clube, análise ou opinião). Só "dado oficial" e "análise" citam a avaliação técnica; opiniões de torcedores e comentaristas são marcadas e podem reclamar mesmo sem erro nenhum, para deixar claro que reclamação não prova erro técnico.

**Convocações por e-mail:** o e-mail da rodada é atualizado no lugar quando as ofertas mudam (por exemplo, numa suspensão). Os botões Aceitar e Recusar usam o estado real das convocações (`world.offers`), então aceitar ou recusar pela aba ou pelo e-mail é a mesma operação e não pode ser feita duas vezes. Recusar não custa nada. Mensagens de rodadas antigas aparecem como "Rodada encerrada".

**Idempotência e persistência:** cada item tem uma chave (por partida, temporada, objetivo ou rodada) e itens com a mesma chave nunca entram duas vezes; reprocessar um jogo (`matchId`) não gera nada. Limites: 60 notícias, 80 e-mails, 120 publicações (as mais antigas saem). Tudo é salvo com a carreira. Uma carreira com 60 jogos ocupa cerca de 150 KB.

**Imagem pública:** tom das últimas 5 notícias sobre a arbitragem (positiva, neutra ou crítica). É só narrativa: não afeta nota, reputação nem progressão. Os gatilhos de pressão e rivalidade ficam para a Etapa 6.

**Interface:** abas Notícias (filtro por tom), E-mails (lista, leitura, marcar lida ou não lida, marcar todas, ações de convocação, indicador de não lidas) e Rede social (filtro por etiqueta). A tela de resultado informa quantas mensagens novas chegaram.


## VAR
O VAR grava o estado da partida em `VarRecorder`/`VarSystem`, reproduz os quadros por `VarReplay` e apresenta a revisão em `VarPanel`. A abertura congela a simulação; uma correção restaura o estado do lance, reaplica a decisão escolhida e emite eventos para atualizar efeitos, cartões, placar e jogadores. O histórico de comunicação da Etapa 5 continua sendo alimentado pela carreira normalmente.

## 13. Etapa 6 (conclusão): VAR na carreira, pressão, rivalidades e eventos

**Onde o projeto estava:** Etapas 1 a 5, durações configuráveis e o VAR em partida (gravação, reprodução, painel, correção com restauração do estado) já existiam, com 83 testes. Faltavam: o VAR chegar à carreira (histórico auditável, notícias, e-mails, publicações, estatísticas) e o sistema de pressão, rivalidades e eventos especiais.

**VAR auditável** (`VarSystem.audit`): cada revisão concluída (decisão mantida ou alterada) vira uma linha com id, lance, relógio, se era um lance típico de VAR (`isVarEligible`: pênalti, impedimento ou vermelho), decisão inicial, decisão final e motivo. A decisão inicial é copiada antes de a correção ser reaplicada. Ao fim da partida, `MatchScene` envia `varReviews` com o desfecho real de cada lance (`finalCorrect`, vindo da súmula, a mesma fonte da nota). `RefereeGrading.varFacts` conta revisões, mantidas, alteradas, em lances elegíveis, corrigidas (alteradas e certas) e pioradas (alteradas e ainda erradas). Esses fatos entram em `extras` do resultado e no registro da partida (`history[].var`, com no máximo 8 linhas de auditoria). O VAR não recalcula nem altera a nota: ela continua vindo só da súmula de decisões.

**Comunicação sobre o VAR** (`CommsSystem`): só existe se houve revisão. Notícia da categoria `lance` (não entra na imagem pública), com tom positivo (correção confirmada), negativo (alteração que ainda aparece como erro) ou neutro (mantida, ou alterada sem desfecho conhecido); linha "VAR" no relatório da supervisão; publicação de dado oficial e debate de comentarista (opinião).

**Pressão** (`systems/ContextSystem.js`, funções puras): `matchContext` soma fatores explícitos, nível 0 a 3 (Normal, Atenção, Alta, Máxima): rivalidade (12 clássicos fictícios, `RIVALRIES`), final (peso 2) ou semifinal, competição de prestígio, última rodada da temporada, última partida com 2 ou mais erros graves ou nota abaixo de 5, e imagem pública crítica. **A pressão não altera nota, XP, reputação nem a quantidade ou dificuldade dos lances**: ela é mostrada nas convocações e alimenta eventos narrativos. A dificuldade real continua vindo da importância da partida (Etapa 3). O contexto é calculado antes de a partida entrar no histórico e salvo em `history[].context`.

**Eventos da carreira** (`career.events`, até 40, chave única por evento, nunca duplicados):
| Evento | Gatilho | Efeito |
|---|---|---|
| Jogo de pressão | nível 2 ou mais | registro, notícia (tom pela nota e erros graves) e publicação |
| Revisão técnica | 2 ou mais erros graves reais | e-mail do comitê citando os lances; resultado e nota não mudam |
| Reconhecimento | nota 9 ou mais | registro (o e-mail de reconhecimento já existia) |
| Críticas públicas | imagem pública "Crítica", no máximo a cada 3 partidas | e-mail da assessoria; só narrativa |
| Convocação especial | convocação da semana é final, semifinal, clássico ou última rodada | registro e e-mail, uma vez por jogo |

Nenhum evento custa reputação, XP ou nota. Reprocessar uma partida (`matchId`) ou reabrir a semana não gera nada novo.

**Interface:** aba Eventos na central; linha "Pressão" nas convocações (cores por nível); VAR e pressão no histórico; novas linhas na aba Estatísticas (revisões, alterações, revisões em lances elegíveis, jogos de pressão alta); lista de revisões do VAR com decisão inicial, final e motivo na aba Decisões do resultado; pressão e eventos na aba Carreira do resultado.

**Persistência:** `CAREER_VERSION` 6. A migração 5 para 6 só cria `events: []` (nada é inventado sobre partidas passadas), com backup como nas outras migrações.

**Testes:** `tests/context.test.mjs` (15 testes): rivalidades, níveis de pressão, recompensas inalteradas, eventos e idempotência, críticas, convocações especiais, migração, fatos e comunicação do VAR e auditoria em partida simulada. Total: 98 testes.

**Ainda não feito (Etapas 7 e 8):** prêmios de temporada, Supercopa e Liga Continental, objetivo de "usar o VAR corretamente", eventos de mudança de escala e de oportunidade de competição superior (hoje coberta pelo e-mail de convite ao liberar uma competição), refinamento final e regressão manual completa.

## 14. Etapa 7: prêmios de temporada, objetivo do VAR e acabamento

**Prêmios** (`systems/AwardsSystem.js`, funções puras): Árbitro Revelação, Melhor Avaliação Técnica, Destaque Regional, Destaque em Competições Eliminatórias e Árbitro da Temporada. Cada um tem critérios verificáveis calculados só com os registros das partidas da temporada (nota, erros graves e competição), sem sorteio: Revelação (1ª ou 2ª temporada, 3 jogos ou mais, média 6,5 ou mais, no máximo 1 erro grave; único na carreira), Avaliação Técnica (3 jogos ou mais, média 8,0 ou mais), Regional (2 jogos de copas regionais, média 7,0 ou mais neles), Eliminatórias (2 jogos de copas, média 7,0 ou mais neles) e Árbitro da Temporada (4 jogos ou mais, média 7,5 ou mais, nenhum erro grave). Recompensa: +40 XP uma única vez (chave `prêmio:sTemporada` em `career.awards`).

**Fluxo:** `closeSeason` chama `grantAwards` antes de publicar a comunicação da temporada. Os prêmios conquistados entram em `summary.seasonEnded.awards` e geram notícia, e-mail de reconhecimento e publicação oficial (chaves únicas). Passar a rodada sem apitar não gera prêmio. Reprocessar nunca duplica prêmio nem XP.

**Interface:** aba Prêmios (conquistados, critérios da temporada atual com valores reais e indicador de novos prêmios) e bloco "Prêmios de temporada" no fim da temporada.

**Objetivo de carreira do VAR** (`id: 'var'`): usar o VAR e terminar com a decisão final correta em 3 lances típicos (pênalti, vermelho ou impedimento), medido a partir da auditoria dos registros das partidas. Recompensa: +80 XP, uma vez. Agora são 9 objetivos de carreira.

**Persistência:** `CAREER_VERSION` 7. A migração 6 para 7 só cria `awards: []` (nada é concedido retroativamente).

**Durações:** não foram alteradas. Continuam as 3 opções (Rápida, Padrão, Longa); `src/config.js` e `tests/duration.test.mjs` são idênticos aos da versão anterior.

**Testes:** `tests/awards.test.mjs` (13 testes). Total: 111 testes, todos aprovados.

**Limitações conhecidas:** a Supercopa e a Liga Continental não foram adicionadas (a Etapa 7 pede só integrar as ligas já habilitadas); mudança de escala e oportunidade de competição superior continuam sem evento próprio. A Etapa 8 (regressão manual completa) ainda não foi feita.

## 15. Anulação de gol (falta ou impedimento no lance do gol)

**Pedido:** todo gol que vem de falta ou impedimento deve poder ser anulado, com ou sem VAR, sem alterar o VAR.

**Como funciona (sem VAR):**
- Quando sai o gol, `RefereeDecisionSystem.onGoal` procura a *causa*: uma falta (leve, grave ou na área) ou um impedimento **da equipe que marcou**, que não foi apitado, ocorrido no jogo corrido atual e nos últimos 8 s (`GOAL_CAUSE_WINDOW_MS`). Disputa legal, posição legal e simulação nunca são causa, nem infração da equipe que sofreu o gol (isso é vantagem natural).
- A pausa depois do gol passa de 2,8 s para 4,2 s (`GOAL_CHECK_S`) e o HUD mostra "GOL! Espaço anula o gol". O prompt é o mesmo com ou sem causa, então não entrega a resposta.
- **Espaço** (apito), **F** (falta) ou **G** chamam `annulGoal()` (a `MatchScene` direciona essas teclas para a anulação só durante a pausa do gol; fora dela o apito é o de sempre) → `MatchSimulation.disallowGoal`: o placar volta, o banner mostra "GOL ANULADO" e o jogo recomeça com tiro livre (indireto se foi impedimento) para a equipe prejudicada, no local da infração. Sem infração (gol válido anulado por engano), recomeça com tiro de meta.
- Se nada for apertado, o gol vale.

**Nota (decisão registrada na súmula, tipo `goal_check`):**
- Só entra na súmula quando há infração real ou quando o árbitro anula: gol limpo confirmado não gera registro, para não inflar a nota com acertos fáceis.
- Anular gol com infração real: acerto ("Gol irregular anulado corretamente").
- Confirmar gol com infração real: "gol irregular validado" (erro grave, peso 1,5).
- Anular gol limpo: "gol válido anulado" (erro grave).
- A falta ou o impedimento original continua avaliado à parte, como antes (se não foi apitado, segue como "não marcada").
- `matchFacts` não conta o `goal_check` como falta, impedimento nem cartão (campos novos: `goalsDisallowed`, `goalChecksWrong`).

**Com VAR (nada foi alterado em `VarSystem`):** corrigir a falta ou o impedimento na revisão volta a partida ao instante do lance, e o gol some junto, como já acontecia. `restoreState` descarta a conferência de gol pendente e a súmula é truncada, sem registro duplicado.

**Arquivos:** `MatchRules.js` (constantes e textos), `MatchSimulation.js` (`disallowGoal`), `RefereeDecisionSystem.js`, `RefereeGrading.js`, `Controls.js` (tecla G), `MatchScene.js`, `HUD.js`, `config.js` (eventos `goal-disallowed` e `goal-decision` na lista), `MenuScene.js` (Como jogar) e `CommsSystem.js` (campos novos de fatos).

**Testes:** `tests/goalcheck.test.mjs` (12 testes). Total: 123 testes.

**Limitações:** a anulação não permite dar cartão junto; o replay do VAR continua mostrando o gol anulado pela tecla G na linha do tempo (o VAR não foi alterado); a durações das partidas continuam as mesmas 3 opções (só a pausa depois de cada gol ficou 1,4 s maior).

## 16. Upgrade 1 (primeira fatia): arbitragem mais realista

**Objetivo:** os lances deixam de parecer aleatórios: o árbitro precisa ler o contexto (evidências e histórico do jogador). Nada aqui altera a nota por fora das regras: tudo entra na súmula pelas mesmas decisões, com as mesmas penalidades de erro.

**Novidades:**
- **Faltas acumuladas / reincidência:** `jogador.foulsCommitted` conta as faltas *marcadas* contra ele (incrementa em `RefereeDecisionSystem.finalize`; faltas ignoradas não contam). A partir da 3ª (`PERSISTENT_FOULS = 2` faltas anteriores), uma falta leve passa a pedir **amarelo** e não aceita vantagem (`buildExpected(..., { persistent: true })`, evidência "reincidente: 3ª falta").
- **Falta tática** (`MatchRules.tacticalLevel`): falta fora da área que interrompe ataque promissor (jogador na metade de ataque, com velocidade, correndo para o gol e com no máximo 2 defensores à frente) pede **amarelo** (vira `serious_foul` nível amarelo); se ele era o último defensor perto do gol (distância menor que 190 px), pede **vermelho**. A tática só sobe a gravidade, nunca desce.
- **Mão na bola** (`MatchSimulation.checkHandball`): um defensor na linha de um passe, cruzamento ou chute pode tocar com o braço (14% por lance elegível, no máximo 1 a cada 30 s). Braço afastado do corpo = falta (pênalti na área); braço junto ao corpo com bola rápida = não é falta. Não criou tipo novo de lance: usa `light_foul`, `penalty` ou `challenge` com `subtype: 'handball'`, para o VAR, a nota e a súmula funcionarem sem mudanças estruturais (rótulo "Mão na bola" via `incidentLabel`).
- **Graus de contato:** toda disputa mostra "contato leve", "moderado" ou "forte" (`contactGrade`, pela velocidade relativa). Metade das quedas agora tem um toque mínimo do adversário ("contato mínimo (leve)" + "queda exagerada"): continua sendo simulação (amarelo para quem caiu, sem falta), mas o jogador precisa ler as evidências para não marcar falta.
- **Histórico no painel:** o botão Informação mostra posição, amarelos, faltas marcadas e quedas em lances duvidosos (`suspectFalls`), que é como o árbitro reconhece quem simula.
- **VAR:** o estado novo (`foulsCommitted`, `suspectFalls`, `lastHandballTime`) é capturado e restaurado em `captureState`/`restoreState`, então voltar no tempo desfaz as contagens. Só o texto do rótulo do VAR passou a usar `incidentLabel`.

**Frequência medida (16 partidas padrão, árbitro perfeito):** cerca de 19 lances por partida (mesma média de antes), ~2 mãos na bola, ~1,7 quedas (metade com contato mínimo), reincidência e falta tática raras (~0,25 por partida cada). O árbitro perfeito (que lê as evidências) continua sem nenhum erro.

**Testes:** `tests/realism.test.mjs` (8 testes). Dois testes antigos de `sim.test.mjs` foram ajustados de propósito: o das agravantes agora aceita a falta tática como segunda via de gravidade, e o de frequência de lances usa a média de 6 sementes (uma semente isolada varia de 6 a 13 lances na rápida). Total: 131 testes.

**Ainda não feito deste upgrade:** reclamação excessiva com cartão, tensão acumulada na partida, assistentes e lance mal interpretado pela equipe. Ficam para as próximas fatias.

## 17. Upgrade 2: decisões com consequências

**Princípio:** o clima muda o comportamento dos JOGADORES, nunca a chance de o árbitro errar. A torcida reage a quem a decisão favorece, não a quem tem razão, e isso nunca altera a nota.

**`systems/MatchMood.js`** (puro, dentro de `RefereeDecisionSystem.mood`):
- **Tensão (0 a 100):** começa na base do jogo (importância da partida e rivalidade: `(importância-1)*6 + 10 se clássico`), sobe com erros (falta real ignorada +12, falta sem infração +8, cartão errado +6, erro grave +10 extra, apito sem lance +3) e cai com acertos (-5) e com o tempo de jogo corrido. Rótulos: Calmo (menos de 25), Tenso, Quente (60 ou mais). Chegar ao Quente avisa uma vez.
- **Calor de cada time:** a falta ignorada esquenta o time prejudicado; a falta sem infração esquenta o time punido. `MatchSimulation.heat` soma até +0,15 na agressividade do jogador na disputa de bola.
- **Torcida da casa (-100 a 100):** `favoredBy(entrada)` diz quem a decisão favoreceu. Decisão correta contra a casa conta como "impopular", errada a favor da casa como "popular". Só informação.
- **Nota:** cada entrada da súmula grava a `tension` em que foi tomada e quem foi `favored`. Com tensão 60 ou mais a decisão pesa x1,25 (`PRESSURE_WEIGHT`): acertar ajuda, errar pesa mais, e quem acerta tudo continua com a mesma nota.
- **Amarelo muda a postura (`changePosture`):** clima calmo, agressividade -0,2 (cauteloso); clima quente, +0,1 (exaltado). A agressividade entra na captura do VAR, então voltar no tempo desfaz.
- **Expulsão:** `ctx.manDown` (diferença de jogadores) faz o time com um a menos recuar (formação mais funda) e o adversário subir um pouco (`PlayerAI.getTarget`).
- **VAR:** `captureState`/`restoreState` do sistema de decisões incluem o clima; `VarSystem` não foi alterado.

**Interface:** canto superior direito do HUD mostra "Clima" e "Torcida" (cor por nível); aba Estatísticas do resultado mostra o clima da partida, decisões sob pressão e decisões impopulares ou populares; o relatório por e-mail ganha a linha "Sob pressão"; as redes sociais ganham a publicação do torcedor (opinião: reclama de decisão correta) e a do jornalista (análise técnica: erro a favor da casa). O resumo do clima fica em `history[].mood`.

**Testes:** `tests/mood.test.mjs` (13 testes). Total: 144 testes.

**Limitações:** a consequência profissional de erro grave continua sendo a revisão técnica e as críticas do Upgrade 1 da carreira (não há suspensão nova); tensão não altera dribles nem placar.

## 18. Upgrade 5: análise técnica pós-jogo

**`systems/TechnicalReport.js`** (puro) monta o relatório a partir da súmula e da nota já calculadas: ele **explica** a nota, não recalcula (um teste garante que a nota não muda). Seções: resumo (o que funcionou e pontos de atenção), por que essa nota (cada categoria com pontos e veredito), decisões por tipo de lance, posicionamento e movimentação (distância média até os lances, quantos bem perto e longe, e comprimentos de campo percorridos, medidos na `MatchScene` por `refTravel`), consistência (mesma situação decidida de jeitos diferentes, ignorando vantagem), controle disciplinar (cartões e tensão máxima), uso do VAR, lances que poderiam ter sido melhor interpretados (os 5 mais graves, com a evidência que o painel mostrava e uma dica por regra, `tipFor`), recomendações de treinamento (no máximo 3, com o motivo real e o nome da atividade do futuro centro de treinamento) e "o que não entra na nota" (torcida e quantidade de cartões).

**Onde aparece:** aba **Relatório [4]** na tela de resultado (a aba Carreira passou a [5]); no histórico da carreira, "Ver relatório técnico" em cada partida (o relatório compacto fica em `history[].report`); a supervisão por e-mail ganha a linha "Recomendação de treino". O desenho do HTML está em `ui/reportHtml.js` (com texto escapado).

**Testes:** `tests/report.test.mjs` (12 testes).

## 19. Prints das partidas e rixa em clássico nas redes sociais

**Prints reais (só nas partidas da carreira que o jogador apita):** `MatchScene.setupHighlights` escuta gol, cartão vermelho, gol anulado, revisão do VAR, pênalti e lance polêmico (`isControversial`) e, quando `HighlightPlanner` aprova, tira uma captura da tela do jogo (`renderer.snapshot`, reduzida para 320x180 em JPEG, cerca de 12 mil caracteres). Limites: 4 prints por partida, 20 s de jogo entre prints (vermelho e gol anulado furam), depois de 2 prints só os mais importantes, imagem válida só se for JPEG em base64 de até 60 mil caracteres, e a carreira guarda as 14 imagens mais recentes (as antigas perdem a imagem e o texto fica).

**Conferência no fim do jogo (`finalizeShots`):** gol anulado (pelo VAR ou pela tecla) não vira publicação de gol (só ficam os prints dos gols que valem no placar final); lance que sumiu da súmula ou revisão que não existe mais é descartada; correção e erros do lance vêm da súmula final, não do momento do print.

**Legendas só com dados reais:** clube (gol), perfil oficial da competição (vermelho, gol anulado, VAR, com "Avaliação técnica: correta/incorreta"), jornalista com análise técnica quando o lance foi erro e torcedor com opinião quando foi correto ("tem gente reclamando, mas a avaliação técnica considerou a decisão correta").

**Rixa em clássico (`findFeud`):** só quando os mesmos dois jogadores de times diferentes se envolveram em 2 ou mais lances reais da partida e o jogo é um dos 12 clássicos. Gera uma publicação de torcedor (opinião) e uma notícia da categoria `lance`.

**Testes:** `tests/highlights.test.mjs` (10 testes). Total: 166 testes. Teste real no navegador: uma partida jogada sem decidir gerou 3 prints válidos de 320x180, sem erro no console, e o salvamento ficou com 85 KB.

**Limitações:** prints só existem nas partidas que o jogador apita (as outras partidas das ligas não têm imagem); não há imagens genéricas nem elenco fixo (aposentadorias e contratações ficam para o Upgrade 7); a captura depende do navegador (se falhar, a publicação sai sem imagem).

## 20. Upgrade 7: carreira com história e memória

**`systems/MemorySystem.js`** (puro). A memória só guarda o que aconteceu em partidas realmente apitadas e nunca altera a nota, o XP ou a reputação de uma partida (um teste compara uma partida com e sem queixa de clube). Estrutura salva em `career.memory` (clubes, competições e rivalidades) e `career.retrospectives`. Salvamento versão 8; a migração reconstrói a memória só com o `history` (sem queixas nem rixas antigas, que não existiam) e deixa as retrospectivas vazias.

- **Clubes que reclamaram:** `sideImpact(súmula)` separa decisão errada contra um lado (o lado foi prejudicado de verdade) de decisão correta contra o lado. Erro confirmado vira **queixa formal** (e-mail do clube, categoria comunicado); 2 ou mais decisões corretas contra um clube que perdeu viram **queixa pública** (publicação do clube deixando claro que a avaliação técnica discorda). Guarda as 4 mais recentes por clube. Na próxima convocação com esse clube aparece a lembrança, e a queixa formal soma 1 de pressão (a pública só informa).
- **Competições:** jogos, média, melhor nota e média por temporada. Aparece na aba Competições e nas convocações (média com 2 jogos ou mais).
- **Rivalidades que voltam:** a rixa de um clássico (`findFeud`) fica registrada por clássico (3 mais recentes). Como o elenco de cada clube é determinístico (`makeRoster`), os mesmos nomes voltam nas temporadas seguintes, e a convocação lembra "na última vez, X e Y se estranharam N vezes".
- **Reencontros em jogos decisivos:** final, semifinal, última rodada ou clássico mostram "você já apitou o clube X N vezes (média Y)".
- **Convocação de confiança:** `goodFormTrust` (média 8,0 ou mais nas 3 últimas partidas e nenhum erro grave) transforma o jogo mais importante da semana em **"Convite"** da comissão (`buildOffers(..., { trusted })`), com evento `trust_call` e e-mail únicos por semana. Aceitar é opcional.
- **Retrospectiva da temporada:** `seasonRetrospective` roda uma vez no fim da temporada: jogos, média, melhor e pior jogo, melhor competição, clube mais encontrado, queixas, rixas, cartões, VAR, reputação, XP, prêmios, promoção ou rebaixamento e um **perfil da temporada** por regra (Temporada polêmica, Cirúrgico, Árbitro regional, Especialista em copas, Veterano de clássicos, Pulso firme, Temporada regular). Gera notícia e e-mail da temporada e aparece na tela de fim de temporada e na aba **Retrospectiva** (que também lista clubes que reclamaram e rivalidades lembradas).

**Testes:** `tests/memory.test.mjs` (11 testes). Total: 177 testes.

**Ainda não feito:** elenco fixo de jogadores (aposentadoria, contratações e transferências). Hoje os nomes dos jogadores são determinísticos por clube, mas não envelhecem nem trocam de clube; isso exige uma virada de temporada própria para o elenco e fica para uma próxima fatia.

## 21. Upgrade 4: acontecimentos dinâmicos

**Princípio:** as condições e a história de cada jogo mudam o CONTEXTO da partida (como a bola corre, quantos contatos surgem, a tensão e o que a torcida espera), nunca a nota nem a resposta certa de um lance. O árbitro não perde velocidade na chuva, e nada é sorteado a cada execução: tudo sai de um hash da partida (`conditionsFor`), então a mesma partida da carreira tem sempre as mesmas condições, e a convocação já mostra a **Previsão**.

**`systems/MatchConditions.js`** (puro):
- **Tempo e gramado:** tempo bom, nublado, chuva, chuva forte e neblina (chuva deixa o gramado pesado; sem chuva, 20% de gramado irregular). Efeitos: atrito da bola, velocidade dos jogadores e `slip` (a disputa de bola fica menos limpa: mais contatos). Medido em 12 partidas: faltas por jogo 9,6 (bom), 11,3 (chuva) e 12,2 (chuva forte); lances por jogo 19,4 em todos os casos e árbitro perfeito sem nenhum erro.
- **Visibilidade reduzida (neblina e chuva forte):** efeito visual (neblina) e a evidência "visibilidade reduzida" em lances a 90 px ou mais do árbitro. Só informação.
- **História do jogo:** clássico (+10 de tensão), final (+10), semifinal (+6), disputa de título e luta contra o rebaixamento (+8, só em liga, só a partir da 3ª rodada, lendo a tabela real) e **retorno de lesão** (30% dos jogos: um jogador de linha do elenco real do clube volta com 8% menos de velocidade; falta ignorada nele esquenta o time +6 e a evidência mostra "retorno de lesão"). Jogos grandes fazem a torcida pesar 1,5x.
- **Minutos finais (`isLateDrama`):** depois dos 80 minutos com no máximo 1 gol de diferença o clima não esfria abaixo de 50 e aparece o aviso "MINUTOS FINAIS". As decisões nessa fase pesam mais pelo mecanismo de tensão do Upgrade 2.
- **Banco e torcida:** falta real ignorada com a tensão em 40 ou mais faz o banco do time prejudicado reclamar (no máximo 1 vez a cada 30 s por time); torcida muito irritada pressiona (no máximo 3 vezes) e sobe a tensão em 4. Só contexto.

**Visual:** `ui/WeatherFx.js` desenha chuva, tempestade (com relâmpago) e neblina por código, sem arquivos de imagem; o HUD mostra o tempo e o gramado.

**Integrações:** o resumo das condições fica em `history[].conditions`; as redes sociais ganham publicações com dados reais (tempo e gramado, disputa de título ou rebaixamento, retorno de lesão e faltas sofridas, jogo decidido nos minutos finais); o relatório técnico ganha a seção "Contexto da partida"; a convocação mostra a previsão e a história do jogo.

**Correção encontrada no caminho:** o calendário chama a fase de "Semifinais", mas três regras só reconheciam "Semifinal" (pressão, reencontro e condições). Agora todas reconhecem as duas formas, então as semifinais passaram a gerar pressão e convocação especial como era esperado desde a Etapa 6.

**Correção de layout (vinha do Upgrade 2):** o bloco "Clima/Torcida" ficava atrás do botão VAR; passou para o canto superior esquerdo da barra. A dica de controles foi encurtada para caber.

**Para testes:** `?weather=storm` (ou rain, fog, clear, cloudy) na URL força o tempo da partida.

**Testes:** `tests/conditions.test.mjs` (14 testes). Total: 191 testes.

**Limitações:** o clima não afeta a IA de passes (só a velocidade e o atrito); o retorno de lesão vale só para um jogador por partida; as notícias não usam as condições (só as publicações e o relatório).

## 22. Upgrade 6: treinamento e especialização

**Aba Treino** na central da carreira: 6 atividades curtas (5 exercícios cada) que melhoram 6 atributos profissionais do árbitro. O treino só conta quando a sessão termina (sair antes não gasta nada), cada rodada da carreira dá **2 sessões** (`SESSIONS_PER_WEEK`), e cada sessão é determinística pela carreira, rodada e número da sessão (`sessionSeed`), então recarregar não troca os exercícios. Uma sessão paga até 30 pontos de atributo (24 proporcionais aos acertos mais 6 de bônus na sessão perfeita) e 6 XP de carreira; nenhum treino dá reputação.

**`systems/TrainingSystem.js`** (puro) e `data/trainingContent.js` (bancos de perguntas):
| Atributo | Atividade | Exercício |
|---|---|---|
| Leitura de faltas | Reconhecer faltas em situações ilustradas | 12 tipos de lance (disputa legal, falta leve e grave, pênalti, falta tática, reincidência, mão na bola, simulação com e sem contato) montados com `classifyFoul`, `buildExpected` e `tacticalLevel`, as mesmas funções da partida |
| Impedimentos | Julgar impedimentos | cenas com a linha do penúltimo defensor, bola e atacante; a resposta usa a mesma regra de `PlayerAI.offsideInfo` (um teste confere 500 exercícios contra a função do jogo) |
| Posicionamento | Treinar o posicionamento | 4 posições (A a D) na jogada; a certa é a mais perto do ponto ideal (uns 26 px atrás da jogada, do lado do meio do campo) |
| Domínio do VAR | Aprender quando o VAR pode intervir | 12 situações (3 em que pode, 2 em que não, por sessão) |
| Controle de jogo | Simular situações de confronto entre jogadores | 10 situações (conversar, amarelo, vermelho, seguir) |
| Conhecimento de regras | Testes de regras e interpretação | 20 perguntas alinhadas às regras do jogo |

**Níveis:** 0 a 5 (40, 100, 180, 280 e 400 pontos). **Efeitos em partida da carreira**, todos explícitos na tela e nenhum muda a resposta certa de um lance nem a nota:
- Posicionamento: +4% de velocidade do árbitro por nível (`MatchScene`).
- Leitura de faltas e Impedimentos: +10% por nível no tempo para apitar o tipo de lance (`RefereeDecisionSystem.windowMul`).
- Controle de jogo: o clima esfria 15% mais rápido por nível e erros esquentam 4% menos por nível (`MatchMood.setTraining`).
- Domínio do VAR (nível 2): o painel marca "Lance típico de VAR" (leitura de `isVarEligible`, sem alterar o VAR).
- Conhecimento de regras (nível 3): o painel mostra a regra geral do tipo de lance (`ruleHintFor`, nunca o cartão); nível 5: também quantas agravantes o lance tem.

**Integrações:** as recomendações do relatório pós-jogo apontam a atividade do treino (`activity`); salvamento versão 9 (migração só cria o treino zerado).

**Testes:** `tests/training.test.mjs` (14 testes). Total: 205 testes.

**Limitações:** o treino não existe em partida rápida (sem carreira); as perguntas de confronto ensinam regras de conduta que o jogo ainda não cobra em partida (reclamação com cartão ficou para o Upgrade 1); posicionamento só treina o ponto ideal, não mede a posição real na partida.

## 23. Limpeza de layout da central da carreira

Só interface (`MenuScene.js` e `style.css`): nenhuma regra, dado ou salvamento mudou.

- **15 telas em 5 grupos**, numa barra no topo, com sub-abas dentro de cada grupo (o grupo reabre a última sub-aba usada):
  - **Início:** visão geral.
  - **Jogos:** Convocações, Calendário, Classificação e Competições.
  - **Carreira:** Objetivos, Prêmios, Retrospectiva, Estatísticas e Histórico.
  - **Comunicação:** Notícias, E-mails, Rede social e Eventos.
  - **Treino.**
- **Contadores de novidades** no grupo (soma) e na sub-aba (e-mails não lidos, convocações abertas, objetivos e prêmios novos).
- **Cartão de convocação enxuto:** times, competição e estádio, uma linha de etiquetas (importância, pressão, previsão, retorno de lesão, histórico com os clubes) e **"Ver detalhes"** com o texto completo (descrição, pressão, previsão e lembranças da memória).
- **Rodapé:** Menu, Configurações e Salvar carreira. **Apagar carreira** foi para uma "Zona de risco" dentro de Configurações (a confirmação continua).
- A marcação de objetivos e prêmios como vistos agora acontece em qualquer caminho que abra a sub-aba (`afterTabChange`).
- **Roteiro de regressão no navegador:** agora verifica 5 grupos e 15 telas com conteúdo.

## 24. Upgrade 3: equipe de arbitragem

**Princípio:** a equipe dá INFORMAÇÃO (bandeira, opinião, ajuda com o banco), às vezes errada, com a confiabilidade mostrada ao jogador. A decisão e a nota continuam sendo só do árbitro principal: seguir um conselho errado conta como erro, ignorar um conselho certo e acertar não custa nada (um teste confere que a nota não muda com ou sem os dados da equipe). Tudo é determinístico (mesma partida, mesmo lance e mesmo número de consulta dão a mesma resposta), então a revisão do VAR e recarregar o jogo não mudam o que a equipe viu.

**`systems/CrewSystem.js`** (puro): dois assistentes (linha lateral de cima e de baixo) e o quarto árbitro, com nomes e experiência da semente da carreira (`generateCrew`).
- **Confiabilidade pela experiência (0 a 100):** de 62% a 92%. **Entrosamento (0 a 100):** a comunicação é Boa (70 ou mais), Regular ou Divergente, e define a chance de o assistente hesitar sem dar opinião (30% sem entrosamento, 0% com 100).
- **Bandeira (`flagFor`):** só em lance de impedimento (`offside` e `legal_position`). Levanta em 62% a 92% dos impedimentos reais e, às vezes, levanta sem impedimento (19% a 4%). O aviso e o painel mostram "Bandeira de fulano: levantada".
- **Consulta (`consultOptions` e `consult`, tecla C no painel):** impedimento sempre; faltas só a até 70 px da linha lateral; no máximo 3 por partida; cada uma esquenta o clima em 2 (o jogo fica parado). Acerta com a confiabilidade (um pouco menos longe da linha), hesita se a comunicação falhar. Uma consulta por lance.
- **Quarto árbitro (`benchCalm`, tecla B):** por até 6 s depois que um banco reclama (Upgrade 4), no máximo 2 vezes por jogo; chance de 50% a 90% pela experiência dele; se der certo, o calor do time cai 10 e a tensão cai 4.
- **Depois da partida (`crewMatchUpdate`):** todos ganham 6 de experiência (+2 para o assistente cujo conselho certo foi seguido); entrosamento +3 (+2 se houve consulta e nenhum conselho errado foi seguido). Estatísticas totais na carreira.

**Integrações:** `RefereeDecisionSystem` (bandeira no registro do lance, `consult`, `callFourth`, `crewEntry` na súmula, captura e restauração para o VAR); `DecisionPanel` (botão "Consultar assistente [C]" com o que restou e o motivo quando não dá); `HUD` (avisos de bandeira e de bola fora: lateral, escanteio e tiro de meta, no máximo 1 a cada 12 s); `ui/CrewSprites.js` (assistentes acompanhando a jogada nas linhas laterais, bandeira levantada, quarto árbitro com a placa, tudo desenhado por código); relatório pós-jogo (seção "Equipe de arbitragem", dicas de bandeira errada e de conselho errado seguido, recomendação de treino); aba **Equipe** em Carreira; salvamento versão 10 (migração cria a equipe da semente e dos jogos já apitados).

**Testes:** `tests/crew.test.mjs` (15 testes, incluindo taxas de acerto e de hesitação em 1.000 a 1.500 sorteios). Total: 220 testes.

**Limitações:** os assistentes só opinam sobre falta ou impedimento (não sobre cartões); o quarto árbitro não faz substituições (o jogo não tem substituições); o jogo continua sem lances de reclamação com cartão (Upgrade 1, ainda pendente). Os assistentes ficam nas linhas laterais, então só aparecem na tela quando a câmera chega perto delas.

## 25. Upgrade 1 (fechamento): reclamação com cartão e perfis de jogador

**Perfis (`systems/PlayerProfiles.js`):** a tendência a reclamar (`dissentTrait`, 0,1 a 0,9) é fixa por jogador (hash de time, número e nome), sem usar o sorteio da simulação, então os jogos não mudam de rumo por isso. O painel só mostra o perfil pelo que o jogador FEZ (`profileTags`): "costuma cair em lances duvidosos" (2 quedas), "reclama muito" (2 reclamações), "reincidente em faltas", "já foi advertido"; e o aviso de cartão perto (`bookingEdge`): "na beira do amarelo" (2 faltas marcadas) e "já tem amarelo: o próximo é vermelho". Contadores novos por jogador, capturados e restaurados para o VAR: `protests` e `warnings`.

**Reclamação (`RefereeDecisionSystem.maybeDissent` e `resolveDissent`):** depois de uma falta marcada, o jogador de perfil reclamão (tendência de 0,6 ou mais) da equipe punida pode protestar (chance de cerca de 0,14 vezes a tendência mais a tensão/600; no máximo 2 por jogo e 60 s entre elas; sorteio determinístico por lance). Mede-se cerca de 1 por jogo em partidas completas. O jogo fica parado até a decisão (o relógio da parada espera).
- **Leve** (primeira reclamação, clima abaixo de 50, tendência abaixo de 0,8): evidências "reclamação com palavras", "tom controlado", "primeira reclamação do jogador". Certo: advertência verbal (ou seguir o jogo). Amarelo = `CARD_UNWARRANTED`.
- **Exagerada** (reclamou antes, já foi advertido, clima quente ou tendência de 0,8 ou mais): "gestos exagerados", "grita com o árbitro" e, se for o caso, "já foi advertido neste jogo", "reclamação persistente (3ª vez)", "clima quente". Certo: amarelo. Advertência = `CARD_TOO_LIGHT`; seguir o jogo = `CARD_MISSED`. O segundo amarelo vira vermelho, como sempre.
- Entra na súmula como decisão do tipo `dissent` (peso 0,8 na nota, texto próprio, `matchFacts` conta `dissents`, `dissentsRight` e os cartões, sem virar falta), no relatório (dica e recomendação de treino de Controle de jogo) e no clima (erro esquenta, acerto esfria). Não é um lance do campo: não passa pelo VAR (que não foi alterado), e a revisão do VAR descarta uma reclamação aberta.
- Painel curto `ui/DissentPanel.js` (teclas I, A e 1).

**Frequência:** o árbitro perfeito (que lê as evidências) continua sem erros nas 12 partidas de teste.

**Testes:** `tests/dissent.test.mjs` (9 testes). O simulador de teste agora resolve a reclamação como o modo pede. Total: 229 testes.

**Nota sobre o simulador de teste:** nas sementes 16 e 22 de partidas longas, dois lances que acontecem no mesmo segundo (um impedimento legal e uma falta grave) fazem o árbitro de teste decidir só um deles; é uma limitação antiga do simulador de teste, que não foi mexida, e os testes usam sementes até 14.

**Limitações:** a reclamação só ocorre depois de falta marcada (não depois de falta ignorada); não existe cartão vermelho direto por reclamação (só por segundo amarelo); a tendência a reclamar não tem efeito em outras decisões.
