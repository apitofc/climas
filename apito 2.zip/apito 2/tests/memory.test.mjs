import test from 'node:test';
import assert from 'node:assert/strict';
import { createCareer, applyMatch, migrateCareer, getOffers, skipWeek, CAREER_VERSION } from '../src/systems/CareerSystem.js';
import { sideImpact, rememberMatch, memoryNotes, goodFormTrust, seasonRetrospective, buildMemoryFromHistory, emptyMemory, COMPLAINT_LIMIT } from '../src/systems/MemorySystem.js';
import { matchContext } from '../src/systems/ContextSystem.js';
import { xpBreakdown, repBreakdown } from '../src/systems/ProgressionSystem.js';

const FACTS = { decisions: 8, correct: 7, yellow: 1, red: 0, redWrong: 0, fouls: 3, penalties: 0, penaltiesCorrect: 0, penaltiesMissed: 0, wrongCalls: 0, missedFouls: 0, simulationsPunished: 0, simulationsMissed: 0, offsides: 0, offsidesCorrect: 0, offsidesMissed: 0, advantageOk: 0, advantageFailed: 0, whistles: 0 };
const result = (nota, over = {}) => ({ nota, label: 'ok', categories: [{ label: 'Posicionamento', points: 5, max: 10, ratio: 0.5 }], mistakes: [], hits: [], counts: { unnecessaryWhistles: 0 }, score: { home: 1, away: 0 }, extras: { ...FACTS }, ...over });
const fx = (home, away, matchId, comp = 'varzea') => ({ competitionId: comp, homeId: home, awayId: away, importance: 1, matchId, duration: 'standard' });
const sides = (h = {}, a = {}) => ({ home: { wrong: 0, correctAgainst: 0, reds: 0, ...h }, away: { wrong: 0, correctAgainst: 0, reds: 0, ...a } });
const E = (over = {}) => ({ type: 'light_foul', correct: true, favored: null, actual: { cards: [] }, errors: [], ...over });

test('impacto por lado: decisão errada prejudica de verdade, decisão correta contra o lado só gera reclamação', () => {
  const log = [
    E({ favored: 'home', correct: false, errors: ['FOUL_MISSED'] }), // errada, favoreceu a casa: prejudicou o visitante
    E({ favored: 'home', correct: true }), // correta contra o visitante
    E({ favored: 'away', correct: true, actual: { cards: [{ team: 'home', color: 'red' }] } }),
    E({ favored: null }),
    { type: 'unnecessary_whistle', errors: ['WHISTLE_UNNECESSARY'], correct: false },
  ];
  assert.deepEqual(sideImpact(log), { home: { wrong: 0, correctAgainst: 1, reds: 1 }, away: { wrong: 1, correctAgainst: 1, reds: 0 } });
  assert.deepEqual(sideImpact([]), sides());
});

test('memória do clube: jogos, média, queixa formal (erro confirmado) e queixa pública (decisão correta e derrota)', () => {
  const c = createCareer('Ana', 1);
  const rec = (matchId, score = '1 x 0', nota = 7) => ({ matchId, season: 1, week: 1, competitionId: 'varzea', homeId: 'tamarindo', awayId: 'moinho', nota, score });
  const n1 = rememberMatch(c, rec('a'), { sides: sides({}, { wrong: 2 }) });
  assert.ok(n1.some((n) => n.type === 'complaint' && n.clubId === 'moinho' && n.kind === 'formal' && n.n === 2));
  const n2 = rememberMatch(c, rec('b', '1 x 0', 9), { sides: sides({}, { correctAgainst: 2 }) });
  assert.ok(n2.some((n) => n.kind === 'publica' && n.clubId === 'moinho'), 'perdeu e reclamou de decisão correta');
  const n3 = rememberMatch(c, rec('c', '0 x 1', 6), { sides: sides({ correctAgainst: 3 }, {}) });
  assert.ok(n3.some((n) => n.clubId === 'tamarindo' && n.kind === 'publica'));
  const n4 = rememberMatch(c, rec('d', '2 x 0', 8), { sides: sides({}, { correctAgainst: 1 }) });
  assert.equal(n4.length, 0, 'uma decisão correta contra o time não vira reclamação');
  const m = c.memory.clubs.moinho;
  assert.equal(m.matches, 4);
  assert.equal(m.sumNota, 30);
  assert.equal(m.complaints.length, 2);
  assert.equal(m.complaints[0].kind, 'publica', 'a mais recente primeiro');
  assert.equal(c.memory.competitions.varzea.matches, 4);
  assert.deepEqual(c.memory.competitions.varzea.best, { nota: 9, season: 1, matchId: 'b' });
  for (let i = 0; i < 8; i++) rememberMatch(c, rec(`x${i}`), { sides: sides({}, { wrong: 1 }) });
  assert.equal(c.memory.clubs.moinho.complaints.length, COMPLAINT_LIMIT);
});

test('rivalidade: a rixa do clássico fica registrada e volta como lembrança no próximo encontro', () => {
  const c = createCareer('Ana', 2);
  const feud = { a: { name: 'Moura', number: 10 }, b: { name: 'Silva', number: 9 }, count: 3, cards: 1 };
  const notes = rememberMatch(c, { matchId: 'r1', season: 1, week: 2, competitionId: 'varzea', homeId: 'tamarindo', awayId: 'jaqueira', nota: 7, score: '1 x 1' }, { feud });
  assert.ok(notes.some((n) => n.type === 'feud'));
  const rm = c.memory.rivalries.varzea;
  assert.deepEqual([rm.matches, rm.cards, rm.feuds.length, rm.lastSeason], [1, 1, 1, 1]);
  const lembrancas = memoryNotes(c, { competitionId: 'varzea', homeId: 'jaqueira', awayId: 'tamarindo', stage: 'Rodada 1', week: 1 });
  assert.ok(lembrancas.some((n) => n.id === 'rivalry' && n.text.includes('Moura') && n.text.includes('3 vezes')));
  assert.ok(lembrancas.some((n) => n.id === 'reencounter' && n.text.includes('Reencontro')), 'clássico é partida decisiva');
  assert.deepEqual(memoryNotes(c, { competitionId: 'varzea', homeId: 'moinho', awayId: 'cacimba', stage: 'Rodada 1', week: 1 }), []);
  assert.deepEqual(memoryNotes({}, { competitionId: 'varzea', homeId: 'a', awayId: 'b' }), []);
});

test('reencontro só aparece em jogo decisivo; média por competição só com 2 jogos ou mais', () => {
  const c = createCareer('Ana', 3);
  const rec = (id) => ({ matchId: id, season: 1, week: 1, competitionId: 'varzea', homeId: 'cacimba', awayId: 'pitangueira', nota: 8, score: '0 x 0' });
  rememberMatch(c, rec('p1'), {});
  const plain = memoryNotes(c, { competitionId: 'varzea', homeId: 'cacimba', awayId: 'moinho', stage: 'Rodada 1', week: 2 });
  assert.ok(!plain.some((n) => n.id === 'reencounter'));
  assert.ok(!plain.some((n) => n.id === 'competition'), 'só 1 jogo');
  const last = memoryNotes(c, { competitionId: 'varzea', homeId: 'cacimba', awayId: 'moinho', stage: 'Rodada 5', week: 5 });
  assert.ok(last.some((n) => n.id === 'reencounter' && n.text.includes('Cacimba FC')), 'última rodada é decisiva');
  rememberMatch(c, rec('p2'), {});
  assert.ok(memoryNotes(c, { competitionId: 'varzea', homeId: 'cacimba', awayId: 'moinho', stage: 'Rodada 1', week: 2 }).some((n) => n.id === 'competition' && n.text.includes('média é 8 em 2 jogos')));
});

test('boa fase: média 8,0 ou mais nas 3 últimas, sem erro grave', () => {
  const h = (nota, graves = 0) => ({ nota, graves });
  assert.equal(goodFormTrust({ history: [h(9), h(8)] }).trusted, false, 'precisa de 3 partidas');
  assert.equal(goodFormTrust({ history: [h(9), h(8), h(7.9)] }).trusted, true, 'média 8,3');
  assert.equal(goodFormTrust({ history: [h(8), h(8), h(7.9)] }).trusted, false, 'média 7,97');
  assert.equal(goodFormTrust({ history: [h(9), h(9), h(9, 1)] }).trusted, false, 'erro grave bloqueia');
  assert.equal(goodFormTrust({ history: [h(9), h(9), h(9), h(2)] }).trusted, true, 'só as 3 últimas contam');
});

test('na carreira: queixa vira e-mail ou publicação do clube, a memória é salva e nada muda na nota, XP ou reputação', () => {
  const a = createCareer('Ana', 4);
  const b = createCareer('Ana', 4);
  const sa = applyMatch(a, fx('tamarindo', 'moinho', 'm1'), result(7, { sides: sides({}, { wrong: 1 }) }));
  const sb = applyMatch(b, fx('tamarindo', 'moinho', 'm1'), result(7));
  assert.equal(sa.xpGain, sb.xpGain);
  assert.equal(sa.repDelta, sb.repDelta);
  assert.equal(sa.xpGain, xpBreakdown(7, 1).xp);
  assert.equal(a.history[0].nota, b.history[0].nota);
  assert.ok(sa.memory.some((n) => n.type === 'complaint'));
  const mail = a.inbox.find((m) => m.key === 'm1:mem:complaint:moinho:mail');
  assert.ok(mail && mail.from === 'Moinho AC' && mail.lines.some((l) => l.includes('não altera sua nota')));
  assert.equal(a.history[0].homeId, 'tamarindo');
  assert.equal(a.memory.clubs.moinho.matches, 1);
  assert.equal(b.memory.clubs.moinho.complaints.length, 0);

  const c = createCareer('Ana', 5);
  applyMatch(c, fx('tamarindo', 'moinho', 'm2'), result(7, { score: { home: 1, away: 0 }, sides: sides({}, { correctAgainst: 2 }) }));
  const post = c.social.find((p) => p.key === 'm2:mem:complaint:moinho:post');
  assert.ok(post && post.author.kind === 'clube' && post.technical === false && post.text.includes('A avaliação técnica considerou as decisões corretas'));

  assert.equal(applyMatch(a, fx('tamarindo', 'moinho', 'm1'), result(7, { sides: sides({}, { wrong: 1 }) })), null);
  assert.equal(a.memory.clubs.moinho.matches, 1, 'reprocessar não duplica a memória');
  assert.equal(a.inbox.filter((m) => m.key === 'm1:mem:complaint:moinho:mail').length, 1);
});

test('o clube que reclamou volta a aparecer com pressão a mais e a lembrança nas convocações', () => {
  const c = createCareer('Ana', 6);
  const f = { competitionId: 'varzea', homeId: 'moinho', awayId: 'cacimba', stage: 'Rodada 1', week: 1 };
  const before = matchContext(c, f).level;
  applyMatch(c, fx('tamarindo', 'moinho', 'g1'), result(7, { sides: sides({}, { wrong: 1 }) }));
  const ctx = matchContext(c, f);
  assert.ok(ctx.level >= before + 1 - (before >= 3 ? 1 : 0));
  assert.ok(ctx.tags.some((t) => t.id === 'memory-grievance'));
  assert.ok(memoryNotes(c, f).some((n) => n.id === 'grievance' && n.text.includes('Moinho AC')));
  // Queixa pública (decisão correta) só informa: não soma pressão.
  const d = createCareer('Ana', 7);
  applyMatch(d, fx('tamarindo', 'moinho', 'g2'), result(7, { sides: sides({}, { correctAgainst: 2 }) }));
  assert.ok(!matchContext(d, f).tags.some((t) => t.id === 'memory-grievance'));
  assert.ok(memoryNotes(d, f).some((n) => n.id === 'grievance' && n.weight === 0));
});

test('convocação de confiança: boa fase destaca o jogo mais importante e avisa uma vez; sem boa fase, nada muda', () => {
  const good = createCareer('Ana', 8);
  good.history = [{ nota: 9, graves: 0 }, { nota: 8.5, graves: 0 }, { nota: 8, graves: 0 }];
  skipWeek(good);
  const offers = getOffers(good);
  assert.ok(offers.some((o) => o.tag === 'Convite'), offers.map((o) => o.tag).join());
  assert.ok(!offers.some((o) => o.tag === 'Importante'));
  const ev = good.events.find((e) => e.type === 'trust_call');
  assert.ok(ev && ev.tone === 'positive' && ev.text.includes('8,5'));
  const mail = good.inbox.find((m) => m.key === `${ev.key}:mail`);
  assert.ok(mail && mail.category === 'convocação' && mail.lines.some((l) => l.includes('opcional')));

  const plain = createCareer('Ana', 9);
  plain.history = [{ nota: 6, graves: 0 }, { nota: 8.5, graves: 0 }, { nota: 8, graves: 0 }];
  skipWeek(plain);
  assert.ok(!getOffers(plain).some((o) => o.tag === 'Convite'));
  assert.ok(!plain.events.some((e) => e.type === 'trust_call'));
});

// ------------------------------------------------------------ retrospectiva
function playSeason(career, nota) {
  const start = career.season.number;
  let guard = 0;
  while (career.season.number === start && guard++ < 20) {
    const offers = getOffers(career).filter((o) => o.status === 'offered');
    if (!offers.length) {
      skipWeek(career);
      continue;
    }
    const f = offers[0].fixture;
    applyMatch(career, { competitionId: f.competitionId, homeId: f.home, awayId: f.away, importance: f.importance, fixtureId: f.id, matchId: `s${start}-${guard}`, duration: 'standard' }, result(nota));
  }
  assert.ok(career.season.number > start);
}

test('fim da temporada: retrospectiva com números reais, notícia, e-mail e perfil; sem duplicar', () => {
  const c = createCareer('Ana', 10);
  playSeason(c, 8.8);
  assert.equal(c.retrospectives.length, 1);
  const r = c.retrospectives[0];
  assert.equal(r.season, 1);
  assert.ok(r.played >= 3 && r.avg === 8.8);
  assert.equal(r.best.nota, 8.8);
  assert.ok(r.lines.some((l) => l.includes('média 8,8')));
  assert.ok(['cirurgico', 'copas', 'regional', 'classicos', 'regular', 'pulso'].includes(r.profile.id));
  assert.ok(c.news.some((n) => n.key === 'season:1:news:retro' && n.headline.includes('Retrospectiva')));
  assert.ok(c.inbox.some((m) => m.key === 'season:1:mail:retro' && m.lines.length >= 3));
  assert.ok(Object.keys(c.memory.competitions).length >= 1);
  const count = [c.retrospectives.length, c.news.length, c.inbox.length];
  playSeason(c, 7);
  assert.equal(c.retrospectives.length, 2);
  assert.equal(c.retrospectives[0].season, 2, 'a mais recente primeiro');
  assert.deepEqual(count, [1, count[1], count[2]]);
});

test('perfil da temporada: cada trajetória tem o seu', () => {
  const m = (nota, over = {}) => ({ nota, graves: 0, competition: 'Copa Várzea Verde', competitionId: 'varzea', home: 'A', away: 'B', score: '1 x 0', rep: 0.5, xp: 40, extras: { yellow: 1, red: 0 }, ...over });
  const mk = (matches) => seasonRetrospective(createCareer('Ana', 1), { number: 1, matches }, {});
  assert.equal(mk([m(8.5), m(9), m(8.2), m(8.9)]).profile.id, 'cirurgico');
  assert.equal(mk([m(8, { graves: 2 }), m(7, { graves: 1 })]).profile.id, 'polemico');
  assert.equal(mk([m(7.5, { competitionId: 'copanacional', competition: 'Copa Nacional' }), m(7.5, { competitionId: 'copanacional', competition: 'Copa Nacional' }), m(7)]).profile.id, 'copas');
  assert.equal(mk([m(7, { competitionId: 'copasul', competition: 'Copa Sul' }), m(7, { competitionId: 'copasul', competition: 'Copa Sul' })]).profile.id, 'regional');
  assert.equal(mk([m(7, { context: { tags: ['rivalry'] } }), m(7, { context: { tags: ['rivalry'] } })]).profile.id, 'classicos');
  assert.equal(mk([]).lines[0], 'Temporada sem partidas apitadas.');
});

// ------------------------------------------------------------ migração
test('migração v7 -> v8: a memória é reconstruída só com o histórico e nada é inventado', () => {
  const c = createCareer('Ana', 11);
  applyMatch(c, fx('tamarindo', 'moinho', 'o1'), result(7, { sides: sides({}, { wrong: 1 }) }));
  applyMatch(c, fx('tamarindo', 'jaqueira', 'o2'), result(8));
  const old = JSON.parse(JSON.stringify(c));
  old.version = 7;
  delete old.memory;
  delete old.retrospectives;
  for (const h of old.history) {
    delete h.homeId; // registros antigos só tinham os nomes
    delete h.awayId;
  }
  const r = migrateCareer(old);
  assert.ok(!r.error && r.migrated);
  assert.equal(r.career.version, CAREER_VERSION);
  assert.equal(r.career.memory.clubs.tamarindo.matches, 2);
  assert.equal(r.career.memory.clubs.moinho.matches, 1);
  assert.equal(r.career.memory.clubs.moinho.complaints.length, 0, 'queixas antigas não existem: nada é inventado');
  assert.equal(r.career.memory.competitions.varzea.matches, 2);
  assert.deepEqual(r.career.retrospectives, []);
  assert.equal(migrateCareer(JSON.parse(JSON.stringify(r.career))).migrated, false);
  const built = buildMemoryFromHistory({ history: [] });
  assert.deepEqual(built, emptyMemory());
});
