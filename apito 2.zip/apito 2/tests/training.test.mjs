import test from 'node:test';
import assert from 'node:assert/strict';
import { createCareer, migrateCareer, skipWeek, CAREER_VERSION } from '../src/systems/CareerSystem.js';
import {
  ATTRIBUTES, LEVEL_XP, MAX_LEVEL, SESSIONS_PER_WEEK, SESSION_XP, PERFECT_BONUS, CAREER_XP_PER_SESSION, HISTORY_LIMIT,
  levelOf, attrLevelInfo, buildSession, scoreSession, applySession, sessionsLeft, sessionSeed, trainingEffects, ensureTraining, emptyTraining, isOffsidePosition, idealSpot,
} from '../src/systems/TrainingSystem.js';
import { VAR_BANK } from '../src/data/trainingContent.js';
import { offsideInfo } from '../src/systems/PlayerAI.js';
import { ruleHintFor, INCIDENT } from '../src/systems/MatchRules.js';
import { createMatch } from './helpers/harness.mjs';
import { DURATIONS, FIELD_RECT } from '../src/config.js';
import { buildReport } from '../src/systems/TechnicalReport.js';
import { gradeMatch, matchFacts } from '../src/systems/RefereeGrading.js';
import { sceneSvg } from '../src/ui/trainingScene.js';

const standard = DURATIONS.find((d) => d.id === 'standard').ms;
const IDS = ['fouls', 'offside', 'position', 'var', 'control', 'rules'];
const perfect = (s) => s.items.map((i) => i.answer);

test('seis atributos, cada um com atividade, efeito explicado e nível máximo 5', () => {
  assert.deepEqual(ATTRIBUTES.map((a) => a.id), IDS);
  for (const a of ATTRIBUTES) assert.ok(a.label && a.activity && a.blurb && typeof a.effect(1) === 'string' && typeof a.effect(5) === 'string');
  assert.equal(MAX_LEVEL, 5);
  assert.deepEqual([levelOf(0), levelOf(39), levelOf(40), levelOf(180), levelOf(399), levelOf(400), levelOf(9999)], [0, 0, 1, 3, 4, 5, 5]);
  assert.deepEqual(attrLevelInfo(50), { level: 1, into: 10, need: 60, next: 100 });
  assert.equal(attrLevelInfo(400).next, null);
  assert.equal(LEVEL_XP.length, MAX_LEVEL + 1);
});

test('toda sessão tem 5 exercícios com resposta entre as opções, é determinística e muda com a semente', () => {
  for (const act of IDS) {
    const a = buildSession(act, 'semente');
    assert.equal(a.items.length, 5);
    assert.deepEqual(a, buildSession(act, 'semente'));
    assert.notDeepEqual(a.items.map((i) => i.prompt + i.explain), buildSession(act, 'outra').items.map((i) => i.prompt + i.explain));
    for (const it of a.items) {
      assert.ok(it.options.some((o) => o.id === it.answer), `${act}: resposta fora das opções`);
      assert.ok(it.explain.length > 10 && it.prompt.length > 5);
      assert.ok(new Set(it.options.map((o) => o.id)).size === it.options.length);
      if (it.scene) assert.ok(sceneSvg(it.scene).startsWith('<svg'));
    }
  }
  assert.throws(() => buildSession('inexistente', 'x'));
});

test('faltas: a resposta certa sempre bate com as evidências e com as regras do jogo (100 sessões)', () => {
  const agg = ['entrada por trás', 'alta velocidade', 'entrada imprudente'];
  const seen = new Set();
  for (let i = 0; i < 100; i++) {
    for (const it of buildSession('fouls', `s${i}`).items) {
      const n = agg.filter((e) => it.evidence.includes(e)).length;
      const tactical = it.evidence.some((e) => e.startsWith('falta tática'));
      const persistent = it.evidence.includes('reincidente: 3ª falta');
      const area = it.evidence.includes('dentro da área');
      seen.add(it.answer);
      assert.equal(area || it.answer === 'play_on' || it.answer === 'dive_y' || it.options[1].id === 'foul', true);
      if (it.answer === 'foul') assert.ok(n <= 1 && !tactical && !persistent, JSON.stringify(it.evidence));
      if (it.answer === 'foul_y') assert.ok(n === 2 || (tactical && !it.evidence.includes('falta tática: evitou chance clara de gol')) || persistent, JSON.stringify(it.evidence));
      if (it.answer === 'foul_r') assert.ok(n === 3 || it.evidence.includes('falta tática: evitou chance clara de gol'), JSON.stringify(it.evidence));
      if (it.answer.startsWith('pen')) {
        assert.ok(area);
        if (it.answer === 'pen_y') assert.equal(n, 2);
        if (it.answer === 'pen_r') assert.equal(n, 3);
        if (it.answer === 'pen') assert.ok(n <= 1 || it.evidence.includes('mão na bola'));
      }
      if (it.answer === 'dive_y') assert.ok(it.evidence.includes('sem contato') || it.evidence.includes('queda exagerada'));
      if (it.answer === 'play_on') assert.ok(it.evidence.includes('bola jogada primeiro') || it.evidence.includes('braço junto ao corpo'));
      assert.equal(it.options.some((o) => o.id.startsWith('pen')), area);
    }
  }
  assert.deepEqual([...seen].sort(), ['dive_y', 'foul', 'foul_r', 'foul_y', 'pen', 'pen_r', 'pen_y', 'play_on']);
});

test('impedimento: a resposta confere com a regra da simulação (PlayerAI.offsideInfo) em 100 sessões', () => {
  let offs = 0;
  let legal = 0;
  for (let i = 0; i < 100; i++) {
    for (const it of buildSession('offside', `s${i}`).items) {
      const sc = it.scene;
      const att = sc.players.find((p) => p.label === 'A');
      // O exercício usa x de 0 a 320 com o meio em 160; o jogo usa o meio do campo real. Só muda a origem, as margens são iguais.
      const shift = FIELD_RECT.cx - sc.half;
      const passer = { team: 'a', attackDir: 1, x: sc.ball + shift };
      const others = sc.players.filter((p) => p.team === 'def').map((p) => ({ team: 'b', x: p.x + shift }));
      const a = { team: 'a', x: att.x + shift };
      const info = offsideInfo(passer, [passer, a, ...others], sc.ball + shift);
      const game = info.offside.some((e) => e.player === a);
      assert.equal(it.answer === 'offside', game, `${JSON.stringify(sc)} ${it.explain}`);
      assert.equal(isOffsidePosition(att.x, sc.line, sc.ball), game);
      if (game) offs++;
      else legal++;
    }
  }
  assert.ok(offs > 100 && legal > 100, `${offs} impedimentos, ${legal} legais`);
});

test('posicionamento: a melhor opção é a mais perto do ponto ideal, dentro do campo, com letras únicas', () => {
  for (let i = 0; i < 60; i++) {
    for (const it of buildSession('position', `p${i}`).items) {
      const sc = it.scene;
      assert.equal(new Set(sc.spots.map((s) => s.letter)).size, 4);
      assert.ok(sc.spots.every((s) => s.x >= 12 && s.x <= 308 && s.y >= 8 && s.y <= 142));
      const ideal = idealSpot(sc.ball, sc.dir);
      const best = [...sc.spots].sort((a, b) => Math.hypot(a.x - ideal.x, a.y - ideal.y) - Math.hypot(b.x - ideal.x, b.y - ideal.y))[0];
      assert.equal(best.letter, it.answer);
    }
  }
});

test('VAR: 3 situações em que pode intervir e 2 em que não; confronto e regras vêm dos bancos', () => {
  for (let i = 0; i < 40; i++) {
    const s = buildSession('var', `v${i}`);
    assert.equal(s.items.filter((it) => it.answer === 'yes').length, 3);
    for (const it of s.items) assert.equal(it.answer === 'yes', VAR_BANK.find((b) => b.q === it.prompt).yes);
  }
  for (const act of ['control', 'rules']) {
    const s = buildSession(act, 'z');
    assert.equal(new Set(s.items.map((i) => i.prompt)).size, 5, 'sem pergunta repetida');
  }
});

test('pontuação: cada acerto vale 1, a sessão perfeita ganha bônus e errar tudo não ganha nada', () => {
  const s = buildSession('rules', 'k');
  assert.deepEqual(scoreSession(s, perfect(s)), { correct: 5, total: 5, xp: SESSION_XP + PERFECT_BONUS, detail: s.items.map((i) => ({ ok: true, chosen: i.answer, answer: i.answer })) });
  const half = scoreSession(s, [s.items[0].answer, s.items[1].answer, 'x', 'x', null]);
  assert.deepEqual([half.correct, half.xp], [2, Math.round((SESSION_XP * 2) / 5)]);
  assert.equal(scoreSession(s, []).xp, 0);
});

test('aplicar a sessão: soma pontos, XP pequeno da carreira, limite por rodada e sem repetição', () => {
  const c = createCareer('Ana', 1);
  assert.equal(c.training.sessions, 0);
  assert.equal(sessionsLeft(c), SESSIONS_PER_WEEK);
  const s1 = buildSession('fouls', sessionSeed(c, 'fouls'));
  const r1 = applySession(c, s1, perfect(s1));
  assert.ok(r1.ok && r1.result.xp === SESSION_XP + PERFECT_BONUS);
  assert.equal(c.training.attrs.fouls, 30);
  assert.equal(c.xp, CAREER_XP_PER_SESSION);
  assert.equal(r1.levelUp, null);
  assert.deepEqual(applySession(c, s1, perfect(s1)), { ok: false, reason: 'duplicate' });
  assert.equal(c.training.attrs.fouls, 30, 'repetir não paga de novo');

  const s2 = buildSession('offside', sessionSeed(c, 'offside'));
  assert.ok(s2.id !== s1.id);
  const r2 = applySession(c, s2, perfect(s2));
  assert.ok(r2.ok);
  assert.equal(sessionsLeft(c), 0);
  const s3 = buildSession('rules', sessionSeed(c, 'rules'));
  assert.deepEqual(applySession(c, s3, perfect(s3)), { ok: false, reason: 'limit' });
  assert.equal(c.training.sessions, 2);
  assert.equal(c.training.history.length, 2);
  assert.equal(c.xp, CAREER_XP_PER_SESSION * 2);

  skipWeek(c); // nova rodada: as sessões voltam
  assert.equal(sessionsLeft(c), SESSIONS_PER_WEEK);
  const s4 = buildSession('rules', sessionSeed(c, 'rules'));
  assert.ok(applySession(c, s4, perfect(s4)).ok);
});

test('subir de nível é avisado e o histórico guarda só as últimas sessões', () => {
  const c = createCareer('Ana', 2);
  c.training.attrs.position = 20; // 20 + 30 = 50: passa do nível 1 (40)
  const s = buildSession('position', 'a1');
  const r = applySession(c, s, perfect(s));
  assert.deepEqual(r.levelUp, { attr: 'position', from: 0, to: 1 });
  for (let i = 0; i < HISTORY_LIMIT + 5; i++) {
    c.training.week = { key: '', used: 0 };
    const x = buildSession('var', `h${i}`);
    applySession(c, x, perfect(x));
  }
  assert.equal(c.training.history.length, HISTORY_LIMIT);
  assert.equal(c.training.history[0].id, `var:h${HISTORY_LIMIT + 4}`);
});

test('efeitos dos atributos: números explícitos e sem efeito por padrão', () => {
  const none = trainingEffects(null);
  assert.deepEqual([none.positionSpeedMul, none.foulWindowMul, none.offsideWindowMul, none.tensionDecayMul, none.errorTensionMul, none.varTag, none.ruleHint, none.agravantes], [1, 1, 1, 1, 1, false, false, false]);
  const c = createCareer('Ana', 3);
  c.training.attrs = { fouls: 100, offside: 180, position: 400, var: 40, control: 280, rules: 400 }; // níveis 2, 3, 5, 1, 4, 5
  const e = trainingEffects(c);
  assert.deepEqual(e.levels, { fouls: 2, offside: 3, position: 5, var: 1, control: 4, rules: 5 });
  assert.ok(Math.abs(e.positionSpeedMul - 1.2) < 1e-9 && Math.abs(e.foulWindowMul - 1.2) < 1e-9 && Math.abs(e.offsideWindowMul - 1.3) < 1e-9);
  assert.ok(Math.abs(e.tensionDecayMul - 1.6) < 1e-9 && Math.abs(e.errorTensionMul - 0.84) < 1e-9);
  assert.deepEqual([e.varTag, e.ruleHint, e.agravantes], [false, true, true]);
  c.training.attrs.var = 100;
  assert.equal(trainingEffects(c).varTag, true);
});

test('na partida: tempo para apitar e clima seguem o treino, sem mudar a resposta certa', () => {
  const play = (eff) => {
    const m = createMatch({ seed: 4, durationMs: standard });
    for (let i = 0; i < 60 * 30 && m.sim.state !== 'playing'; i++) m.advance('manual');
    if (eff) m.dec.setTraining(eff);
    const mk = (type) => {
      let inc = null;
      m.events.once('incident-registered', (i) => (inc = i));
      const off = m.players.find((p) => p.team === 'away' && p.role === 'DEF');
      const vic = m.players.find((p) => p.team === 'home' && p.role === 'FWD');
      m.sim.registerIncident({ type, level: 'light', offender: off, victim: vic, evidence: ['contato antes da bola'], contact: true });
      return inc;
    };
    return { m, foul: mk(INCIDENT.LIGHT_FOUL), offside: mk(INCIDENT.OFFSIDE) };
  };
  const base = play(null);
  const c = createCareer('Ana', 4);
  c.training.attrs = { fouls: 280, offside: 100, position: 0, var: 0, control: 280, rules: 0 };
  const eff = trainingEffects(c);
  const trained = play(eff);
  assert.ok(trained.foul.expiresAt - trained.foul.time > base.foul.expiresAt - base.foul.time);
  assert.ok(Math.abs((trained.foul.expiresAt - trained.foul.time) / (base.foul.expiresAt - base.foul.time) - 1.4) < 1e-6);
  assert.ok(Math.abs((trained.offside.expiresAt - trained.offside.time) / (base.offside.expiresAt - base.offside.time) - 1.2) < 1e-6);
  assert.deepEqual(trained.foul.expected, base.foul.expected, 'a resposta certa não muda');
  // Controle de jogo: o clima esfria mais rápido e erros esquentam menos.
  const a = base.m.dec.mood;
  const b = trained.m.dec.mood;
  a.add(50);
  b.add(50);
  a.update(60000);
  b.update(60000);
  assert.ok(b.tension < a.tension, `${b.tension} < ${a.tension}`);
  const miss = { type: 'light_foul', errors: ['FOUL_MISSED'], correct: false, evidence: [], offender: { team: 'away' }, victim: { team: 'home' }, actual: { foulCalled: false, cards: [] }, expected: { foul: true } };
  const x = new (a.constructor)(0);
  const y = new (a.constructor)(0);
  y.setTraining({ decayMul: 1.6, errorMul: 0.84 });
  x.onDecision({ ...miss });
  y.onDecision({ ...miss });
  assert.ok(y.tension < x.tension && Math.abs(y.tension / x.tension - 0.84) < 1e-9);
});

test('dicas do painel: regra geral por tipo de lance, nunca a resposta', () => {
  for (const type of Object.values(INCIDENT)) assert.ok(ruleHintFor({ type, evidence: [] }).length > 20, type);
  assert.ok(ruleHintFor({ type: INCIDENT.LIGHT_FOUL, subtype: 'handball' }).includes('Braço'));
  assert.ok(ruleHintFor({ type: INCIDENT.OFFSIDE }).includes('penúltimo defensor'));
  assert.equal(ruleHintFor(null), '');
  for (const type of Object.values(INCIDENT)) assert.ok(!/amarelo para o jogador|vermelho para o jogador/.test(ruleHintFor({ type })), 'não diz o cartão deste lance');
});

test('relatório: cada recomendação aponta a atividade do centro de treinamento', () => {
  const E = (over) => ({ incidentId: 1, type: 'light_foul', level: 'light', time: 1, clock: '10:00', period: 1, refDistance: 20, offender: { team: 'away', number: 9, name: 'J9' }, victim: { team: 'home', number: 10, name: 'J10' }, evidence: ['contato antes da bola'], expected: { foul: true, card: null }, actual: { foulCalled: false, cards: [], advantage: null }, errors: ['FOUL_MISSED'], correct: false, ...over });
  const log = [E({}), E({ type: 'offside', incidentId: 2, evidence: ['x'] })];
  const grade = gradeMatch(log);
  const r = buildReport({ log, grade, facts: matchFacts(log) });
  assert.ok(r.recommendations.length >= 2);
  assert.ok(r.recommendations.every((x) => IDS.includes(x.activity)));
  assert.equal(r.recommendations.find((x) => x.id === 'faltas').activity, 'fouls');
  assert.equal(r.recommendations.find((x) => x.id === 'impedimento').activity, 'offside');
});

test('salvamento: carreira nova tem treino zerado e a migração v8 -> v9 não concede nada', () => {
  const c = createCareer('Ana', 5);
  assert.deepEqual(c.training, emptyTraining());
  const old = JSON.parse(JSON.stringify(c));
  old.version = 8;
  delete old.training;
  const r = migrateCareer(old);
  assert.ok(!r.error && r.migrated);
  assert.equal(r.career.version, CAREER_VERSION);
  assert.deepEqual(r.career.training, emptyTraining());
  assert.equal(migrateCareer(JSON.parse(JSON.stringify(r.career))).migrated, false);
  const broken = { ...emptyTraining(), attrs: { fouls: 'x' }, history: 'nada', week: null };
  const d = { training: broken };
  ensureTraining(d);
  assert.equal(d.training.attrs.fouls, 0);
  assert.deepEqual(d.training.history, []);
});
