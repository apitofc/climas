import test from 'node:test';
import assert from 'node:assert/strict';
import { HighlightPlanner, isShotImage, isControversial, finalizeShots, findFeud, trimImages, MAX_SHOTS, MIN_GAP_MS, MAX_IMAGE_CHARS, MAX_STORED_IMAGES } from '../src/systems/Highlights.js';
import { createCareer, applyMatch } from '../src/systems/CareerSystem.js';

const IMG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQ';
const P = (team, n, name = `J${n}`) => ({ team, number: n, name });
let id = 0;
function entry(over = {}) {
  id += 1;
  return {
    incidentId: id, type: 'light_foul', level: 'light', time: id * 1000, clock: `${10 + id}:00`, period: 1, refDistance: 20,
    offender: P('away', 9), victim: P('home', 10), evidence: ['contato antes da bola'],
    expected: { foul: true, card: null, restart: 'free_kick', cardTarget: null, advantageAllowed: true },
    actual: { foulCalled: true, cards: [], advantage: null, decided: true },
    errors: [], notes: [], correct: true, ...over,
  };
}
const ignored = (over = {}) => entry({ actual: { foulCalled: false, cards: [], advantage: null, decided: true }, errors: ['FOUL_MISSED'], correct: false, ...over });
const base = { clock: '23:10', period: 1, score: { home: 1, away: 0 } };

test('planejador: limite por partida, intervalo entre prints e prioridade', () => {
  const p = new HighlightPlanner();
  assert.equal(p.reserve({ kind: 'qualquer' }, 0), null, 'tipo desconhecido não vale');
  assert.ok(p.reserve({ kind: 'controversy', ...base }, 0));
  assert.equal(p.reserve({ kind: 'controversy', ...base }, 5000), null, 'muito perto do anterior');
  assert.ok(p.reserve({ kind: 'red', ...base }, 5000), 'vermelho fura o intervalo');
  assert.equal(p.reserve({ kind: 'controversy', ...base }, 5000 + MIN_GAP_MS + 1), null, 'depois de 2 prints, só os mais importantes');
  assert.ok(p.reserve({ kind: 'goal', ...base }, 100000));
  assert.ok(p.reserve({ kind: 'goal', ...base }, 200000));
  assert.equal(p.shots.length, MAX_SHOTS);
  assert.equal(p.reserve({ kind: 'red', ...base }, 300000), null, 'no máximo 4 por partida');
});

test('imagem válida: só JPEG em base64 e até o tamanho máximo', () => {
  assert.ok(isShotImage(IMG));
  assert.ok(!isShotImage('http://exemplo.com/x.jpg') && !isShotImage('data:image/png;base64,AAA') && !isShotImage(null) && !isShotImage(''));
  assert.ok(!isShotImage(IMG + 'A'.repeat(MAX_IMAGE_CHARS)));
});

test('lance polêmico: erro grave em lance sério ou dois erros; apito sem lance e gol não contam', () => {
  assert.ok(isControversial(ignored({ type: 'serious_foul' })));
  assert.ok(isControversial(ignored({ type: 'penalty' })));
  assert.ok(isControversial(entry({ errors: ['FOUL_MISSED', 'CARD_MISSED'], correct: false })));
  assert.ok(!isControversial(ignored()), 'falta leve ignorada não rende print');
  assert.ok(!isControversial(entry()));
  assert.ok(!isControversial({ type: 'unnecessary_whistle', errors: ['WHISTLE_UNNECESSARY'] }));
  assert.ok(!isControversial({ type: 'goal_check', errors: ['FOUL_MISSED'] }));
});

test('conferência final: gol anulado, lance que sumiu e imagem ausente não viram publicação; dados do lance vêm da súmula final', () => {
  const e1 = ignored({ type: 'serious_foul', incidentId: 100 });
  const e2 = entry({ type: 'penalty', incidentId: 101, correct: true });
  const log = [e1, e2];
  const shots = [
    { kind: 'goal', team: 'home', image: IMG, ...base },
    { kind: 'goal', team: 'home', image: IMG, ...base, clock: '40:00' },
    { kind: 'goal', team: 'away', image: null, ...base },
    { kind: 'controversy', incidentId: 100, image: IMG, ...base },
    { kind: 'controversy', incidentId: 999, image: IMG, ...base },
    { kind: 'penalty', incidentId: 101, image: IMG, ...base },
    { kind: 'red', player: 'J9 (#9)', team: 'away', image: IMG, ...base },
    { kind: 'var', incidentId: 100, image: IMG, ...base },
    { kind: 'var', incidentId: 555, image: IMG, ...base },
  ];
  const reviews = [{ incidentId: 100, label: 'Falta grave', kind: 'change', finalCorrect: false }];
  const out = finalizeShots(shots, log, { home: 1, away: 0 }, reviews);
  assert.equal(out.filter((s) => s.kind === 'goal').length, 1, 'placar final tem 1 gol: o outro foi anulado');
  assert.equal(out.find((s) => s.kind === 'goal').clock, '40:00', 'fica o gol mais recente');
  const c = out.find((s) => s.kind === 'controversy');
  assert.equal(c.correct, false);
  assert.ok(c.errors.length && c.label === 'Falta grave');
  assert.ok(!out.some((s) => s.kind === 'controversy' && s.clock === undefined) && out.filter((s) => s.kind === 'controversy').length === 1, 'incidente que não está na súmula some');
  assert.equal(out.find((s) => s.kind === 'penalty').correct, true);
  assert.ok(out.find((s) => s.kind === 'red').player.includes('J9'));
  assert.equal(out.filter((s) => s.kind === 'var').length, 1);
  assert.equal(out.find((s) => s.kind === 'var').correct, false);
  assert.ok(out.every((s) => isShotImage(s.image)));
});

test('placar final zerado: nenhum print de gol sobra (todos os gols foram anulados)', () => {
  const shots = [{ kind: 'goal', team: 'home', image: IMG, ...base }, { kind: 'goal', team: 'away', image: IMG, ...base }];
  assert.equal(finalizeShots(shots, [], { home: 0, away: 0 }).length, 0);
  assert.equal(finalizeShots(shots, [], { home: 1, away: 0 }).length, 1);
});

test('rixa: mesmos dois jogadores de times diferentes em 2 ou mais lances reais', () => {
  const log = [entry(), entry({ offender: P('home', 10), victim: P('away', 9), type: 'simulation', level: 'none', expected: { foul: false, card: 'yellow', cardTarget: 'victim' }, actual: { foulCalled: false, cards: [{ team: 'away', number: 9, name: 'J9', color: 'yellow' }], advantage: null, decided: true } }), entry({ offender: P('away', 5), victim: P('home', 7) })];
  const f = findFeud(log);
  assert.ok(f);
  assert.deepEqual([f.a.number, f.b.number, f.count, f.cards], [10, 9, 2, 1]);
  assert.ok(f.labels.length === 2);
  assert.equal(findFeud([entry(), entry({ offender: P('away', 5), victim: P('home', 7) })]), null, 'lances com jogadores diferentes não formam rixa');
  assert.equal(findFeud([entry({ offender: P('away', 9), victim: P('away', 4) }), entry({ offender: P('away', 9), victim: P('away', 4) })]), null, 'mesmo time não é rixa');
  assert.equal(findFeud([{ type: 'goal_check', offender: P('home', 1, 'equipe'), victim: P('away', 2, 'equipe'), actual: { cards: [] } }, { type: 'goal_check', offender: P('home', 1, 'equipe'), victim: P('away', 2, 'equipe'), actual: { cards: [] } }]), null);
});

test('guardar imagens: só as mais recentes mantêm a imagem e imagens inválidas são descartadas', () => {
  const c = createCareer('Ana', 1);
  c.social = Array.from({ length: MAX_STORED_IMAGES + 3 }, (_, i) => ({ key: `p${i}`, text: 't', image: { src: IMG, alt: 'x' } }));
  c.social.push({ key: 'ruim', text: 't', image: { src: 'http://x/y.jpg' } }, { key: 'semimagem', text: 't' });
  const trimmed = trimImages(c);
  assert.equal(c.social.filter((p) => p.image).length, MAX_STORED_IMAGES);
  assert.ok(trimmed >= 4);
  assert.ok(!c.social.find((p) => p.key === 'ruim').image);
  assert.ok(c.social.every((p) => p.text === 't'), 'o texto continua');
  assert.ok(c.social[0].image, 'a lista é da mais nova para a mais antiga: as primeiras ficam');
});

// ------------------------------------------------------------ na carreira
const FACTS = { decisions: 8, correct: 7, yellow: 0, red: 1, redWrong: 0, fouls: 3, penalties: 1, penaltiesCorrect: 1, penaltiesMissed: 0, wrongCalls: 0, missedFouls: 1, simulationsPunished: 0, simulationsMissed: 0, offsides: 0, offsidesCorrect: 0, offsidesMissed: 0, advantageOk: 0, advantageFailed: 0, whistles: 0 };
const resultOf = (shots, feud = null) => ({ nota: 7, label: 'Bom', categories: [{ label: 'Posicionamento', points: 5, max: 10, ratio: 0.5 }], mistakes: [], hits: [], counts: { unnecessaryWhistles: 0 }, score: { home: 1, away: 0 }, extras: FACTS, shots, feud });
const fx = (home, away, matchId) => ({ competitionId: 'varzea', homeId: home, awayId: away, importance: 1, matchId, duration: 'standard' });

test('na carreira: cada print vira uma publicação com a imagem e a legenda feita só com os dados do lance', () => {
  const c = createCareer('Ana', 2);
  const shots = [
    { kind: 'goal', team: 'home', scorer: 'Moura (#9)', image: IMG, ...base },
    { kind: 'red', team: 'away', player: 'Silva (#4)', image: IMG, ...base, clock: '30:00' },
    { kind: 'controversy', label: 'Falta grave', correct: false, errors: ['falta não marcada'], image: IMG, ...base, clock: '40:00' },
    { kind: 'penalty', label: 'Pênalti', correct: true, errors: [], image: IMG, ...base, clock: '50:00' },
    { kind: 'goal', team: 'home', image: 'http://externa/x.jpg', ...base },
  ];
  applyMatch(c, fx('tamarindo', 'moinho', 'h1'), resultOf(shots));
  const posts = c.social.filter((p) => p.image);
  assert.equal(posts.length, 4, 'imagem inválida é ignorada');
  assert.ok(posts.every((p) => p.matchId === 'h1' && isShotImage(p.image.src) && p.image.alt));
  const goal = posts.find((p) => p.image.kind === 'goal');
  assert.ok(goal.text.startsWith('GOL! ') && goal.text.includes('Moura (#9)') && goal.author.kind === 'clube');
  const red = posts.find((p) => p.image.kind === 'red');
  assert.ok(red.text.includes('Silva (#4)') && red.author.kind === 'oficial');
  const polemica = posts.find((p) => p.image.kind === 'controversy');
  assert.equal(polemica.technical, true);
  assert.ok(polemica.text.includes('A avaliação técnica apontou: falta não marcada'));
  const penalty = posts.find((p) => p.image.kind === 'penalty');
  assert.equal(penalty.technical, false);
  assert.ok(penalty.text.includes('considerou a decisão correta'));
  assert.ok(c.social.filter((p) => !p.image).length >= 3, 'as publicações de sempre continuam');
});

test('rixa só aparece em clássico, com notícia e publicação; fora de clássico não há rixa', () => {
  const feud = { a: P('home', 10, 'Moura'), b: P('away', 9, 'Silva'), count: 3, labels: ['falta leve', 'simulação'], cards: 1 };
  const c = createCareer('Ana', 3);
  applyMatch(c, fx('tamarindo', 'jaqueira', 'd1'), resultOf([], feud)); // Clássico da Várzea
  const post = c.social.find((p) => p.key === 'd1:post:feud');
  assert.ok(post && post.technical === false && post.text.includes('Clássico da Várzea') && post.text.includes('Moura') && post.text.includes('3 vezes'));
  const news = c.news.find((n) => n.key === 'd1:news:feud');
  assert.ok(news && news.category === 'lance' && news.matchId === 'd1' && news.tone === 'negative');

  const d = createCareer('Ana', 4);
  applyMatch(d, fx('tamarindo', 'moinho', 'd2'), resultOf([], feud));
  assert.ok(!d.social.some((p) => p.key === 'd2:post:feud') && !d.news.some((n) => n.key === 'd2:news:feud'));
  const e = createCareer('Ana', 5);
  applyMatch(e, fx('tamarindo', 'jaqueira', 'd3'), resultOf([], null));
  assert.ok(!e.social.some((p) => p.key === 'd3:post:feud'));
});

test('sem duplicar e sem estourar o espaço: reprocessar não repete e só as 14 imagens mais recentes ficam', () => {
  const c = createCareer('Ana', 6);
  const mk = (n) => Array.from({ length: 4 }, (_, i) => ({ kind: 'goal', team: 'home', image: IMG, ...base, clock: `${10 + i}:00` }));
  applyMatch(c, fx('tamarindo', 'moinho', 'm1'), resultOf(mk(0)));
  const count = c.social.length;
  assert.equal(applyMatch(c, fx('tamarindo', 'moinho', 'm1'), resultOf(mk(0))), null);
  assert.equal(c.social.length, count);
  for (let i = 2; i <= 6; i++) applyMatch(c, fx('tamarindo', 'moinho', `m${i}`), resultOf(mk(i)));
  assert.equal(c.social.filter((p) => p.image).length, MAX_STORED_IMAGES);
  const newest = c.social.find((p) => p.image);
  assert.ok(newest.matchId === 'm6', 'as imagens mais novas são as que ficam');
});
