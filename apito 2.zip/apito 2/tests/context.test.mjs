import test from 'node:test';
import assert from 'node:assert/strict';
import { createCareer, applyMatch, migrateCareer, CAREER_VERSION } from '../src/systems/CareerSystem.js';
import { xpBreakdown, repBreakdown } from '../src/systems/ProgressionSystem.js';
import { findFixture } from '../src/systems/CalendarSystem.js';
import { getClub } from '../src/data/competitions.js';
import { RIVALRIES, rivalryOf, matchContext, eventsForWeek, criticismEvent } from '../src/systems/ContextSystem.js';
import { varFacts } from '../src/systems/RefereeGrading.js';
import { publicImage } from '../src/systems/CommsSystem.js';
import { createMatch } from './helpers/harness.mjs';

const BASE_FACTS = {
  decisions: 10, correct: 9, yellow: 0, red: 0, redWrong: 0, fouls: 3, penalties: 0, penaltiesCorrect: 0, penaltiesMissed: 0, wrongCalls: 0,
  missedFouls: 0, simulationsPunished: 0, simulationsMissed: 0, offsides: 0, offsidesCorrect: 0, offsidesMissed: 0, advantageOk: 0, advantageFailed: 0, whistles: 0,
};
const result = (nota, over = {}) => ({
  nota,
  label: nota >= 7.5 ? 'Muito bom' : nota >= 5 ? 'Regular' : 'Precisa melhorar',
  categories: [{ label: 'Posicionamento', points: 4, max: 10, ratio: 0.4 }, { label: 'Decisões corretas', points: 27, max: 30, ratio: 0.9 }],
  mistakes: [],
  hits: [],
  counts: { unnecessaryWhistles: 0 },
  score: { home: 1, away: 0 },
  extras: { ...BASE_FACTS },
  ...over,
});
// Partida avulsa (sem jogo do calendário) entre dois clubes, para controlar a rivalidade.
const playVs = (career, home, away, res, id) =>
  applyMatch(career, { competitionId: 'varzea', homeId: home, awayId: away, importance: 1, matchId: id, duration: 'standard' }, res);
const grave = (clock) => ({ severity: 3, errors: ['falta não marcada'], clock, label: 'Pênalti', actual: 'nada', expected: 'pênalti' });
const review = (over = {}) => ({ id: 1, incidentId: 1, incidentType: 'penalty', label: 'Pênalti', clock: '30:00', period: 1, eligible: true, kind: 'change', initial: 'Nada marcado (o jogo segue)', final: 'Pênalti marcado', reason: 'Decisão corrigida na revisão.', finalCorrect: true, ...over });

// ------------------------------------------------------------ rivalidades e pressão
test('rivalidades: todos os clubes existem e cada par aparece uma vez', () => {
  const seen = new Set();
  for (const r of RIVALRIES) {
    assert.equal(r.clubs.length, 2);
    for (const id of r.clubs) assert.ok(getClub(id), `clube desconhecido: ${id}`);
    const key = [...r.clubs].sort().join('|');
    assert.ok(!seen.has(key), 'par repetido');
    seen.add(key);
  }
  assert.equal(rivalryOf('tamarindo', 'jaqueira').id, 'varzea');
  assert.equal(rivalryOf('jaqueira', 'tamarindo').id, 'varzea');
  assert.equal(rivalryOf('tamarindo', 'moinho'), null);
});

test('pressão: sem fatores é zero; clássico, final e jogo anterior polêmico somam; o teto é 3', () => {
  const c = createCareer('Ana', 5);
  assert.equal(matchContext(c, { competitionId: 'varzea', homeId: 'tamarindo', awayId: 'moinho', stage: 'Rodada 1', week: 1 }).level, 0);
  const derby = matchContext(c, { competitionId: 'varzea', homeId: 'tamarindo', awayId: 'jaqueira', stage: 'Rodada 1', week: 1 });
  assert.equal(derby.level, 1);
  assert.deepEqual(derby.tags.map((t) => t.id), ['rivalry']);
  const final = matchContext(c, { competitionId: 'copanacional', homeId: 'titas', awayId: 'realhorizonte', stage: 'Final', week: 5 });
  assert.ok(final.level >= 3 && final.tags.some((t) => t.id === 'final') && final.tags.some((t) => t.id === 'rivalry'));
  c.history.unshift({ graves: 2, nota: 4 });
  assert.ok(matchContext(c, { competitionId: 'varzea', homeId: 'tamarindo', awayId: 'moinho', stage: 'Rodada 1', week: 1 }).tags.some((t) => t.id === 'controversy'));
  assert.ok(final.level <= 3);
});

test('a pressão não muda a nota nem as recompensas (XP e reputação seguem as regras da Etapa 4)', () => {
  const c = createCareer('Ana', 6);
  c.history.unshift({ graves: 2, nota: 4 }); // aumenta a pressão
  const s = playVs(c, 'tamarindo', 'jaqueira', result(8), 'p1');
  assert.ok(s.pressure.level >= 2);
  assert.equal(s.xpGain, xpBreakdown(8, 1).xp);
  assert.equal(s.repDelta, repBreakdown(8, 1, 0).delta);
  assert.deepEqual(c.history[0].context.tags.sort(), ['controversy', 'rivalry']);
});

// ------------------------------------------------------------ eventos
test('jogo de pressão alta gera evento, notícia e publicação, sem duplicar ao reprocessar', () => {
  const c = createCareer('Ana', 7);
  c.history.unshift({ graves: 2, nota: 4 });
  const s = playVs(c, 'tamarindo', 'jaqueira', result(8), 'p2');
  const ev = c.events.find((e) => e.type === 'high_pressure');
  assert.ok(ev && ev.tone === 'positive' && ev.matchId === 'p2');
  assert.ok(c.news.some((n) => n.key === 'p2:ev:pressure:news' && n.matchId === 'p2'));
  assert.ok(c.social.some((p) => p.key === 'p2:ev:pressure:post'));
  assert.ok(s.events.length >= 1);
  const count = [c.events.length, c.news.length, c.social.length, c.xp, c.rep];
  assert.equal(playVs(c, 'tamarindo', 'jaqueira', result(8), 'p2'), null, 'a mesma partida não é processada duas vezes');
  assert.deepEqual([c.events.length, c.news.length, c.social.length, c.xp, c.rep], count);
});

test('jogo sem pressão alta não cria evento de pressão', () => {
  const c = createCareer('Ana', 8);
  playVs(c, 'tamarindo', 'moinho', result(8), 'q1');
  assert.ok(!c.events.some((e) => e.type === 'high_pressure'));
});

test('revisão técnica só existe com erros graves reais e cita os lances da partida', () => {
  const c = createCareer('Ana', 9);
  playVs(c, 'tamarindo', 'moinho', result(6, { mistakes: [grave('10:00')] }), 'r1');
  assert.ok(!c.events.some((e) => e.type === 'technical_review'), 'um erro grave não basta');
  playVs(c, 'tamarindo', 'moinho', result(4, { mistakes: [grave('11:00'), grave('22:00')] }), 'r2');
  const ev = c.events.find((e) => e.type === 'technical_review');
  assert.ok(ev && ev.matchId === 'r2');
  const mail = c.inbox.find((m) => m.key === 'r2:ev:review:mail');
  assert.ok(mail && mail.lines.some((l) => l.includes('11:00')) && mail.lines.some((l) => l.includes('não são alterados')));
  assert.equal(c.history[0].nota, 4, 'a nota da partida não é alterada pela revisão');
});

test('reconhecimento por desempenho vira registro na carreira (nota 9 ou mais)', () => {
  const c = createCareer('Ana', 10);
  playVs(c, 'tamarindo', 'moinho', result(9.4), 's1');
  assert.ok(c.events.some((e) => e.type === 'recognition' && e.tone === 'positive'));
});

test('críticas públicas: só com imagem crítica, no máximo a cada 3 partidas e sem custo para a carreira', () => {
  const c = createCareer('Ana', 11);
  assert.equal(criticismEvent(c, { matchId: 'c0', season: 1, week: 1, fixtureId: null }).events.length, 0, 'sem notícias, sem evento');
  for (let i = 0; i < 4; i++) c.news.unshift({ key: `k${i}`, category: 'arbitragem', tone: 'negative', variant: 'x' });
  assert.equal(publicImage(c).label, 'Crítica');
  const rep = c.rep;
  const first = criticismEvent(c, { matchId: 'c1', season: 1, week: 1, fixtureId: null });
  assert.equal(first.events.length, 1);
  assert.ok(first.bundle.emails[0].lines.some((l) => l.includes('não altera')));
  assert.equal(c.rep, rep);
  assert.equal(criticismEvent(c, { matchId: 'c1', season: 1, week: 1, fixtureId: null }).events.length, 0, 'mesma partida: sem duplicar');
  assert.equal(criticismEvent(c, { matchId: 'c2', season: 1, week: 1, fixtureId: null }).events.length, 0, 'muito perto do último evento');
});

test('convocação especial: clássico entre as convocações gera um registro e um e-mail, uma única vez', () => {
  const c = createCareer('Ana', 12);
  const w = c.world;
  const fx = w.competitions.varzea.fixtures.find((f) => [f.home, f.away].sort().join() === ['jaqueira', 'tamarindo'].sort().join());
  assert.ok(fx, 'todos os pares se enfrentam na liga de 6 clubes');
  c.events = []; // a semana 1 pode já ter registrado este jogo ao montar as convocações
  w.week = fx.week;
  w.offers = { week: fx.week, items: [{ fixtureId: fx.id, tag: 'Segura', status: 'offered' }], restriction: null };
  const first = eventsForWeek(c);
  assert.equal(first.events.length, 1);
  assert.equal(first.events[0].type, 'special_call');
  assert.ok(first.bundle.emails[0].category === 'convocação' && first.bundle.emails[0].fixtureId === fx.id);
  assert.equal(eventsForWeek(c).events.length, 0, 'segunda chamada não duplica');
  assert.ok(findFixture(w, fx.id));
});

// ------------------------------------------------------------ migração
test('migração v5 -> v6: eventos começam vazios, o resto é preservado e nada é inventado', () => {
  const c = createCareer('Ana', 13);
  playVs(c, 'tamarindo', 'moinho', result(7), 'm1');
  const old = JSON.parse(JSON.stringify(c));
  old.version = 5;
  delete old.events;
  const r = migrateCareer(old);
  assert.ok(!r.error && r.migrated);
  assert.equal(r.career.version, CAREER_VERSION);
  assert.deepEqual(r.career.events, []);
  assert.equal(r.career.history.length, c.history.length);
  assert.equal(r.career.xp, c.xp);
  // Carreira atual (v6) não é migrada de novo.
  const again = migrateCareer(JSON.parse(JSON.stringify(r.career)));
  assert.equal(again.migrated, false);
});

// ------------------------------------------------------------ VAR na carreira
test('varFacts conta revisões, mantidas, alteradas e o desfecho real de cada alteração', () => {
  const f = varFacts([review(), review({ id: 2, finalCorrect: false }), review({ id: 3, kind: 'keep', finalCorrect: true }), review({ id: 4, eligible: false, kind: 'keep', finalCorrect: null })]);
  assert.deepEqual(f, { varReviews: 4, varKept: 2, varChanged: 2, varEligible: 3, varFixed: 1, varWorsened: 1 });
  assert.deepEqual(varFacts(undefined), { varReviews: 0, varKept: 0, varChanged: 0, varEligible: 0, varFixed: 0, varWorsened: 0 });
});

test('o desfecho do VAR chega à carreira: registro auditável, notícia, e-mail e publicações coerentes', () => {
  const c = createCareer('Ana', 14);
  const reviews = [review()];
  playVs(c, 'tamarindo', 'moinho', result(8, { varReviews: reviews, extras: { ...BASE_FACTS, ...varFacts(reviews) } }), 'v1');
  const rec = c.history[0];
  assert.equal(rec.var.reviews, 1);
  assert.equal(rec.var.changed, 1);
  assert.equal(rec.var.audit[0].initial, 'Nada marcado (o jogo segue)');
  assert.equal(rec.var.audit[0].final, 'Pênalti marcado');
  assert.equal(rec.var.audit[0].finalCorrect, true);

  const news = c.news.find((n) => n.key === 'v1:news:var');
  assert.ok(news && news.category === 'lance' && news.tone === 'positive' && news.matchId === 'v1');
  const mail = c.inbox.find((m) => m.key === 'v1:mail:report');
  assert.ok(mail.lines.some((l) => l.startsWith('VAR: 1 revisão, 1 decisão alterada')));
  assert.ok(c.social.some((p) => p.key === 'v1:post:var-official' && p.tag === 'dado oficial'));
  assert.ok(c.social.some((p) => p.key === 'v1:post:var-debate' && p.tag === 'opinião'));
});

test('alteração que não corrige o erro gera notícia negativa; manter a decisão gera notícia neutra', () => {
  const a = createCareer('Ana', 15);
  const worse = [review({ finalCorrect: false })];
  playVs(a, 'tamarindo', 'moinho', result(6, { varReviews: worse, extras: { ...BASE_FACTS, ...varFacts(worse) } }), 'w1');
  assert.equal(a.news.find((n) => n.key === 'w1:news:var').tone, 'negative');

  const b = createCareer('Ana', 16);
  const kept = [review({ kind: 'keep', initial: 'Falta marcada', final: 'Falta marcada', finalCorrect: true })];
  playVs(b, 'tamarindo', 'moinho', result(7, { varReviews: kept, extras: { ...BASE_FACTS, ...varFacts(kept) } }), 'w2');
  const n = b.news.find((x) => x.key === 'w2:news:var');
  assert.equal(n.tone, 'neutral');
  assert.ok(n.headline.includes('mantém'));
});

test('sem revisão do VAR não há notícia, e-mail nem publicação sobre o VAR e o VAR não entra na imagem pública', () => {
  const c = createCareer('Ana', 17);
  playVs(c, 'tamarindo', 'moinho', result(7), 'n1');
  assert.ok(!JSON.stringify([c.news, c.inbox, c.social]).includes('VAR'));
  assert.equal(c.history[0].var, null);
  const d = createCareer('Ana', 18);
  const reviews = [review()];
  playVs(d, 'tamarindo', 'moinho', result(7, { varReviews: reviews, extras: { ...BASE_FACTS, ...varFacts(reviews) } }), 'n2');
  assert.ok(d.news.filter((n) => n.category === 'arbitragem').every((n) => !n.headline.includes('VAR')));
});

// ------------------------------------------------------------ VAR em partida simulada: auditoria
const FOULS = ['light_foul', 'serious_foul', 'penalty'];
function runUntil(m, pred, mode = 'ignore', max = 60 * 60 * 20) {
  let n = 0;
  while (!pred() && n < max && !m.sim.finished) {
    m.advance(mode);
    n++;
  }
  assert.ok(pred(), 'condição não atingida');
}
const resolvedFoul = (m) => [...m.varSys.infos.values()].find((i) => FOULS.includes(i.incident.type) && i.incident.status === 'resolved' && i.status === 'live' && i.incident.period === m.sim.period);

test('o VAR registra a decisão inicial, a final e o motivo de cada revisão (mantida ou alterada)', () => {
  const m = createMatch({ seed: 3, durationMs: 245000 });
  runUntil(m, () => resolvedFoul(m), 'ignore');
  for (let i = 0; i < 600 && !m.sim.finished; i++) m.advance('ignore');
  const info = resolvedFoul(m);
  const id = info.incident.id;
  assert.equal(m.varSys.audit.length, 0);

  assert.ok(m.varSys.open().ok);
  m.varSys.keepDecision(id);
  assert.equal(m.varSys.audit.length, 1);
  const kept = m.varSys.audit[0];
  assert.equal(kept.kind, 'keep');
  assert.equal(kept.incidentId, id);
  assert.equal(kept.initial, kept.final);
  assert.ok(kept.reason.includes('mantida'));

  const res = m.varSys.alterDecision(id, { foul: true, cards: { offender: null, victim: null } });
  assert.ok(res.ok && res.changed, res.reason);
  assert.equal(m.varSys.audit.length, 2);
  const changed = m.varSys.audit[1];
  assert.equal(changed.kind, 'change');
  assert.equal(changed.initial, 'Nada marcado (o jogo segue)');
  assert.ok(/marcad/.test(changed.final) && changed.final !== changed.initial);
  assert.ok(changed.reason.includes(changed.initial) && changed.reason.includes(changed.final));
  assert.equal(changed.label.length > 0, true);
  assert.deepEqual(m.varSys.audit.map((a) => a.id), [1, 2]);
  assert.equal(m.varSys.stats.kept, 1);
  assert.equal(m.varSys.stats.changed, 1);
});
