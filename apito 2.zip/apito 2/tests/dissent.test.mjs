import test from 'node:test';
import assert from 'node:assert/strict';
import { createMatch, runMatch } from './helpers/harness.mjs';
import { DURATIONS } from '../src/config.js';
import { dissentTrait, profileTags, bookingEdge } from '../src/systems/PlayerProfiles.js';
import { gradeMatch, matchFacts, describeEntry } from '../src/systems/RefereeGrading.js';
import { buildReport, tipFor } from '../src/systems/TechnicalReport.js';
import { errorText } from '../src/systems/MatchRules.js';

const standard = DURATIONS.find((d) => d.id === 'standard').ms;

function scene(seed = 5) {
  const m = createMatch({ seed, durationMs: standard });
  for (let i = 0; i < 60 * 30 && m.sim.state !== 'playing'; i++) m.advance('manual');
  return m;
}
const away = (m) => m.players.filter((p) => p.team === 'away' && p.role !== 'GK');
// Deixa só um candidato a reclamar (os outros do time saem do jogo) e devolve ele.
function soleProtester(m, wanted = (t) => t >= 0.6) {
  const list = away(m);
  const p = list.find((x) => wanted(dissentTrait(x)));
  assert.ok(p, 'o elenco tem alguém com esse perfil');
  for (const o of list) if (o !== p) o.sentOff = true;
  return p;
}
const called = (m, id, p) => ({ id, actual: { foulCalled: true }, offender: p, victim: m.players.find((x) => x.team === 'home' && x.role === 'DEF'), x: 100, y: 100 });
// Tenta até algum lance (de id diferente) fazer o jogador reclamar; devolve o id que funcionou.
function provoke(m, p) {
  for (let id = 1; id < 400; id++) {
    m.dec.lastDissentTime = -Infinity;
    m.dec.maybeDissent(called(m, id, p));
    if (m.dec.dissent) return id;
  }
  return null;
}

test('tendência a reclamar: fixa por jogador, entre 0,1 e 0,9 e diferente de um jogador para outro', () => {
  const m = scene();
  const vals = m.players.map(dissentTrait);
  assert.deepEqual(vals, m.players.map(dissentTrait));
  assert.ok(vals.every((v) => v >= 0.1 && v <= 0.9));
  assert.ok(new Set(vals.map((v) => v.toFixed(3))).size > 15);
  assert.ok(vals.some((v) => v >= 0.6) && vals.some((v) => v < 0.3));
});

test('perfil observado: só mostra o que o jogador fez, com aviso de cartão perto', () => {
  assert.deepEqual(profileTags({}), []);
  assert.deepEqual(profileTags({ suspectFalls: 2, protests: 2, foulsCommitted: 2, warnings: 1 }), ['costuma cair em lances duvidosos', 'reclama muito', 'reincidente em faltas', 'já foi advertido']);
  assert.deepEqual(profileTags({ suspectFalls: 1, protests: 1, foulsCommitted: 1 }), []);
  assert.equal(bookingEdge({}), '');
  assert.ok(bookingEdge({ foulsCommitted: 2 }).includes('próxima falta já vale cartão'));
  assert.ok(bookingEdge({ yellowCards: 1, foulsCommitted: 5 }).includes('próximo é vermelho'));
});

test('reclamação: só depois de falta marcada, só de quem tem o perfil, determinística e com limites', () => {
  const m = scene();
  const p = soleProtester(m);
  const notCalled = called(m, 1, p);
  notCalled.actual.foulCalled = false;
  for (let id = 1; id < 200; id++) m.dec.maybeDissent({ ...notCalled, id });
  assert.equal(m.dec.dissent, null, 'sem falta marcada não há reclamação');

  const id = provoke(m, p);
  assert.ok(id, 'em algum lance ele reclama');
  const d = m.dec.dissent;
  assert.equal(d.player, p);
  assert.ok(['mild', 'strong'].includes(d.level) && d.evidence.length >= 2);
  assert.equal(p.protests, 1);
  assert.ok(m.dec.isDissentOpen());

  // O mesmo lance dá o mesmo resultado (revisão do VAR e recarregar não mudam).
  const again = scene();
  const p2 = soleProtester(again);
  assert.equal(provoke(again, p2), id);

  // Aberta, nova reclamação não abre outra; depois de resolvida vale o intervalo de 60 s e o limite de 2 por jogo.
  const open = m.dec.dissent;
  m.dec.maybeDissent(called(m, id + 1, p));
  assert.equal(m.dec.dissent, open);
  m.dec.resolveDissent('ignore');
  m.sim.time += 1000;
  m.dec.maybeDissent(called(m, id, p));
  assert.equal(m.dec.dissent, null, 'intervalo de 60 s');
  m.dec.lastDissentTime = -Infinity;
  assert.ok(provoke(m, p));
  m.dec.resolveDissent('ignore');
  assert.equal(m.dec.dissentCount, 2);
  m.dec.lastDissentTime = -Infinity;
  for (let k = 1; k < 200; k++) m.dec.maybeDissent(called(m, k, p));
  assert.equal(m.dec.dissent, null, 'no máximo 2 por jogo');

  // Goleiro e quem foi expulso nunca reclamam.
  const g = scene();
  for (const o of away(g)) o.sentOff = true;
  for (let k = 1; k < 200; k++) g.dec.maybeDissent(called(g, k, away(g)[0]));
  assert.equal(g.dec.dissent, null);
});

test('nível: reclamação leve na primeira vez com clima calmo; exagerada com clima quente, repetição ou advertência', () => {
  const mk = (setup) => {
    const m = scene();
    const p = soleProtester(m, (t) => t >= 0.6 && t < 0.8);
    setup(m, p);
    provoke(m, p);
    return m.dec.dissent;
  };
  const mild = mk(() => {});
  assert.equal(mild.level, 'mild');
  assert.ok(mild.evidence.includes('primeira reclamação do jogador') && mild.evidence.includes('tom controlado'));
  assert.equal(mk((m) => m.dec.mood.add(55)).level, 'strong');
  assert.ok(mk((m) => m.dec.mood.add(55)).evidence.includes('clima quente'));
  assert.equal(mk((m, p) => (p.protests = 1)).level, 'strong');
  assert.ok(mk((m, p) => (p.protests = 2)).evidence.some((e) => e.startsWith('reclamação persistente (3ª vez)')));
  const warned = mk((m, p) => (p.warnings = 1));
  assert.equal(warned.level, 'strong');
  assert.ok(warned.evidence.includes('já foi advertido neste jogo'));
  const top = scene();
  const hot = soleProtester(top, (t) => t >= 0.8);
  provoke(top, hot);
  assert.equal(top.dec.dissent.level, 'strong', 'o reclamão de verdade já começa exagerado');
});

test('decidir a reclamação: advertência ou amarelo conforme a gravidade, com erros e efeitos corretos', () => {
  const run = (level, choice) => {
    const m = scene();
    const p = soleProtester(m, (t) => t >= 0.6 && t < 0.8);
    if (level === 'strong') p.protests = 1;
    provoke(m, p);
    assert.equal(m.dec.dissent.level, level);
    const tension = m.dec.mood.tension;
    const n = m.dec.log.length;
    m.dec.resolveDissent(choice);
    assert.equal(m.dec.dissent, null);
    const e = m.dec.log[m.dec.log.length - 1];
    assert.equal(m.dec.log.length, n + 1);
    return { m, p, e, tension };
  };
  let r = run('mild', 'warning');
  assert.deepEqual([r.e.type, r.e.correct, r.e.errors, r.p.warnings, r.e.actual.cards.map((c) => c.color)], ['dissent', true, [], 1, ['warning']]);
  assert.deepEqual([r.e.dissent.level, r.e.dissent.choice, r.e.expected.card], ['mild', 'warning', null]);
  assert.ok(r.m.dec.mood.tension <= r.tension, 'acertar não esquenta');
  r = run('mild', 'ignore');
  assert.deepEqual([r.e.correct, r.e.errors, r.p.warnings], [true, [], 0]);
  r = run('mild', 'yellow');
  assert.deepEqual([r.e.correct, r.e.errors, r.e.actual.cards.map((c) => c.color)], [false, ['CARD_UNWARRANTED'], ['yellow']]);
  assert.equal(r.p.yellowCards, 1);
  assert.ok(r.m.dec.mood.tension > r.tension, 'erro esquenta o clima');
  r = run('strong', 'yellow');
  assert.deepEqual([r.e.correct, r.e.errors, r.e.expected.card, r.e.actual.cards.map((c) => c.color)], [true, [], 'yellow', ['yellow']]);
  assert.ok(r.e.evidence.includes('gestos exagerados'));
  r = run('strong', 'warning');
  assert.deepEqual([r.e.correct, r.e.errors], [false, ['CARD_TOO_LIGHT']]);
  r = run('strong', 'ignore');
  assert.deepEqual([r.e.correct, r.e.errors], [false, ['CARD_MISSED']]);
  assert.equal(errorText('CARD_MISSED', 'dissent') !== undefined, true);
});

test('segundo amarelo por reclamação vira vermelho e o jogador sai do jogo', () => {
  const m = scene();
  const p = soleProtester(m, (t) => t >= 0.6 && t < 0.8);
  p.protests = 1;
  p.yellowCards = 1;
  provoke(m, p);
  m.dec.resolveDissent('yellow');
  assert.ok(p.sentOff || p.yellowCards >= 2);
  const e = m.dec.log[m.dec.log.length - 1];
  assert.ok(e.actual.cards.some((c) => c.color === 'yellow' || c.color === 'red'));
});

test('enquanto a reclamação está aberta o jogo não recomeça; fim de jogo ou revisão do VAR fecham', () => {
  const m = scene();
  const p = soleProtester(m, (t) => t >= 0.6 && t < 0.8);
  provoke(m, p);
  m.dec.stoppage = { reason: 'resolved', timer: 500, incident: { actual: {} } };
  m.dec.update(300);
  m.dec.update(300);
  assert.equal(m.dec.stoppage.timer, 500, 'o relógio da parada espera a decisão');
  const snap = m.dec.captureState();
  m.dec.restoreState(snap);
  assert.equal(m.dec.dissent, null, 'voltar no tempo descarta a reclamação daquele instante');
  assert.equal(m.dec.dissentCount, snap.dissentCount);
  provoke(m, p);
  m.sim.finished = true;
  m.dec.update(16);
  assert.equal(m.dec.dissent, null);
});

test('nota e súmula: reclamação pesa 0,8, aparece com texto certo e conta os cartões, sem virar falta', () => {
  const entry = (over = {}) => ({ incidentId: null, type: 'dissent', level: 'none', time: 1, clock: '33:00', period: 1, refDistance: null, evidence: ['gestos exagerados', 'grita com o árbitro'], offender: { team: 'away', number: 7, name: 'Silva' }, victim: { team: 'home', number: 3, name: 'Lima' }, expected: { foul: false, card: 'yellow', cardTarget: 'offender' }, actual: { foulCalled: false, cards: [{ team: 'away', number: 7, name: 'Silva', color: 'yellow' }], advantage: null, decided: true }, errors: [], notes: [], correct: true, varChanged: false, dissent: { level: 'strong', choice: 'yellow' }, ...over });
  const ok = entry();
  const bad = entry({ actual: { foulCalled: false, cards: [], advantage: null, decided: true }, errors: ['CARD_MISSED'], correct: false, dissent: { level: 'strong', choice: 'ignore' } });
  const d = describeEntry(ok);
  assert.equal(d.label, 'Reclamação');
  assert.equal(d.actual, 'cartão amarelo');
  assert.ok(d.expected.includes('cartão amarelo por reclamação'));
  assert.equal(describeEntry(bad).actual, 'seguiu o jogo');
  const f = matchFacts([ok, bad]);
  assert.deepEqual([f.dissents, f.dissentsRight, f.yellow, f.fouls, f.wrongCalls], [2, 1, 1, 0, 0]);
  const g = gradeMatch([ok, bad]);
  assert.ok(g.nota < 10 && g.mistakes.length === 1 && g.mistakes[0].label === 'Reclamação');
  const mild = entry({ expected: { foul: false, card: null }, dissent: { level: 'mild', choice: 'warning' }, actual: { foulCalled: false, cards: [], decided: true } });
  assert.equal(describeEntry(mild).expected, 'advertência verbal (ou seguir o jogo)');
  assert.equal(describeEntry(mild).actual, 'advertência verbal');
  assert.ok(tipFor(bad).includes('amarelo por reclamação'));
  assert.ok(tipFor(entry({ dissent: { level: 'mild', choice: 'yellow' }, errors: ['CARD_UNWARRANTED'], correct: false })).includes('Cartão aqui seria exagero'));
  const r = buildReport({ log: [bad], grade: gradeMatch([bad]), facts: matchFacts([bad]) });
  const rec = r.recommendations.find((x) => x.id === 'reclamacao');
  assert.ok(rec && rec.activity === 'control' && rec.reason.includes('reclamação mal resolvida'));
});

test('jogando de verdade: reclamações aparecem com variedade e o árbitro perfeito continua sem erros', () => {
  let dissents = 0;
  let mild = 0;
  let strong = 0;
  let errors = 0;
  for (let seed = 1; seed <= 12; seed++) {
    const r = runMatch({ mode: 'perfect', seed, durationMs: standard });
    for (const e of r.dec.log) {
      if (!e.correct) errors++;
      if (e.type !== 'dissent') continue;
      dissents++;
      if (e.dissent.level === 'mild') mild++;
      else strong++;
      assert.ok(e.dissent.choice === (e.dissent.level === 'strong' ? 'yellow' : 'warning'));
    }
    assert.ok(r.dec.dissentCount <= 2);
  }
  assert.equal(errors, 0);
  assert.ok(dissents >= 3 && mild >= 1 && strong >= 1, `${dissents} reclamações (${mild} leves, ${strong} fortes)`);
});
