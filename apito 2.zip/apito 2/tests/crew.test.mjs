import test from 'node:test';
import assert from 'node:assert/strict';
import { createMatch } from './helpers/harness.mjs';
import { FIELD_RECT, DURATIONS } from '../src/config.js';
import {
  generateCrew, ensureCrew, reliability, divergenceChance, communicationLabel, flagFor, consultOptions, consult, benchCalm, crewMatchUpdate, emptyStats,
  MAX_CONSULTS, MAX_BENCH_CALLS, CONSULT_COST, CREW_IDS, VIEW_ZONE,
} from '../src/systems/CrewSystem.js';
import { createCareer, applyMatch, migrateCareer, CAREER_VERSION } from '../src/systems/CareerSystem.js';
import { gradeMatch, matchFacts } from '../src/systems/RefereeGrading.js';
import { buildReport, tipFor } from '../src/systems/TechnicalReport.js';
import { reportToHtml } from '../src/ui/reportHtml.js';
import { INCIDENT } from '../src/systems/MatchRules.js';

const L = FIELD_RECT;
const standard = DURATIONS.find((d) => d.id === 'standard').ms;
const crewWith = (exp, chemistry = 100) => ({ ...generateCrew('x', 0), chemistry, members: { a1: { id: 'a1', name: 'Caio Assis', exp }, a2: { id: 'a2', name: 'Vitor Lima', exp }, fo: { id: 'fo', name: 'Bruno Reis', exp } } });
const inc = (over = {}) => ({ id: 1, type: INCIDENT.OFFSIDE, y: L.top + 10, expected: { foul: true }, ...over });
const rate = (n, fn) => Array.from({ length: n }, (_, i) => fn(i)).filter(Boolean).length / n;

test('fórmulas: confiabilidade de 62% a 92%, hesitação de 30% a 0%, rótulos de comunicação', () => {
  assert.ok(Math.abs(reliability(0) - 0.62) < 1e-9 && Math.abs(reliability(100) - 0.92) < 1e-9 && Math.abs(reliability(500) - 0.92) < 1e-9 && Math.abs(reliability(-5) - 0.62) < 1e-9);
  assert.ok(Math.abs(divergenceChance(0) - 0.3) < 1e-9 && divergenceChance(100) === 0 && Math.abs(divergenceChance(50) - 0.15) < 1e-9);
  assert.deepEqual([communicationLabel(10), communicationLabel(40), communicationLabel(69), communicationLabel(70)], ['Divergente', 'Regular', 'Regular', 'Boa']);
});

test('equipe nova: determinística, 3 membros com nomes diferentes e experiência pelos jogos já apitados', () => {
  const a = generateCrew('semente', 0);
  assert.deepEqual(a, generateCrew('semente', 0));
  assert.notDeepEqual(a.members, generateCrew('outra', 0).members);
  assert.deepEqual(Object.keys(a.members), CREW_IDS);
  assert.equal(new Set(CREW_IDS.map((id) => a.members[id].name)).size, 3);
  assert.ok(CREW_IDS.every((id) => a.members[id].exp >= 18 && a.members[id].exp <= 38));
  const veteran = generateCrew('semente', 10);
  assert.ok(CREW_IDS.every((id) => veteran.members[id].exp >= a.members[id].exp + 29));
  assert.ok(veteran.chemistry > a.chemistry);
  assert.deepEqual(a.stats, emptyStats());
});

test('bandeira: só em lance de impedimento, determinística, pelo lado certo e com a taxa da confiabilidade', () => {
  assert.equal(flagFor(crewWith(50), inc({ type: INCIDENT.LIGHT_FOUL }), 's'), null);
  assert.equal(flagFor(crewWith(50), inc({ type: INCIDENT.CHALLENGE }), 's'), null);
  const f = flagFor(crewWith(50), inc(), 's');
  assert.deepEqual(f, flagFor(crewWith(50), inc(), 's'));
  assert.equal(f.who, 'a1');
  assert.equal(flagFor(crewWith(50), inc({ y: L.bottom - 10 }), 's').who, 'a2');
  assert.equal(f.truth, true);

  const real = (exp) => rate(1000, (i) => flagFor(crewWith(exp), inc({ id: i }), 'seed').raised);
  const fake = (exp) => rate(1000, (i) => flagFor(crewWith(exp), inc({ id: i, type: INCIDENT.LEGAL_POSITION, expected: { foul: false } }), 'seed').raised);
  assert.ok(Math.abs(real(0) - 0.62) < 0.05, `${real(0)}`);
  assert.ok(Math.abs(real(100) - 0.92) < 0.04, `${real(100)}`);
  assert.ok(Math.abs(fake(0) - 0.19) < 0.04, `${fake(0)}`);
  assert.ok(Math.abs(fake(100) - 0.04) < 0.03, `${fake(100)}`);
  const w = flagFor(crewWith(0), inc({ id: 7, type: INCIDENT.LEGAL_POSITION, expected: { foul: false } }), 'seed');
  assert.equal(w.wrong, w.raised, 'levantar a bandeira sem impedimento é erro');
});

test('consultar: impedimento sempre, falta só perto da linha lateral, no máximo 3 por partida', () => {
  assert.deepEqual(consultOptions(inc(), 0), { available: true, who: 'a1', near: true });
  const far = inc({ type: INCIDENT.LIGHT_FOUL, y: L.cy });
  const o = consultOptions(far, 0);
  assert.equal(o.available, false);
  assert.ok(o.reason.includes('longe da linha lateral'));
  const near = inc({ type: INCIDENT.LIGHT_FOUL, y: L.bottom - VIEW_ZONE + 5 });
  assert.deepEqual(consultOptions(near, 0), { available: true, who: 'a2', near: true });
  assert.equal(consultOptions(inc(), MAX_CONSULTS).available, false);
  assert.ok(consultOptions(inc(), MAX_CONSULTS).reason.includes(String(MAX_CONSULTS)));
});

test('opinião do assistente: determinística, mais certa com mais experiência, hesita com comunicação ruim', () => {
  const a = consult(crewWith(60, 60), inc(), 0, 's');
  assert.deepEqual(a, consult(crewWith(60, 60), inc(), 0, 's'));
  const variety = new Set(Array.from({ length: 40 }, (_, n) => JSON.stringify(consult(crewWith(60, 60), inc(), n, 's'))));
  assert.ok(variety.size > 1, 'o número da consulta entra no sorteio (às vezes a resposta muda)');
  const acc = (exp) => rate(1500, (i) => consult(crewWith(exp, 100), inc({ id: i }), 0, 'q').correct === true);
  assert.ok(acc(100) > acc(0) + 0.15, `${acc(100)} > ${acc(0)}`);
  assert.ok(Math.abs(acc(0) - (reliability(0) + 0.05)) < 0.05);
  const hes = (chem) => rate(1500, (i) => consult(crewWith(50, chem), inc({ id: i }), 0, 'q').divergent);
  assert.equal(hes(100), 0);
  assert.ok(Math.abs(hes(0) - 0.3) < 0.04, `${hes(0)}`);
  const d = Array.from({ length: 400 }, (_, i) => consult(crewWith(50, 0), inc({ id: i }), 0, 'q')).find((x) => x.divergent);
  assert.ok(d.foul === null && d.correct === null && d.text.includes('hesita'));
  const ok = consult(crewWith(100, 100), inc({ expected: { foul: false }, type: INCIDENT.LEGAL_POSITION }), 0, 'q');
  assert.ok(ok.text.includes('Caio Assis') && /posição|impedimento/.test(ok.text) || ok.text.includes('Caio'));
  // Falta longe da linha lateral: visão pior.
  const farAcc = rate(1500, (i) => consult(crewWith(50, 100), inc({ id: i, type: INCIDENT.LIGHT_FOUL, y: L.cy }), 0, 'q').correct === true);
  const nearAcc = rate(1500, (i) => consult(crewWith(50, 100), inc({ id: i, type: INCIDENT.LIGHT_FOUL, y: L.top + 10 }), 0, 'q').correct === true);
  assert.ok(nearAcc > farAcc + 0.1);
});

test('quarto árbitro: chance de 50% a 90% pela experiência, sempre a mesma resposta', () => {
  assert.deepEqual(benchCalm(crewWith(50), 'home', 0, 's'), benchCalm(crewWith(50), 'home', 0, 's'));
  assert.ok(Math.abs(benchCalm(crewWith(0), 'home', 0, 's').chance - 0.5) < 1e-9 && Math.abs(benchCalm(crewWith(100), 'home', 0, 's').chance - 0.9) < 1e-9);
  const ok = (exp) => rate(1500, (i) => benchCalm(crewWith(exp), 'home', 0, `k${i}`).ok);
  assert.ok(ok(100) > ok(0) + 0.25);
});

test('depois da partida: experiência, entrosamento e estatísticas (com teto de 100)', () => {
  const c = createCareer('Ana', 1);
  const before = JSON.parse(JSON.stringify(c.crew));
  crewMatchUpdate(c, { consults: [{ who: 'a1', followed: true, correct: true, divergent: false }, { who: 'a2', followed: false, correct: true, divergent: false }, { who: 'a2', followed: true, correct: false, divergent: false }, { who: 'a1', followed: false, correct: null, divergent: true }], flagsRaised: 2, flagsWrong: 1, bench: { calls: 2, ok: 1 } });
  assert.equal(c.crew.members.a1.exp, before.members.a1.exp + 8, '6 + 2 pelo conselho certo seguido');
  assert.equal(c.crew.members.a2.exp, before.members.a2.exp + 6);
  assert.equal(c.crew.members.fo.exp, before.members.fo.exp + 6);
  assert.equal(c.crew.chemistry, before.chemistry + 3, 'seguir um conselho errado tira o bônus de entrosamento');
  assert.deepEqual(c.crew.stats, { consults: 4, followedRight: 1, followedWrong: 1, ignoredRight: 1, divergences: 1, flagsRaised: 2, flagsWrong: 1, benchCalls: 2, benchOk: 1 });
  assert.equal(c.crew.matches, 1);
  crewMatchUpdate(c, { consults: [{ who: 'a1', followed: true, correct: true }] });
  assert.equal(c.crew.chemistry, before.chemistry + 3 + 5);
  c.crew.members.a1.exp = 99;
  crewMatchUpdate(c, {});
  assert.equal(c.crew.members.a1.exp, 100);
});

// ------------------------------------------------------------ na partida
function scene(seed, crew = crewWith(100, 100)) {
  const m = createMatch({ seed: 4, durationMs: standard });
  for (let i = 0; i < 60 * 30 && m.sim.state !== 'playing'; i++) m.advance('manual');
  m.dec.setCrew(crew, seed);
  return m;
}
const reg = (m, type, y, extra = {}) => {
  let got = null;
  m.events.once('incident-registered', (i) => (got = i));
  const off = m.players.find((p) => p.team === 'away' && p.role === 'FWD');
  const vic = m.players.find((p) => p.team === 'home' && p.role === 'DEF');
  m.sim.registerIncident({ type, level: 'none', offender: off, victim: vic, evidence: ['x'], contact: type !== INCIDENT.OFFSIDE && type !== INCIDENT.LEGAL_POSITION, at: { x: L.cx + 100, y }, ...extra });
  return got;
};

test('na partida: o lance de impedimento ganha a bandeira do assistente e avisa uma vez', () => {
  const m = scene('flags', crewWith(100, 100));
  const flags = [];
  m.events.on('crew-flag', (f) => flags.push(f));
  const seen = [];
  for (let k = 0; k < 40; k++) {
    m.sim.time += 100;
    const i = reg(m, k % 2 ? INCIDENT.OFFSIDE : INCIDENT.LEGAL_POSITION, k % 3 ? L.top + 10 : L.bottom - 10);
    seen.push(i);
  }
  assert.ok(seen.every((i) => i.crewFlag && ['a1', 'a2'].includes(i.crewFlag.who)));
  assert.equal(flags.length, seen.filter((i) => i.crewFlag.raised).length);
  assert.equal(m.dec.crewLog.flagsRaised, flags.length);
  assert.equal(m.dec.crewLog.flagsWrong, seen.filter((i) => i.crewFlag.raised && i.crewFlag.wrong).length);
  assert.ok(flags.length > 10 && flags.every((f) => f.name));
  const falta = reg(m, INCIDENT.LIGHT_FOUL, L.cy);
  assert.equal(falta.crewFlag, null, 'falta comum não tem bandeira');
  const noCrew = createMatch({ seed: 4, durationMs: standard });
  assert.equal(noCrew.dec.consultOptions({}).available, false, 'sem equipe nada muda');
});

test('na partida: consultar custa clima, só vale uma vez por lance e tem limite por jogo', () => {
  const m = scene('consult', crewWith(100, 100));
  const t0 = m.dec.mood.tension;
  const i1 = reg(m, INCIDENT.OFFSIDE, L.top + 10);
  const r1 = m.dec.consult(i1);
  assert.ok(r1 && r1.text.includes('Caio Assis'));
  assert.equal(m.dec.mood.tension, t0 + CONSULT_COST);
  assert.equal(m.dec.consult(i1), r1, 'segunda consulta no mesmo lance devolve a mesma resposta');
  assert.equal(m.dec.mood.tension, t0 + CONSULT_COST, 'e não cobra de novo');
  assert.equal(m.dec.consultOptions(i1).done, true);
  for (let k = 0; k < MAX_CONSULTS - 1; k++) {
    m.sim.time += 50;
    assert.ok(m.dec.consult(reg(m, INCIDENT.OFFSIDE, L.bottom - 10)));
  }
  const last = reg(m, INCIDENT.OFFSIDE, L.top + 12);
  assert.equal(m.dec.consultOptions(last).available, false);
  assert.equal(m.dec.consult(last), null);
  assert.equal(m.dec.crewSummary().consults.length, MAX_CONSULTS);
  const far = reg(m, INCIDENT.LIGHT_FOUL, L.cy);
  assert.ok(!m.dec.consultOptions(far).available);
});

test('na súmula: a consulta e a bandeira ficam registradas e dizem se o conselho foi seguido; a nota não muda', () => {
  const m = scene('sumula', crewWith(100, 100));
  const i = reg(m, INCIDENT.OFFSIDE, L.top + 10);
  const res = m.dec.consult(i);
  assert.ok(res.foul === true || res.foul === false);
  // O árbitro decide o contrário do que o assistente disse.
  i.actual.foulCalled = !res.foul;
  m.dec.finalize(i);
  const e = m.dec.log[m.dec.log.length - 1];
  assert.equal(e.crew.consult.followed, false);
  assert.equal(e.crew.consult.foul, res.foul);
  assert.equal(e.crew.flag.who, 'a1');
  assert.equal(m.dec.crewSummary().consults[0].followed, false);

  const j = reg(m, INCIDENT.OFFSIDE, L.bottom - 10);
  const r2 = m.dec.consult(j);
  j.actual.foulCalled = r2.foul === null ? true : r2.foul;
  m.dec.finalize(j);
  const e2 = m.dec.log[m.dec.log.length - 1];
  assert.equal(e2.crew.consult.followed, r2.foul !== null);
  // Nota: igual com ou sem os dados da equipe na súmula.
  const stripped = m.dec.log.map(({ crew, ...rest }) => rest);
  assert.equal(gradeMatch(m.dec.log).nota, gradeMatch(stripped).nota);
});

test('voltar no tempo (VAR) desfaz as consultas feitas depois daquele instante', () => {
  const m = scene('var', crewWith(100, 100));
  const snap = m.dec.captureState();
  m.dec.consult(reg(m, INCIDENT.OFFSIDE, L.top + 10));
  assert.equal(m.dec.crewLog.consults.length, 1);
  m.dec.restoreState(snap);
  assert.equal(m.dec.crewLog.consults.length, 0);
});

test('quarto árbitro: só funciona logo depois que o banco reclama, com limite e efeito no clima', () => {
  // Procura sementes em que o pedido dá certo e em que não dá, para testar as duas respostas.
  const outcomes = new Set();
  for (let s = 0; s < 40 && outcomes.size < 2; s++) {
    const m = scene(`fo${s}`, crewWith(50, 100));
    const msgs = [];
    m.events.on('feedback', (f) => msgs.push(f));
    assert.equal(m.dec.callFourth(), false, 'sem banco reclamando não há o que fazer');
    // Falta real ignorada com o clima quente faz o banco reclamar.
    m.dec.mood.add(45);
    let bench = null;
    m.events.once('bench-protest', (b) => (bench = b));
    const i = reg(m, INCIDENT.LIGHT_FOUL, L.cy, {});
    i.expected = { foul: true, card: null };
    m.dec.finalize(i);
    assert.ok(bench, 'o banco reclamou');
    const heat = m.dec.mood.heatPts[bench.team];
    const tension = m.dec.mood.tension;
    const ok = m.dec.callFourth();
    outcomes.add(ok);
    assert.equal(m.dec.crewLog.bench.calls, 1);
    if (ok) {
      assert.ok(m.dec.mood.heatPts[bench.team] < heat && m.dec.mood.tension < tension);
      assert.equal(m.dec.crewLog.bench.ok, 1);
    } else {
      assert.equal(m.dec.mood.tension, tension);
    }
    assert.equal(m.dec.callFourth(), false, 'a janela fecha depois do pedido');
    // Limite por jogo.
    for (let k = 0; k < MAX_BENCH_CALLS + 1; k++) {
      m.dec.benchWindow = { team: 'home', until: m.sim.time + 1000 };
      m.dec.callFourth();
    }
    assert.equal(m.dec.crewLog.bench.calls, MAX_BENCH_CALLS);
  }
  assert.deepEqual([...outcomes].sort(), [false, true]);
});

// ------------------------------------------------------------ relatório, carreira e salvamento
const E = (over = {}) => ({ incidentId: 1, type: 'offside', level: 'none', time: 1, clock: '10:00', period: 1, refDistance: 20, offender: { team: 'away', number: 9, name: 'J9' }, victim: { team: 'home', number: 10, name: 'J10' }, evidence: ['impedido'], expected: { foul: true, card: null }, actual: { foulCalled: false, cards: [], advantage: null }, errors: ['FOUL_MISSED'], correct: false, ...over });

test('relatório: seção da equipe, dica de bandeira errada e recomendação quando segue conselho errado', () => {
  const log = [E({ crew: { flag: { who: 'a1', raised: false, wrong: false }, consult: { who: 'a1', foul: false, correct: false, divergent: false, followed: true } } })];
  const grade = gradeMatch(log);
  const crew = { consults: [{ who: 'a1', followed: true, correct: false, divergent: false }, { who: 'a2', followed: false, correct: true, divergent: false }], flagsRaised: 2, flagsWrong: 1, bench: { calls: 1, ok: 1 } };
  const r = buildReport({ log, grade, facts: matchFacts(log), crew });
  assert.equal(r.crew.verdict, 'bad');
  assert.ok(r.crew.lines.some((l) => l.includes('2 (0 opinião(ões) certa(s) seguida(s), 1 errada(s) seguida(s), 1 certa(s) ignorada(s)')));
  assert.ok(r.crew.lines.some((l) => l.includes('Bandeiras levantadas: 2, 1 errada(s)')));
  assert.ok(r.crew.lines.some((l) => l.includes('Quarto árbitro: 1 de 1')));
  const rec = r.recommendations.find((x) => x.id === 'equipe');
  assert.ok(rec && rec.activity === 'rules' && rec.reason.includes('opinião errada do assistente foi seguida'));
  assert.ok(r.misses[0].tip.includes('seguiu a opinião do assistente'));
  assert.ok(tipFor(E({ crew: { flag: { raised: true, wrong: true }, consult: null } })).includes('bandeira do assistente estava errada'));
  assert.ok(!tipFor(E({ crew: null })).includes('assistente'));
  assert.ok(reportToHtml(r).includes('Equipe de arbitragem'));
  assert.ok(!reportToHtml(buildReport({ log, grade, facts: matchFacts(log) })).includes('Equipe de arbitragem'));
  assert.equal(buildReport({ log, grade, facts: matchFacts(log), crew: { consults: [], flagsRaised: 0, flagsWrong: 0, bench: { calls: 0, ok: 0 } } }).crew.verdict, 'ok');
});

const FACTS = { decisions: 8, correct: 7, yellow: 0, red: 0, redWrong: 0, fouls: 3, penalties: 0, penaltiesCorrect: 0, penaltiesMissed: 0, wrongCalls: 0, missedFouls: 0, simulationsPunished: 0, simulationsMissed: 0, offsides: 0, offsidesCorrect: 0, offsidesMissed: 0, advantageOk: 0, advantageFailed: 0, whistles: 0 };
const res = (crew) => ({ nota: 7, label: 'Bom', categories: [{ label: 'Posicionamento', points: 5, max: 10, ratio: 0.5 }], mistakes: [], hits: [], counts: { unnecessaryWhistles: 0 }, score: { home: 1, away: 0 }, extras: { ...FACTS }, crew });
const fx = (matchId) => ({ competitionId: 'varzea', homeId: 'tamarindo', awayId: 'moinho', importance: 1, matchId, duration: 'standard' });

test('na carreira: a equipe evolui depois de cada partida, sem duplicar, e o resumo fica no histórico', () => {
  const c = createCareer('Ana', 5);
  assert.deepEqual(Object.keys(c.crew.members), CREW_IDS);
  const e0 = c.crew.members.a1.exp;
  const crew = { consults: [{ who: 'a1', followed: true, correct: true, divergent: false }], flagsRaised: 1, flagsWrong: 0, bench: { calls: 1, ok: 0 } };
  applyMatch(c, fx('e1'), res(crew));
  assert.equal(c.crew.members.a1.exp, e0 + 8);
  assert.equal(c.crew.matches, 1);
  assert.deepEqual(c.history[0].crew, { consults: 1, followedRight: 1, followedWrong: 0, ignoredRight: 0, divergences: 0, flagsRaised: 1, flagsWrong: 0, bench: { calls: 1, ok: 0 } });
  assert.equal(applyMatch(c, fx('e1'), res(crew)), null);
  assert.equal(c.crew.members.a1.exp, e0 + 8, 'repetir a partida não soma de novo');
  const d = createCareer('Ana', 6);
  applyMatch(d, fx('e2'), res(null));
  assert.equal(d.crew.matches, 0, 'sem dados da equipe, nada muda');
  assert.equal(d.history[0].crew, null);
});

test('salvamento: carreira nova tem equipe e a migração v9 -> v10 cria a equipe sem inventar experiência', () => {
  const c = createCareer('Ana', 7);
  applyMatch(c, fx('s1'), res(null));
  applyMatch(c, fx('s2'), res(null));
  const old = JSON.parse(JSON.stringify(c));
  old.version = 9;
  delete old.crew;
  const r = migrateCareer(old);
  assert.ok(!r.error && r.migrated);
  assert.equal(r.career.version, CAREER_VERSION);
  assert.deepEqual(Object.keys(r.career.crew.members), CREW_IDS);
  assert.deepEqual(r.career.crew.members, generateCrew(c.seed, 2).members, 'sai da semente e dos jogos apitados');
  assert.equal(r.career.crew.matches, 0);
  assert.equal(migrateCareer(JSON.parse(JSON.stringify(r.career))).migrated, false);
  const broken = { seed: 'abc', totalMatches: 0, crew: { members: { a1: { id: 'a1', name: 'X', exp: 10 } }, chemistry: 'x', stats: { consults: 3 } } };
  ensureCrew(broken);
  assert.deepEqual(Object.keys(broken.crew.members), CREW_IDS);
  assert.equal(broken.crew.chemistry, 30);
  assert.equal(broken.crew.stats.consults, 3);
  assert.equal(broken.crew.stats.flagsRaised, 0);
});
