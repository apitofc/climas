import test from 'node:test';
import assert from 'node:assert/strict';
import { createMatch } from './helpers/harness.mjs';
import { gradeMatch, matchFacts, describeEntry } from '../src/systems/RefereeGrading.js';
import { GOAL_CHECK, GOAL_CHECK_S, GOAL_CAUSE_WINDOW_MS, errorText } from '../src/systems/MatchRules.js';

// Põe a partida em jogo corrido (depois do pontapé inicial), sem decidir nada sozinha.
function inPlay(seed = 5) {
  const m = createMatch({ seed, durationMs: 300000 });
  for (let i = 0; i < 60 * 30 && m.sim.state !== 'playing'; i++) m.advance('manual');
  assert.equal(m.sim.state, 'playing');
  return m;
}
const player = (m, team, role = 'FWD') => m.players.find((p) => p.team === team && p.role === role);
const other = (t) => (t === 'home' ? 'away' : 'home');

// Registra uma infração real (não apitada) da equipe `team` e devolve o lance.
function infraction(m, type, team = 'home', level = 'none') {
  const off = player(m, team);
  const vic = player(m, other(team), 'DEF');
  let reg = null;
  m.events.once('incident-registered', (i) => (reg = i));
  m.sim.registerIncident({ type, level, offender: off, victim: vic, evidence: ['teste'], contact: type !== 'offside', at: { x: 300, y: 200 } });
  assert.ok(reg && reg.expected.foul);
  return reg;
}
const goalEntries = (m) => m.dec.log.filter((e) => e.type === GOAL_CHECK);

test('gol depois de impedimento não apitado da equipe que marcou pode ser anulado (sem VAR)', () => {
  const m = inPlay();
  infraction(m, 'offside');
  m.sim.scoreGoal('home');
  assert.deepEqual(m.sim.score, { home: 1, away: 0 });
  assert.ok(m.dec.isGoalCheckOpen());
  assert.equal(m.dec.getPrompt(), 'GOL!  Espaço anula o gol');
  assert.ok(m.sim.goalTimer >= GOAL_CHECK_S - 0.01, 'pausa maior para dar tempo de decidir');

  let disallowed = null;
  m.events.once('goal-disallowed', (d) => (disallowed = d));
  assert.equal(m.dec.annulGoal(), true);
  assert.deepEqual(m.sim.score, { home: 0, away: 0 });
  assert.equal(m.sim.state, 'setpiece');
  assert.equal(m.sim.setpiece.type, 'indirect_free_kick');
  assert.equal(m.sim.setpiece.team, 'away', 'tiro livre indireto para o adversário de quem estava impedido');
  assert.equal(m.sim.setpiece.x, 300);
  assert.equal(disallowed.cause, 'offside');

  const [e] = goalEntries(m);
  assert.ok(e.correct && e.errors.length === 0 && e.actual.foulCalled);
  assert.equal(describeEntry(e).actual, 'anulou o gol');
  assert.equal(m.dec.goalCheck, null);
  assert.equal(m.dec.annulGoal(), false, 'não anula duas vezes');
});

test('gol depois de falta não apitada: anular marca tiro livre (direto) para a equipe prejudicada', () => {
  const m = inPlay(6);
  infraction(m, 'light_foul', 'away', 'light');
  m.sim.scoreGoal('away');
  assert.ok(m.dec.annulGoal());
  assert.equal(m.sim.setpiece.type, 'free_kick');
  assert.equal(m.sim.setpiece.team, 'home');
  assert.deepEqual(m.sim.score, { home: 0, away: 0 });
});

test('não anular o gol irregular é erro grave: "gol irregular validado"', () => {
  const m = inPlay(7);
  infraction(m, 'serious_foul', 'home', 'yellow');
  m.sim.scoreGoal('home');
  // A pausa do gol acaba e o jogo recomeça com o gol confirmado.
  for (let i = 0; i < 60 * 8 && m.dec.goalCheck; i++) m.advance('manual');
  assert.equal(m.dec.goalCheck, null);
  assert.equal(m.sim.score.home, 1);
  const [e] = goalEntries(m);
  assert.deepEqual(e.errors, ['FOUL_MISSED']);
  assert.equal(errorText('FOUL_MISSED', GOAL_CHECK), 'gol irregular validado');
  const grade = gradeMatch(m.dec.log);
  const mistake = grade.mistakes.find((x) => x.label === 'Gol');
  assert.ok(mistake && mistake.severity >= 3, 'conta como erro grave');
  assert.equal(mistake.expected, 'anular o gol (houve falta ou impedimento da equipe que marcou)');
  assert.equal(mistake.actual, 'confirmou o gol');
});

test('a infração também vale depois de a janela do lance expirar (lance já registrado como ignorado)', () => {
  const m = inPlay(8);
  const inc = infraction(m, 'light_foul', 'home', 'light');
  for (let i = 0; i < 60 * 20 && inc.status !== 'resolved' && m.sim.state === 'playing'; i++) m.advance('ignore');
  assert.equal(inc.status, 'resolved');
  assert.ok(m.sim.state === 'playing' && m.sim.time - inc.time < GOAL_CAUSE_WINDOW_MS);
  m.sim.scoreGoal('home');
  assert.ok(m.dec.goalCheck.cause && m.dec.goalCheck.cause.incidentId === inc.id);
  assert.ok(m.dec.annulGoal());
});

test('gol limpo: confirmar não gera registro (nota não infla); anular um gol válido é erro e recomeça com tiro de meta', () => {
  const a = inPlay(9);
  a.sim.scoreGoal('home');
  assert.equal(a.dec.goalCheck.cause, null);
  for (let i = 0; i < 60 * 8 && a.dec.goalCheck; i++) a.advance('manual');
  assert.equal(goalEntries(a).length, 0);
  assert.equal(a.sim.score.home, 1);

  const b = inPlay(10);
  b.sim.scoreGoal('home');
  assert.ok(b.dec.annulGoal());
  assert.deepEqual(b.sim.score, { home: 0, away: 0 });
  assert.equal(b.sim.setpiece.type, 'goal_kick');
  assert.equal(b.sim.setpiece.team, 'away');
  const [e] = goalEntries(b);
  assert.deepEqual(e.errors, ['FOUL_WRONG']);
  assert.equal(errorText('FOUL_WRONG', GOAL_CHECK), 'gol válido anulado');
  assert.equal(describeEntry(e).who, '');
});

test('infração da equipe adversária (que sofreu o gol) ou de outro tipo não é causa do gol', () => {
  const m = inPlay(11);
  infraction(m, 'light_foul', 'away', 'light'); // falta do time que vai SOFRER o gol: vantagem natural
  m.sim.scoreGoal('home');
  assert.equal(m.dec.goalCheck.cause, null);

  const n = inPlay(12);
  const off = player(n, 'home');
  const vic = player(n, 'away', 'DEF');
  n.sim.registerIncident({ type: 'challenge', level: 'none', offender: off, victim: vic, evidence: ['x'], contact: true });
  n.sim.registerIncident({ type: 'simulation', level: 'none', offender: vic, victim: off, evidence: ['x'], contact: false });
  n.sim.scoreGoal('home');
  assert.equal(n.dec.goalCheck.cause, null, 'disputa legal e simulação não anulam gol');
});

test('infração antiga (fora da janela) ou de antes de uma paralisação não anula o gol', () => {
  const m = inPlay(13);
  const inc = infraction(m, 'offside');
  inc.time = m.sim.time - GOAL_CAUSE_WINDOW_MS - 500;
  m.sim.scoreGoal('home');
  assert.equal(m.dec.goalCheck.cause, null, 'passou de 8 s');

  const n = inPlay(14);
  infraction(n, 'offside');
  n.events.emit('play-resumed', { time: n.sim.time + 1, reason: 'drop' }); // jogo parou e voltou depois da infração
  n.sim.scoreGoal('home');
  assert.equal(n.dec.goalCheck.cause, null);
});

test('falta já apitada não é causa: a infração foi marcada, não há o que anular', () => {
  const m = inPlay(15);
  const inc = infraction(m, 'light_foul', 'home', 'light');
  inc.actual.foulCalled = true;
  m.sim.scoreGoal('home');
  assert.equal(m.dec.goalCheck.cause, null);
});

test('anular só é possível na pausa do gol; fora dela a tecla não faz nada', () => {
  const m = inPlay(16);
  assert.equal(m.dec.annulGoal(), false);
  m.sim.scoreGoal('home');
  for (let i = 0; i < 60 * 8 && m.dec.goalCheck; i++) m.advance('manual');
  assert.equal(m.dec.annulGoal(), false, 'depois do pontapé inicial não dá mais');
  assert.equal(m.sim.score.home, 1);
});

test('a revisão do VAR volta no tempo e descarta a conferência de gol daquele instante', () => {
  const m = inPlay(17);
  const snap = m.dec.captureState();
  infraction(m, 'offside');
  m.sim.scoreGoal('home');
  assert.ok(m.dec.goalCheck);
  m.dec.restoreState(snap);
  assert.equal(m.dec.goalCheck, null);
  assert.equal(goalEntries(m).length, 0);
});

test('estatísticas: conferência de gol não vira falta, impedimento nem cartão nos fatos da partida', () => {
  const m = inPlay(18);
  infraction(m, 'offside');
  m.sim.scoreGoal('home');
  m.dec.annulGoal();
  const f = matchFacts(m.dec.log);
  assert.equal(f.goalsDisallowed, 1);
  assert.equal(f.goalChecksWrong, 0);
  assert.equal(f.offsides, 0);
  assert.equal(f.fouls, 0);
  assert.equal(f.yellow + f.red, 0);
});

test('o VAR continua anulando o gol ao corrigir a falta (sem a tecla G e sem mudar o VarSystem)', () => {
  const m = inPlay(19);
  const inc = infraction(m, 'light_foul', 'home', 'light');
  for (let i = 0; i < 20; i++) m.advance('manual'); // o VAR grava o lance
  m.sim.scoreGoal('home');
  for (let i = 0; i < 10; i++) m.advance('manual');
  assert.equal(m.sim.score.home, 1);
  assert.ok(m.dec.goalCheck && m.dec.goalCheck.cause, 'a conferência de gol enxerga a falta');

  const opened = m.varSys.open();
  assert.ok(opened.ok, opened.reason);
  const res = m.varSys.alterDecision(inc.id, { foul: true, cards: { offender: null, victim: null } });
  assert.ok(res.ok && res.changed, res.reason);
  assert.equal(m.sim.score.home, 0, 'o gol some junto com a decisão corrigida');
  assert.equal(m.dec.goalCheck, null);
  assert.equal(goalEntries(m).length, 0, 'sem registro duplicado de gol');
});
