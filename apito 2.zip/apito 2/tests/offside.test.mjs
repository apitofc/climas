import test from 'node:test';
import assert from 'node:assert/strict';
import { offsideInfo } from '../src/systems/PlayerAI.js';
import { buildExpected, errorText, describeIncident } from '../src/systems/MatchRules.js';
import { FIELD_RECT } from '../src/config.js';
import { runMatch } from './helpers/harness.mjs';

const cx = FIELD_RECT.cx;
const player = (team, attackDir, x, name) => ({ team, attackDir, x, y: 100, number: 7, name });

// Time "home" ataca para a direita (attackDir = 1). Defensores do "away" em x = cx+60 (último) e cx+40 (penúltimo).
const away = [player('away', -1, cx + 40, 'D1'), player('away', -1, cx + 60, 'GK')];

test('impedimento: à frente do penúltimo defensor e da bola, na metade adversária', () => {
  const passer = player('home', 1, cx - 20, 'P');
  const inFront = player('home', 1, cx + 55, 'A');
  const level = player('home', 1, cx + 40, 'B');
  const behind = player('home', 1, cx + 36, 'C');
  const ownHalf = player('home', 1, cx - 5, 'E');
  const info = offsideInfo(passer, [passer, inFront, level, behind, ownHalf, ...away], passer.x);
  assert.deepEqual(info.offside.map((e) => e.player.name), ['A']);
  assert.deepEqual(info.close.map((e) => e.player.name), ['B', 'C']);
  assert.equal(info.lineDefender.name, 'D1');
});

test('impedimento: quem está atrás da bola não está em impedimento, mesmo à frente da defesa', () => {
  const passer = player('home', 1, cx + 70, 'P'); // passador já está mais à frente que todos
  const mate = player('home', 1, cx + 55, 'A');
  const info = offsideInfo(passer, [passer, mate, ...away], passer.x);
  assert.equal(info.offside.length, 0);
});

test('impedimento vale também para o time que ataca para a esquerda', () => {
  const passer = { team: 'away', attackDir: -1, x: cx + 20, y: 100, number: 1, name: 'P' };
  const mate = { team: 'away', attackDir: -1, x: cx - 55, y: 100, number: 2, name: 'A' };
  const defs = [player('home', 1, cx - 40, 'D1'), player('home', 1, cx - 60, 'GK')];
  const info = offsideInfo(passer, [passer, mate, ...defs], passer.x);
  assert.deepEqual(info.offside.map((e) => e.player.name), ['A']);
});

test('decisão esperada: impedimento é marcado (tiro indireto, sem cartão); posição legal segue', () => {
  const off = buildExpected('offside', 'none');
  assert.equal(off.foul, true);
  assert.equal(off.card, null);
  assert.equal(off.restart, 'indirect_free_kick');
  assert.equal(buildExpected('legal_position', 'none').foul, false);
  assert.equal(errorText('FOUL_MISSED', 'offside'), 'impedimento não marcado');
  assert.equal(errorText('FOUL_WRONG', 'legal_position'), 'não era impedimento');
  assert.equal(errorText('FOUL_MISSED', 'light_foul'), 'falta não marcada');
  const a = { team: 'home', number: 9, name: 'Moura' };
  const b = { team: 'away', number: 4, name: 'Silva' };
  assert.match(describeIncident({ type: 'offside', offender: a, victim: b }), /impedimento/);
});

test('partidas geram impedimentos e posições legais com as evidências corretas', () => {
  let offsides = 0;
  let legal = 0;
  for (let seed = 1; seed <= 8; seed++) {
    for (const i of runMatch({ mode: 'perfect', seed }).incidents) {
      if (i.type === 'offside') {
        offsides++;
        assert.equal(i.expected.foul, true);
        assert.ok(i.evidence.includes('posição de impedimento no passe'));
      }
      if (i.type === 'legal_position') {
        legal++;
        assert.equal(i.expected.foul, false);
        assert.ok(i.evidence.includes('posição legal no passe'));
      }
    }
  }
  assert.ok(offsides >= 3, `poucos impedimentos: ${offsides}`);
  assert.ok(legal >= 3, `poucas posições legais: ${legal}`);
});
