import test from 'node:test';
import assert from 'node:assert/strict';
import {
  repBreakdown, xpBreakdown, suspensionFor, promotionCriteria, decideSeason, careerObjectives, completeObjectives, initialObjectives,
  markObjectivesSeen, unseenObjectives, LEAGUES, PROMOTION, DEMOTION,
} from '../src/systems/ProgressionSystem.js';
import { createCareer, applyMatch, getOffers, skipWeek, currentDivision, migrateCareer, evaluateObjectives, objectiveDefs, SEASON_ROUNDS, CAREER_VERSION } from '../src/systems/CareerSystem.js';

const report = (nota, graves = 0) => ({
  nota,
  label: 'x',
  categories: [{ label: 'Cartões', ratio: 0.5 }],
  mistakes: Array.from({ length: graves }, () => ({ severity: 3 })),
  counts: { unnecessaryWhistles: 0 },
  score: { home: 1, away: 0 },
});
function play(career, nota, { graves = 0, pick = 0 } = {}) {
  const offers = getOffers(career).filter((o) => o.status === 'offered');
  const f = offers[Math.min(pick, offers.length - 1)].fixture;
  return applyMatch(career, { competitionId: f.competitionId, homeId: f.home, awayId: f.away, importance: f.importance, fixtureId: f.id, matchId: `m${career.totalMatches}-${career.season.number}` }, report(nota, graves));
}
// Joga uma temporada inteira com a mesma nota e devolve o resumo do fim da temporada.
function season(career, nota, opts) {
  let end = null;
  for (let i = 0; i < SEASON_ROUNDS; i++) end = play(career, nota, opts).seasonEnded || end;
  return end;
}

test('reputação: nota acima de 6 sobe, abaixo desce, com teto por partida', () => {
  assert.ok(repBreakdown(8, 1, 0).delta > 0);
  assert.ok(repBreakdown(4, 1, 0).delta < 0);
  assert.equal(repBreakdown(6, 3, 0).delta, 0);
  assert.ok(repBreakdown(1, 3, 0).delta >= -5, 'uma partida péssima tem perda limitada');
  assert.ok(repBreakdown(10, 3, 0).delta <= 5);
  assert.ok(repBreakdown(8, 2, 0).delta > repBreakdown(8, 1, 0).delta, 'jogo mais importante pesa mais');
});

test('erros graves custam em proporção e são explicados', () => {
  const a = repBreakdown(7, 1, 0);
  const b = repBreakdown(7, 1, 2);
  const c = repBreakdown(7, 1, 6);
  assert.ok(b.delta < a.delta && c.delta < b.delta);
  assert.equal(repBreakdown(7, 1, 20).delta, repBreakdown(7, 1, 6).delta, 'penalidade tem teto');
  assert.ok(b.lines.some((l) => l.includes('erro(s) grave(s)')));
  assert.ok(a.lines.length === 1);
  assert.match(xpBreakdown(8, 2).line, /XP/);
});

test('suspensão de oportunidades: só com erros muito graves ou duas notas muito baixas seguidas', () => {
  assert.equal(suspensionFor({ graves: 3, nota: 5 }), null);
  assert.ok(suspensionFor({ graves: 4, nota: 5 }));
  assert.equal(suspensionFor({ graves: 0, nota: 3.5, previousNota: 7 }), null);
  assert.ok(suspensionFor({ graves: 0, nota: 3.5, previousNota: 3 }));
});

test('requisitos de promoção: todos explícitos e verificáveis', () => {
  const stats = { played: 4, avg: 7.4, graves: 1 };
  const ok = promotionCriteria({ division: 0, rep: 20 }, stats, 3, 6);
  assert.equal(ok.criteria.length, 5);
  assert.ok(ok.allMet);
  assert.equal(ok.next.id, LEAGUES[1].id);
  const cases = [
    [{ division: 0, rep: LEAGUES[1].unlockRep - 1 }, stats, 3, 6, 'rep'],
    [{ division: 0, rep: 20 }, { ...stats, avg: 5.5 }, 3, 6, 'avg'],
    [{ division: 0, rep: 20 }, { ...stats, played: PROMOTION.minMatches - 1 }, 3, 6, 'played'],
    [{ division: 0, rep: 20 }, { ...stats, graves: PROMOTION.maxGraves + 1 }, 3, 6, 'graves'],
    [{ division: 0, rep: 20 }, stats, PROMOTION.minObjectives - 1, 6, 'objectives'],
  ];
  for (const [who, st, met, target, failing] of cases) {
    const r = promotionCriteria(who, st, met, target);
    assert.equal(r.allMet, false, failing);
    assert.deepEqual(r.criteria.filter((c) => !c.ok).map((c) => c.id), [failing]);
  }
  assert.equal(promotionCriteria({ division: LEAGUES.length - 1, rep: 100 }, stats, 4, 6).isMax, true);
});

test('fim de temporada: promoção quando todos os requisitos são atendidos, com o motivo', () => {
  const c = createCareer('Ana', 5);
  const end = season(c, 8.2);
  assert.equal(end.division.action, 'promoted');
  assert.equal(c.division, 1);
  assert.equal(currentDivision(c).id, LEAGUES[1].id);
  assert.match(end.division.reason, /Promovido/);
  assert.ok(c.unlocked.includes(LEAGUES[1].id));
  assert.equal(c.seasons.length, 1);
  assert.equal(c.seasons[0].action, 'promoted');
  assert.ok(end.division.criteria.every((x) => x.ok));
});

test('sem promoção quando um requisito falha, e o motivo diz qual', () => {
  const c = createCareer('Ana', 6);
  const end = season(c, 8.2, { graves: 2 }); // 10 erros graves na temporada
  assert.notEqual(end.division.action, 'promoted');
  assert.equal(c.division, 0);
  assert.match(end.division.reason, /erros graves/);
});

test('reputação baixa também impede a promoção (e diz isso)', () => {
  const c = createCareer('Ana', 7);
  // notas boas, mas a reputação inicial não alcança o mínimo da divisão seguinte em uma temporada de jogos fáceis
  c.rep = 0;
  const end = season(c, 6.4);
  if (end.division.action !== 'promoted') assert.match(end.division.reason, /reputação|média|objetivos/i);
  assert.ok(end.division.criteria.some((x) => x.id === 'rep'));
});

test('rebaixamento: só após duas temporadas seguidas com média abaixo de 5, nunca abaixo da divisão mais baixa', () => {
  const c = createCareer('Ana', 8);
  c.division = 2;
  c.unlocked = LEAGUES.filter((l) => l.tier <= LEAGUES[2].tier).map((l) => l.id);
  c.rep = 40;

  const first = season(c, 3.5);
  assert.equal(first.division.action, 'warning');
  assert.equal(c.division, 2, 'uma temporada fraca só gera aviso');
  assert.equal(c.strikes, 1);
  assert.match(first.division.reason, /aviso 1 de 2/);

  const second = season(c, 3.5);
  assert.equal(second.division.action, 'demoted');
  assert.equal(c.division, 1);
  assert.equal(c.strikes, 0);
  assert.ok(!c.unlocked.includes(LEAGUES[2].id), 'a liga superior volta a ficar bloqueada');
  assert.match(second.division.reason, /Rebaixado/);

  // na divisão mais baixa nunca há rebaixamento
  const low = createCareer('Bia', 9);
  for (let i = 0; i < 3; i++) season(low, 3);
  assert.equal(low.division, 0);
});

test('uma boa temporada zera os avisos', () => {
  const c = createCareer('Ana', 10);
  c.division = 2;
  c.unlocked = LEAGUES.filter((l) => l.tier <= LEAGUES[2].tier).map((l) => l.id);
  c.rep = 40;
  season(c, 3.5);
  assert.equal(c.strikes, 1);
  season(c, 6.5);
  assert.equal(c.strikes, 0);
});

test('uma partida ruim isolada não apaga a progressão', () => {
  const c = createCareer('Ana', 11);
  for (let i = 0; i < 3; i++) play(c, 8);
  const rep = c.rep;
  const xp = c.xp;
  const s = play(c, 1.5, { graves: 6 });
  assert.ok(s.repDelta >= -5);
  assert.ok(c.rep >= rep - 5.05 && c.rep > 0);
  assert.ok(c.xp >= xp, 'experiência nunca diminui');
  assert.ok(s.reasons.rep.length >= 2 && s.reasons.xp);
});

test('suspensão: por uma rodada só jogos de importância 1, com o motivo', () => {
  const c = createCareer('Ana', 12);
  c.division = 3;
  c.unlocked = LEAGUES.filter((l) => l.tier <= LEAGUES[3].tier).map((l) => l.id);
  c.rep = 60;
  c.season.tierAtStart = 3;
  const s = play(c, 5, { graves: 4, pick: 2 });
  assert.ok(s.suspension);
  const offers = getOffers(c);
  assert.ok(offers.every((o) => o.fixture.importance === 1), 'só importância 1');
  assert.ok(c.world.offers.restriction);
  play(c, 7);
  assert.equal(c.world.offers.restriction, null, 'a suspensão dura uma rodada');
});

test('objetivos de carreira: concluem uma vez e a recompensa é entregue uma vez', () => {
  const c = createCareer('Ana', 13);
  assert.equal(c.objectives.length, 9);
  assert.ok(c.objectives.every((o) => o.status === 'active'));
  const xp0 = c.xp;
  const s = play(c, 7);
  assert.ok(s.objectivesDone.some((o) => o.id === 'first'));
  const first = c.objectives.find((o) => o.id === 'first');
  assert.equal(first.status, 'done');
  assert.ok(first.doneAt);
  const xpAfter = c.xp;
  assert.ok(xpAfter > xp0 + s.xpGain - 1);
  assert.deepEqual(completeObjectives(c), [], 'concluir de novo não entrega nada');
  assert.equal(c.xp, xpAfter);
  assert.ok(unseenObjectives(c) >= 1);
  assert.ok(markObjectivesSeen(c));
  assert.equal(unseenObjectives(c), 0);
  const list = careerObjectives(c);
  assert.equal(list.find((o) => o.id === 'ten').progress, '1/10');
});

test('migração v3 -> v4: divisão vem da maior liga liberada; objetivos antigos sem recompensa', () => {
  const v4 = createCareer('Antigo', 14);
  for (let i = 0; i < 3; i++) play(v4, 8);
  const v3 = JSON.parse(JSON.stringify(v4));
  for (const key of ['division', 'strikes', 'restricted', 'seasons', 'objectives']) delete v3[key];
  v3.version = 3;
  v3.unlocked = ['varzea', 'regional'];
  const xp = v3.xp;
  const r = migrateCareer(v3);
  assert.ok(r.migrated);
  assert.equal(r.career.version, CAREER_VERSION);
  assert.equal(r.career.division, 1);
  assert.equal(r.career.xp, xp, 'sem recompensa retroativa');
  const first = r.career.objectives.find((o) => o.id === 'first');
  assert.equal(first.status, 'done');
  assert.equal(first.retro, true);
  assert.deepEqual(migrateCareer(JSON.parse(JSON.stringify(r.career))).career.division, 1);
});

test('objetivos da temporada e requisitos de promoção usam a mesma meta de média', () => {
  const c = createCareer('Ana', 15);
  const target = objectiveDefs(c.season.tierAtStart)[0].target;
  const end = season(c, 7.5);
  assert.ok(end.division.criteria.find((x) => x.id === 'avg').text.includes(String(target).replace('.', ',')));
  assert.equal(evaluateObjectives(c.seasons.length ? { ...c.season, matches: [] } : c.season).length, 4);
});

test('o mesmo jogo não conta duas vezes na progressão', () => {
  const c = createCareer('Ana', 16);
  const f = getOffers(c)[0].fixture;
  const fixture = { competitionId: f.competitionId, homeId: f.home, awayId: f.away, importance: f.importance, fixtureId: f.id, matchId: 'unico' };
  assert.ok(applyMatch(c, fixture, report(8)));
  const snap = JSON.stringify(c);
  assert.equal(applyMatch(c, fixture, report(8)), null);
  assert.equal(JSON.stringify(c), snap);
});

test('passar rodadas não muda divisão, reputação nem experiência', () => {
  const c = createCareer('Ana', 17);
  const before = { rep: c.rep, xp: c.xp, division: c.division };
  for (let i = 0; i < SEASON_ROUNDS; i++) skipWeek(c);
  assert.deepEqual({ rep: c.rep, xp: c.xp, division: c.division }, before);
  assert.ok(DEMOTION.strikesToDemote >= 2);
});
