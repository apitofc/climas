import test from 'node:test';
import assert from 'node:assert/strict';
import { runMatch } from './helpers/harness.mjs';
import { DURATIONS } from '../src/config.js';

test('partida completa termina, sem valores inválidos, e o placar bate com os gols', () => {
  for (const seed of [1, 2, 3]) {
    const r = runMatch({ mode: 'perfect', seed });
    assert.ok(r.finished, `seed ${seed} não terminou`);
    assert.equal(r.nan, false);
    assert.equal(r.sim.score.home + r.sim.score.away, r.goals.length);
    assert.equal(r.sim.getClock().text, '90:00');
    assert.equal(r.dec.pending.length, 0);
  }
});

test('todas as durações terminam e mantêm a mesma frequência de lances por minuto', () => {
  // Média de várias sementes: uma partida isolada varia muito (6 a 13 lances na rápida), a média é o que importa.
  const rates = [];
  for (const d of DURATIONS.filter((x) => x.id === 'quick' || x.id === 'standard')) {
    let total = 0;
    for (const seed of [1, 2, 3, 4, 5, 6]) {
      const r = runMatch({ mode: 'perfect', seed, durationMs: d.ms });
      assert.ok(r.finished, `${d.id}/${seed}`);
      total += r.dec.log.length;
    }
    const avg = total / 6;
    assert.ok(avg >= 8, `${d.id}: lances demais poucos (média ${avg})`);
    rates.push(avg / (d.ms / 60000));
  }
  assert.ok(Math.max(...rates) / Math.min(...rates) < 1.6, `ritmo muito diferente: ${rates}`);
});

test('as agravantes mostradas nas evidências batem com a gravidade (regra ensinada no "Como jogar")', () => {
  let checked = 0;
  for (let seed = 1; seed <= 6; seed++) {
    for (const f of runMatch({ mode: 'perfect', seed }).fouls) {
      const n = ['entrada por trás', 'alta velocidade', 'entrada imprudente'].filter((e) => f.evidence.includes(e)).length;
      const base = n >= 3 ? 'red' : n === 2 ? 'yellow' : 'light';
      if (f.evidence.some((e) => e.startsWith('falta tática'))) {
        // Falta tática (Upgrade 1): só sobe a gravidade, nunca desce.
        const rank = { light: 0, yellow: 1, red: 2 };
        assert.ok(rank[f.level] >= rank[base] && rank[f.level] >= 1, JSON.stringify(f));
      } else {
        assert.equal(f.level, base, JSON.stringify(f));
      }
      checked++;
    }
  }
  assert.ok(checked > 30);
});

test('a nota é reproduzível e premia boas decisões', () => {
  const a = runMatch({ mode: 'random', seed: 7 }).grade.nota;
  const b = runMatch({ mode: 'random', seed: 7 }).grade.nota;
  assert.equal(a, b);
  const perfect = runMatch({ mode: 'perfect', seed: 7 }).grade.nota;
  const ignoring = runMatch({ mode: 'ignore', seed: 7 }).grade.nota;
  assert.ok(perfect > a, `perfeito ${perfect} deveria superar aleatório ${a}`);
  assert.ok(perfect > ignoring, `perfeito ${perfect} deveria superar ignorar ${ignoring}`);
});

test('com a mesma semente a partida se repete igual', () => {
  const a = runMatch({ mode: 'perfect', seed: 11 });
  const b = runMatch({ mode: 'perfect', seed: 11 });
  assert.deepEqual(a.sim.score, b.sim.score);
  assert.equal(a.dec.log.length, b.dec.log.length);
});
