import test from 'node:test';
import assert from 'node:assert/strict';
import { createMatch, runMatch } from './helpers/harness.mjs';
import { FIELD_RECT, DURATIONS } from '../src/config.js';
import MatchMood, { favoredBy, tensionLabel, crowdLabel, TENSION_HIGH, TENSION_CALM, PRESSURE_WEIGHT } from '../src/systems/MatchMood.js';
import { gradeMatch, matchFacts } from '../src/systems/RefereeGrading.js';
import { getTarget } from '../src/systems/PlayerAI.js';
import { INCIDENT } from '../src/systems/MatchRules.js';
import { createCareer, applyMatch } from '../src/systems/CareerSystem.js';

const L = FIELD_RECT;
const standard = DURATIONS.find((d) => d.id === 'standard').ms;
const P = (team, n = 9) => ({ team, number: n, name: `J${n}` });

// Entrada mínima da súmula para testar o clima e a nota sem simular uma partida.
function entry(over = {}) {
  return {
    incidentId: 1, type: 'light_foul', level: 'light', time: 1000, clock: '10:00', period: 1, refDistance: 20,
    offender: P('away'), victim: P('home', 10), evidence: ['contato antes da bola'],
    expected: { foul: true, card: null, restart: 'free_kick', cardTarget: null, advantageAllowed: true },
    actual: { foulCalled: true, cards: [], advantage: null, decided: true },
    errors: [], notes: [], correct: true, varChanged: false, ...over,
  };
}
const missed = (over = {}) => entry({ actual: { foulCalled: false, cards: [], advantage: null, decided: true }, errors: ['FOUL_MISSED'], correct: false, ...over });

test('rótulos de clima e de torcida', () => {
  assert.deepEqual([tensionLabel(0), tensionLabel(TENSION_CALM), tensionLabel(TENSION_HIGH)], ['Calmo', 'Tenso', 'Quente']);
  assert.deepEqual([crowdLabel(-50), crowdLabel(0), crowdLabel(50)], ['Irritada', 'Dividida', 'Satisfeita']);
});

test('a decisão favorece quem foi apitado a favor, não quem tinha razão', () => {
  assert.equal(favoredBy(entry()), 'home', 'falta marcada contra o visitante favorece o time da casa');
  assert.equal(favoredBy(missed()), 'away', 'falta real ignorada favorece quem a cometeu');
  assert.equal(favoredBy(entry({ actual: { foulCalled: true, cards: [{ team: 'away', color: 'yellow' }], advantage: null, decided: true } })), 'home');
  assert.equal(favoredBy(entry({ type: 'challenge', expected: { foul: false, card: null }, actual: { foulCalled: false, cards: [], decided: true } })), null);
  assert.equal(favoredBy({ type: 'unnecessary_whistle' }), null);
});

test('falta ignorada esquenta o clima e o time prejudicado; decisão correta acalma', () => {
  const m = new MatchMood();
  m.onDecision(missed());
  assert.ok(m.tension >= 12 && m.heatPts.home >= 12 && m.heatPts.away === 0);
  assert.ok(m.heat('home') > m.heat('away'));
  const high = m.tension;
  m.onDecision(entry());
  assert.ok(m.tension < high, 'acertar acalma');
  const w = new MatchMood();
  w.onDecision(entry({ type: 'challenge', expected: { foul: false, card: null }, errors: ['FOUL_WRONG'], correct: false }));
  assert.ok(w.heatPts.away >= 12, 'falta marcada sem infração esquenta o time punido');
});

test('erro grave dá um salto na tensão e conta; chegar ao clima quente avisa uma vez', () => {
  const m = new MatchMood();
  const grave = () => missed({ type: 'serious_foul', level: 'yellow', errors: ['FOUL_MISSED', 'CARD_MISSED'] });
  let crossed = 0;
  for (let i = 0; i < 4; i++) if (m.onDecision(grave()).crossedHot) crossed++;
  assert.ok(m.tension >= TENSION_HIGH);
  assert.equal(crossed, 1);
  assert.ok(m.counts.graveSpikes >= 3);
  assert.equal(m.summary().label, 'Quente');
  assert.ok(m.tension <= 100);
});

test('a tensão grava em cada decisão em que nível foi tomada e esfria sozinha, sem passar da base', () => {
  const m = new MatchMood(10);
  const a = missed();
  m.onDecision(a);
  assert.equal(a.tension, 10);
  const b = entry();
  m.onDecision(b);
  assert.ok(b.tension > 10);
  m.add(60);
  m.update(60000);
  assert.ok(m.tension < 70 && m.tension >= 10);
  m.update(10 * 60000);
  assert.equal(m.tension, 10, 'volta à base');
});

test('torcida: reage a quem foi favorecido; decisão correta contra a casa é "impopular", errada a favor é "popular"', () => {
  const m = new MatchMood();
  const against = entry({ victim: P('away', 7), offender: P('home', 4) }); // falta correta contra o time da casa
  m.onDecision(against);
  assert.ok(m.crowd < 0);
  assert.equal(m.counts.unpopularCorrect, 1);
  const favor = missed({ offender: P('home', 4), victim: P('away', 7) }); // erro que beneficia a casa
  m.onDecision(favor);
  assert.equal(m.counts.popularWrong, 1);
  assert.equal(favor.favored, 'home');
  assert.ok(m.summary().crowdMin <= -8);
});

test('capture/restore volta o clima ao instante (usado pela revisão do VAR)', () => {
  const m = new MatchMood();
  const snap = m.capture();
  m.onDecision(missed());
  m.onDecision(missed());
  m.restore(snap);
  assert.equal(m.tension, 0);
  assert.equal(m.counts.pressureDecisions, 0);
  assert.deepEqual(m.heatPts, { home: 0, away: 0 });
});

test('nota: decisões tomadas sob tensão alta valem mais (acertar ajuda, errar pesa), sem mudar a nota de quem acerta tudo', () => {
  const calm = [entry(), entry({ incidentId: 2 }), missed({ incidentId: 3 })];
  const tense = (i) => calm.map((e, k) => ({ ...e, tension: k === i ? TENSION_HIGH + 5 : 0 }));
  const base = gradeMatch(calm).nota;
  const rightUnderPressure = gradeMatch(tense(0)).nota;
  const wrongUnderPressure = gradeMatch(tense(2)).nota;
  assert.ok(rightUnderPressure > base, `${rightUnderPressure} > ${base}`);
  assert.ok(wrongUnderPressure < base, `${wrongUnderPressure} < ${base}`);
  const perfect = [entry({ tension: 90 }), entry({ incidentId: 2, tension: 90 })];
  assert.equal(gradeMatch(perfect).nota, gradeMatch([entry(), entry({ incidentId: 2 })]).nota, 'acertar tudo dá a mesma nota');
  assert.equal(PRESSURE_WEIGHT, 1.25);
  const f = matchFacts([entry({ tension: 80 }), missed({ incidentId: 2, tension: 70 }), entry({ incidentId: 3, victim: P('away', 7), offender: P('home', 4), favored: 'away' }), missed({ incidentId: 4, offender: P('home', 4), victim: P('away', 7), favored: 'home' })]);
  assert.deepEqual([f.pressureDecisions, f.pressureCorrect, f.unpopularCorrect, f.popularWrong], [2, 1, 1, 1]);
});

// ------------------------------------------------------------ integração com a partida
function scene(seed = 3) {
  const m = createMatch({ seed, durationMs: standard });
  for (let i = 0; i < 60 * 30 && m.sim.state !== 'playing'; i++) m.advance('manual');
  assert.equal(m.sim.state, 'playing');
  return m;
}
const pick = (m, team, role) => m.players.filter((p) => p.team === team && p.role === role);

test('na partida: a decisão registra tensão e quem foi favorecido; o calor sobe a agressividade do time', () => {
  const m = scene(4);
  const off = pick(m, 'away', 'DEF')[0];
  const vic = pick(m, 'home', 'FWD')[0];
  let inc = null;
  m.events.once('incident-registered', (i) => (inc = i));
  m.sim.registerIncident({ type: INCIDENT.LIGHT_FOUL, level: 'light', offender: off, victim: vic, evidence: ['contato antes da bola'], contact: true });
  m.dec.finalize(inc); // ignorada: falta real não marcada
  const e = m.dec.log[m.dec.log.length - 1];
  assert.equal(e.tension, 0);
  assert.equal(e.favored, 'away');
  assert.ok(m.dec.mood.tension > 0);
  m.dec.update(16);
  assert.ok(m.sim.heat.home > 0 && m.sim.heat.away >= 0, 'o time prejudicado esquenta');
  assert.ok(m.sim.heat.home > m.sim.heat.away);

  // Com calor, um jogador de 0,35 de agressividade passa a entrar imprudente.
  const t = pick(m, 'home', 'DEF')[0];
  const h = pick(m, 'away', 'FWD')[0];
  const d = h.attackDir;
  const place = () => {
    Object.assign(h, { x: L.cx, y: L.cy, vx: d * 40, vy: 0 });
    Object.assign(t, { x: L.cx + d * 8, y: L.cy, vx: -d * 5, vy: 0, aggression: 0.35, fallTimer: 0, tackleCooldown: 0 });
  };
  const real = m.sim.rng;
  const evidenceFor = (heat) => {
    m.sim.heat = { home: heat, away: 0 };
    m.sim.rng = { ...real, frac: () => 0.99 };
    place();
    let got = null;
    m.events.once('incident-registered', (i) => (got = i));
    m.sim.resolveTackle(t, h);
    m.sim.rng = real;
    return got.evidence;
  };
  assert.ok(!evidenceFor(0).includes('entrada imprudente'));
  assert.ok(evidenceFor(0.15).includes('entrada imprudente'));
});

test('amarelo muda a postura: cauteloso com clima calmo, exaltado com clima quente; o VAR desfaz', () => {
  const m = scene(5);
  const p = pick(m, 'away', 'MID')[0];
  p.aggression = 0.5;
  const snap = m.sim.captureState();
  const inc = { actual: { cards: [], foulCalled: true } };
  m.dec.applyCard(inc, p, 'yellow');
  assert.ok(Math.abs(p.aggression - 0.3) < 1e-9, 'mais cauteloso');
  m.sim.restoreState(snap);
  assert.ok(Math.abs(p.aggression - 0.5) < 1e-9, 'voltar no tempo desfaz a postura');
  p.yellowCards = 0;
  m.dec.mood.add(80);
  m.dec.applyCard({ actual: { cards: [], foulCalled: true } }, p, 'yellow');
  assert.ok(Math.abs(p.aggression - 0.6) < 1e-9, 'mais exaltado');
});

test('expulsão muda a dinâmica tática: quem fica com um a menos recua e o adversário sobe', () => {
  const m = scene(6);
  const mid = pick(m, 'away', 'MID')[0];
  m.advance('manual');
  assert.deepEqual(m.sim.ctx.manDown, { home: 0, away: 0 });
  const ctxFor = (manDown) => ({ ...m.sim.ctx, manDown, possessionTeam: 'away', chaser: { home: null, away: null } });
  const full = getTarget(mid, ctxFor({ home: 0, away: 0 }));
  const down = getTarget(mid, ctxFor({ home: 0, away: 1 }));
  const d = mid.attackDir;
  assert.ok((down.x - full.x) * d < 0, 'com um a menos fica mais fundo (perto do próprio gol)');
  const fw = pick(m, 'home', 'MID')[0];
  const ctxH = (md) => ({ ...m.sim.ctx, manDown: md, possessionTeam: 'home', chaser: { home: null, away: null } });
  assert.ok((getTarget(fw, ctxH({ home: 0, away: 1 })).x - getTarget(fw, ctxH({ home: 0, away: 0 })).x) * fw.attackDir >= 0, 'o time com um a mais sobe');
  // E o jogo realmente conta os jogadores.
  m.sim.sendOff(mid);
  m.advance('manual');
  assert.equal(m.sim.ctx.manDown.away, 1);
});

test('partida jogada: o clima fica dentro dos limites, o árbitro perfeito continua sem erros e o ritmo é o mesmo', () => {
  let errors = 0, lances = 0;
  for (let seed = 1; seed <= 8; seed++) {
    const r = runMatch({ mode: 'perfect', seed, durationMs: standard });
    const s = r.dec.mood.summary();
    assert.ok(s.peak >= 0 && s.peak <= 100 && s.crowd >= -100 && s.crowd <= 100);
    for (const e of r.dec.log) {
      lances++;
      if (!e.correct) errors++;
      assert.ok(typeof e.tension === 'number', 'toda decisão grava a tensão');
    }
  }
  assert.equal(errors, 0);
  assert.ok(lances / 8 >= 10, `ritmo ${lances / 8}`);
});

test('na carreira: o clima fica no registro e as redes sociais separam torcida de avaliação técnica', () => {
  const c = createCareer('Ana', 31);
  const mood = { peak: 70, final: 40, crowd: -30, crowdMin: -40, label: 'Quente', pressureDecisions: 2, pressureCorrect: 1, unpopularCorrect: 2, popularWrong: 1, graveSpikes: 1 };
  const extras = { decisions: 8, correct: 7, yellow: 1, red: 0, redWrong: 0, fouls: 3, penalties: 0, penaltiesCorrect: 0, penaltiesMissed: 0, wrongCalls: 0, missedFouls: 1, simulationsPunished: 0, simulationsMissed: 0, offsides: 0, offsidesCorrect: 0, offsidesMissed: 0, advantageOk: 0, advantageFailed: 0, whistles: 0, pressureDecisions: 2, pressureCorrect: 1, unpopularCorrect: 2, popularWrong: 1 };
  applyMatch(c, { competitionId: 'varzea', homeId: 'tamarindo', awayId: 'moinho', importance: 1, matchId: 'k1', duration: 'standard' }, {
    nota: 7, label: 'Bom', categories: [{ label: 'Posicionamento', points: 5, max: 10, ratio: 0.5 }], mistakes: [], hits: [], counts: { unnecessaryWhistles: 0 }, score: { home: 1, away: 0 }, extras, mood,
  });
  assert.equal(c.history[0].mood.label, 'Quente');
  const unpop = c.social.find((p) => p.key === 'k1:post:fan-unpopular');
  assert.ok(unpop && unpop.author.kind === 'torcedor' && unpop.technical === false && unpop.text.includes('avaliação técnica considerou'));
  const favor = c.social.find((p) => p.key === 'k1:post:journalist-favor');
  assert.ok(favor && favor.technical === true);
  const mail = c.inbox.find((m) => m.key === 'k1:mail:report');
  assert.ok(mail.lines.some((l) => l.startsWith('Sob pressão: 1 de 2')));
});
