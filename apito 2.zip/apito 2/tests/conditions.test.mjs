import test from 'node:test';
import assert from 'node:assert/strict';
import { createMatch, runMatch } from './helpers/harness.mjs';
import { FIELD_RECT, DURATIONS } from '../src/config.js';
import { buildConditions, conditionsFor, conditionsSummary, returnFouls, isLateDrama, WEATHER, PITCH } from '../src/systems/MatchConditions.js';
import MatchMood from '../src/systems/MatchMood.js';
import { makeRoster } from '../src/data/names.js';
import { createCareer, applyMatch } from '../src/systems/CareerSystem.js';
import { buildReport } from '../src/systems/TechnicalReport.js';
import { gradeMatch, matchFacts } from '../src/systems/RefereeGrading.js';
import { reportToHtml } from '../src/ui/reportHtml.js';
import { INCIDENT } from '../src/systems/MatchRules.js';

const L = FIELD_RECT;
const standard = DURATIONS.find((d) => d.id === 'standard').ms;
const base = { competitionId: 'varzea', homeId: 'tamarindo', awayId: 'moinho', stage: 'Rodada 1', week: 1 };
const withWeather = (weather, pitch) => {
  const w = WEATHER[weather];
  const p = PITCH[pitch];
  const c = buildConditions({ ...base, seed: 'fixa' });
  return { ...c, weather, pitch, visibility: w.visibility, text: weather === 'clear' && pitch === 'good' ? 'Tempo bom, gramado bom' : `${w.label}, ${p.label}`, effects: { ballFriction: w.ballFriction * p.ballFriction, speedMul: w.speedMul * p.speedMul, slip: w.slip + p.slip }, injuryReturn: null };
};

test('as condições de uma partida são sempre as mesmas e variam de partida para partida', () => {
  const a = buildConditions({ ...base, seed: 'x1' });
  assert.deepEqual(a, buildConditions({ ...base, seed: 'x1' }));
  const seen = new Set();
  let returns = 0;
  for (let i = 0; i < 300; i++) {
    const c = buildConditions({ ...base, seed: `s${i}` });
    seen.add(c.weather);
    if (c.injuryReturn) returns++;
    if (c.weather === 'rain' || c.weather === 'storm') assert.equal(c.pitch, 'heavy', 'chuva deixa o gramado pesado');
    assert.ok(c.visibility > 0 && c.visibility <= 1);
  }
  assert.deepEqual([...seen].sort(), ['clear', 'cloudy', 'fog', 'rain', 'storm']);
  assert.ok(returns > 60 && returns < 120, `retornos de lesão: ${returns}`);
});

test('efeitos: chuva e gramado pesado se somam; tempo bom não muda nada; neblina só reduz a visibilidade', () => {
  const clear = withWeather('clear', 'good');
  assert.deepEqual(clear.effects, { ballFriction: 1, speedMul: 1, slip: 0 });
  const storm = withWeather('storm', 'heavy');
  assert.ok(Math.abs(storm.effects.ballFriction - 1.3 * 0.8) < 1e-9);
  assert.ok(Math.abs(storm.effects.slip - 0.13) < 1e-9 && storm.effects.speedMul < 0.9);
  const fog = withWeather('fog', 'good');
  assert.deepEqual(fog.effects, { ballFriction: 1, speedMul: 1, slip: 0 });
  assert.ok(fog.visibility < 0.8);
});

test('história do jogo: clássico, final e semifinal somam tensão; torcida pesa mais em jogos grandes', () => {
  const plain = buildConditions({ ...base, seed: 'p' });
  assert.equal(plain.storylines.filter((s) => s.id !== 'injury_return').length, 0);
  assert.equal(plain.crowdFactor, 1);
  const derby = buildConditions({ ...base, awayId: 'jaqueira', homeId: 'tamarindo', seed: 'p' });
  assert.ok(derby.storylines.some((s) => s.id === 'derby' && s.label === 'Clássico da Várzea'));
  assert.equal(derby.crowdFactor, 1.5);
  const final = buildConditions({ competitionId: 'copanacional', homeId: 'titas', awayId: 'realhorizonte', stage: 'Final', week: 5, seed: 'f' });
  assert.ok(final.storylines.some((s) => s.id === 'final'));
  assert.ok(final.baseTension >= 20, 'clássico (10) + final (10)');
  const semi = buildConditions({ competitionId: 'copanacional', homeId: 'titas', awayId: 'cacimba', stage: 'Semifinais', week: 4, seed: 's' });
  assert.ok(semi.storylines.some((s) => s.id === 'semifinal'));
  assert.equal(semi.baseTension, 6 + 0);
});

test('disputa de título e de rebaixamento usam a tabela real, só a partir da 3ª rodada', () => {
  const c = createCareer('Ana', 1);
  const state = c.world.competitions.varzea;
  const [a, b, d, e, f, g] = state.clubs;
  // Rodadas 1 e 2 já jogadas: o clube "a" venceu tudo e o clube "g" perdeu tudo.
  let n = 0;
  for (const fx of state.fixtures) {
    if (fx.week > 2) continue;
    fx.status = 'completed';
    const homeIsA = fx.home === a || fx.away === g;
    fx.result = homeIsA ? { home: 2, away: 0 } : fx.home === g || fx.away === a ? { home: 0, away: 2 } : { home: 1, away: 1 };
    n++;
  }
  assert.ok(n > 0);
  const week3 = state.fixtures.find((fx) => fx.week === 3 && (fx.home === a || fx.away === a));
  const fixA = buildConditions({ ...base, seed: 'q', homeId: week3.home, awayId: week3.away, week: 3, fixtureId: week3.id }, c.world);
  assert.ok(fixA.storylines.some((s) => s.id === 'title' && s.club === a), fixA.storylines.map((s) => s.id).join());
  const week3g = state.fixtures.find((fx) => fx.week === 3 && (fx.home === g || fx.away === g));
  const fixG = buildConditions({ ...base, seed: 'q', homeId: week3g.home, awayId: week3g.away, week: 3, fixtureId: week3g.id }, c.world);
  assert.ok(fixG.storylines.some((s) => s.id === 'relegation' && s.club === g));
  assert.ok(fixG.baseTension >= 8);
  const early = state.fixtures.find((fx) => fx.week === 2);
  assert.ok(!buildConditions({ ...base, seed: 'q', homeId: early.home, awayId: early.away, week: 2, fixtureId: early.id }, c.world).storylines.some((s) => ['title', 'relegation'].includes(s.id)), 'antes da 3ª rodada não há disputa');
  const viaCareer = conditionsFor(c, { seed: 'q', competitionId: 'varzea', homeId: week3.home, awayId: week3.away, fixtureId: week3.id });
  assert.ok(viaCareer.storylines.some((s) => s.id === 'title'), 'conditionsFor lê o calendário real');
});

test('retorno de lesão: sempre um jogador de linha do elenco real do clube', () => {
  let found = 0;
  for (let i = 0; i < 200; i++) {
    const c = buildConditions({ ...base, seed: `r${i}` });
    if (!c.injuryReturn) continue;
    found++;
    const r = c.injuryReturn;
    assert.ok(r.number >= 2 && r.number <= 11, 'goleiro (#1) nunca');
    const clubId = r.team === 'home' ? 'tamarindo' : 'moinho';
    assert.equal(makeRoster(clubId)[r.number - 1].last, r.name);
    assert.ok(c.storylines.some((s) => s.id === 'injury_return' && s.text.includes(r.name)));
  }
  assert.ok(found > 30);
});

test('na simulação: a bola e os jogadores seguem as condições, o árbitro não, e aplicar duas vezes não acumula', () => {
  const storm = withWeather('storm', 'heavy');
  storm.injuryReturn = { team: 'home', clubId: 'tamarindo', number: 9, name: 'X' };
  const m = createMatch({ seed: 2, durationMs: standard });
  const refSpeed = 70;
  const before = new Map(m.players.map((p) => [p, p.moveSpeed]));
  m.sim.setConditions(storm);
  m.sim.setConditions(storm);
  assert.ok(Math.abs(m.ball.friction - 0.35 * storm.effects.ballFriction) < 1e-9);
  for (const p of m.players) {
    const expected = before.get(p) * storm.effects.speedMul * (p.team === 'home' && p.number === 9 ? 0.92 : 1);
    assert.ok(Math.abs(p.moveSpeed - expected) < 1e-9, `${p.team}${p.number}`);
    assert.equal(p.returning, p.team === 'home' && p.number === 9);
  }
  assert.equal(m.referee.moveSpeed, refSpeed, 'o árbitro não perde velocidade');
  m.sim.setConditions(null);
  assert.equal(m.ball.friction, 0.35);
  for (const p of m.players) assert.equal(p.moveSpeed, before.get(p));
});

test('chuva e gramado pesado geram mais contatos; o árbitro perfeito continua sem erros', () => {
  const foulCount = (cond) => {
    let n = 0;
    for (let seed = 1; seed <= 14; seed++) {
      const r = runMatch({ mode: 'perfect', seed, durationMs: standard, conditions: cond });
      n += r.fouls.length;
      assert.equal(r.dec.log.filter((e) => !e.correct).length, 0, 'lances continuam com resposta certa clara');
    }
    return n;
  };
  const clear = foulCount(withWeather('clear', 'good'));
  const wet = foulCount(withWeather('storm', 'heavy'));
  assert.ok(wet > clear, `tempestade ${wet} > tempo bom ${clear}`);
});

test('evidências: visibilidade reduzida só em lance distante e retorno de lesão em quem voltou', () => {
  const mk = (cond, victimReturning) => {
    const m = createMatch({ seed: 5, durationMs: standard });
    for (let i = 0; i < 60 * 30 && m.sim.state !== 'playing'; i++) m.advance('manual');
    m.sim.setConditions(cond);
    const off = m.players.find((p) => p.team === 'away' && p.role === 'DEF');
    const vic = m.players.find((p) => p.team === 'home' && p.role === 'FWD');
    vic.returning = victimReturning;
    return { m, off, vic };
  };
  const fire = ({ m, off, vic }, far) => {
    Object.assign(vic, { x: L.cx + 150, y: L.cy });
    Object.assign(m.referee, { x: far ? L.left + 5 : vic.x + 5, y: far ? L.top + 5 : vic.y });
    let inc = null;
    m.events.once('incident-registered', (i) => (inc = i));
    m.sim.registerIncident({ type: INCIDENT.LIGHT_FOUL, level: 'light', offender: off, victim: vic, evidence: ['contato antes da bola'], contact: true });
    return inc;
  };
  const fog = withWeather('fog', 'good');
  assert.ok(fire(mk(fog, false), true).evidence.includes('visibilidade reduzida'));
  assert.ok(!fire(mk(fog, false), false).evidence.includes('visibilidade reduzida'), 'lance perto');
  assert.ok(!fire(mk(withWeather('clear', 'good'), false), true).evidence.includes('visibilidade reduzida'), 'visibilidade normal');
  assert.ok(fire(mk(withWeather('clear', 'good'), true), false).evidence.includes('retorno de lesão'));
  assert.ok(!fire(mk(withWeather('clear', 'good'), false), false).evidence.includes('retorno de lesão'));
});

test('falta ignorada em quem voltou de lesão esquenta mais o jogo', () => {
  const missed = (evidence) => ({ type: 'light_foul', errors: ['FOUL_MISSED'], correct: false, evidence, offender: { team: 'away', number: 4 }, victim: { team: 'home', number: 9 }, actual: { foulCalled: false, cards: [] }, expected: { foul: true } });
  const a = new MatchMood();
  a.onDecision(missed(['contato antes da bola']));
  const b = new MatchMood();
  b.onDecision(missed(['contato antes da bola', 'retorno de lesão']));
  assert.equal(b.tension - a.tension, 6);
});

test('minutos finais: só depois dos 80, com no máximo 1 gol de diferença; o clima não esfria enquanto durar', () => {
  assert.equal(isLateDrama('80:00', { home: 1, away: 1 }), true);
  assert.equal(isLateDrama('79:59', { home: 1, away: 1 }), false);
  assert.equal(isLateDrama('88:10', { home: 2, away: 1 }), true);
  assert.equal(isLateDrama('88:10', { home: 3, away: 1 }), false);
  const m = new MatchMood(0);
  assert.equal(m.setLate(true), true);
  assert.equal(m.setLate(true), false, 'só avisa uma vez');
  assert.ok(m.tension >= 55);
  m.update(10 * 60000);
  assert.equal(m.tension, 50, 'não esfria abaixo de 50 durante os minutos finais');
  const snap = m.capture();
  m.setLate(false);
  m.update(10 * 60000);
  assert.equal(m.tension, 0);
  m.restore(snap);
  assert.equal(m.late, true);
  assert.equal(m.summary().late, true);
});

test('na partida: minutos finais, banco e torcida reagem uma vez e só como contexto', () => {
  const m = createMatch({ seed: 6, durationMs: standard });
  for (let i = 0; i < 60 * 30 && m.sim.state !== 'playing'; i++) m.advance('manual');
  const seen = { late: 0, bench: [], crowd: 0 };
  m.events.on('late-drama', () => seen.late++);
  m.events.on('bench-protest', (d) => seen.bench.push(d.team));
  m.events.on('crowd-pressure', () => seen.crowd++);

  // Minutos finais com o placar em aberto.
  m.sim.period = 2;
  m.sim.getClock = () => ({ text: '83:00' });
  m.dec.update(16);
  m.dec.update(16);
  assert.equal(seen.late, 1);
  assert.ok(m.dec.mood.late);
  m.sim.score = { home: 4, away: 0 };
  m.dec.update(16);
  assert.equal(m.dec.mood.late, false, 'goleada: o jogo deixou de estar em aberto');

  // Banco reclama de falta real ignorada com o clima esquentando (uma vez por 30 s, por time).
  m.dec.mood.add(45);
  const off = m.players.find((p) => p.team === 'away' && p.role === 'DEF');
  const vic = m.players.find((p) => p.team === 'home' && p.role === 'FWD');
  const ignore = () => {
    let inc = null;
    m.events.once('incident-registered', (i) => (inc = i));
    m.sim.registerIncident({ type: INCIDENT.LIGHT_FOUL, level: 'light', offender: off, victim: vic, evidence: ['contato antes da bola'], contact: true });
    m.dec.finalize(inc);
  };
  ignore();
  ignore();
  assert.deepEqual(seen.bench, ['home']);
  assert.equal(m.dec.mood.counts.benchProtests, 1);
  m.sim.time += 31000;
  ignore();
  assert.equal(seen.bench.length, 2);

  // Torcida irritada pressiona (no máximo 3 vezes, uma por irritação).
  m.dec.mood.tension = 50;
  m.dec.mood.crowd = -50;
  const t0 = m.dec.mood.tension;
  m.dec.update(16);
  m.dec.update(16);
  assert.equal(seen.crowd, 1);
  assert.ok(m.dec.mood.tension >= t0 + 4 - 1);
  for (let i = 0; i < 6; i++) {
    m.dec.mood.crowd = 0;
    m.dec.update(16);
    m.dec.mood.crowd = -60;
    m.dec.update(16);
  }
  assert.equal(m.dec.mood.counts.crowdPressure, 3);
});

// ------------------------------------------------------------ carreira, redes sociais e relatório
const FACTS = { decisions: 8, correct: 7, yellow: 0, red: 0, redWrong: 0, fouls: 3, penalties: 0, penaltiesCorrect: 0, penaltiesMissed: 0, wrongCalls: 0, missedFouls: 0, simulationsPunished: 0, simulationsMissed: 0, offsides: 0, offsidesCorrect: 0, offsidesMissed: 0, advantageOk: 0, advantageFailed: 0, whistles: 0 };
const res = (conditions) => ({ nota: 7, label: 'Bom', categories: [{ label: 'Posicionamento', points: 5, max: 10, ratio: 0.5 }], mistakes: [], hits: [], counts: { unnecessaryWhistles: 0 }, score: { home: 1, away: 0 }, extras: { ...FACTS }, conditions });
const fx = (matchId) => ({ competitionId: 'varzea', homeId: 'tamarindo', awayId: 'moinho', importance: 1, matchId, duration: 'standard' });

test('resumo das condições para o registro: só dados reais, com as faltas sofridas por quem voltou', () => {
  const cond = withWeather('rain', 'heavy');
  cond.injuryReturn = { team: 'home', clubId: 'tamarindo', number: 9, name: 'Moura' };
  const log = [
    { victim: { team: 'home', number: 9 }, actual: { foulCalled: true }, expected: { foul: true } },
    { victim: { team: 'home', number: 9 }, actual: { foulCalled: false }, expected: { foul: true } },
    { victim: { team: 'home', number: 3 }, actual: { foulCalled: true }, expected: { foul: true } },
    { type: 'unnecessary_whistle' },
  ];
  assert.equal(returnFouls(cond, log), 1);
  const s = conditionsSummary(cond, { returnFouled: 1, late: true });
  assert.equal(s.injuryReturn.fouled, 1);
  assert.equal(s.late, true);
  assert.equal(conditionsSummary(null), null);
});

test('na carreira: condições entram no registro e viram publicações com dados reais, sem inventar', () => {
  const cond = withWeather('storm', 'heavy');
  cond.injuryReturn = { team: 'home', clubId: 'tamarindo', number: 9, name: 'Moura' };
  cond.storylines = [{ id: 'title', label: 'Disputa de título', text: 'Tamarindo FC briga pelo título da Copa Várzea Verde.', tension: 8 }];
  const summary = conditionsSummary(cond, { returnFouled: 2, late: true });
  const c = createCareer('Ana', 2);
  applyMatch(c, fx('c1'), res(summary));
  assert.equal(c.history[0].conditions.weather, 'storm');
  const get = (k) => c.social.find((p) => p.key === `c1:post:${k}`);
  assert.ok(get('cond-weather').text.includes('chuva forte') && get('cond-weather').technical === false);
  assert.ok(get('cond-title').text.includes('briga pelo título'));
  assert.ok(get('cond-return').author.kind === 'clube' && get('cond-return').text.includes('Moura (#9)'));
  assert.ok(get('cond-return-fouled').text.includes('2 faltas marcadas'));
  assert.ok(get('cond-late').text.includes('80 minutos'));

  const calm = createCareer('Ana', 3);
  applyMatch(calm, fx('c2'), res(conditionsSummary(withWeather('clear', 'good'))));
  assert.ok(!calm.social.some((p) => p.key.startsWith('c2:post:cond-')), 'tempo bom e nada de especial: nenhuma publicação de condições');
  const none = createCareer('Ana', 4);
  applyMatch(none, fx('c3'), res(null));
  assert.equal(none.history[0].conditions, null);
  assert.equal(applyMatch(c, fx('c1'), res(summary)), null);
  assert.equal(c.social.filter((p) => p.key.startsWith('c1:post:cond-')).length, 5);
});

test('relatório: contexto da partida explica as condições sem mexer na nota', () => {
  const entry = { incidentId: 1, type: 'light_foul', level: 'light', time: 1, clock: '10:00', period: 1, refDistance: 20, offender: { team: 'away', number: 9, name: 'J9' }, victim: { team: 'home', number: 10, name: 'J10' }, evidence: ['contato antes da bola'], expected: { foul: true, card: null }, actual: { foulCalled: true, cards: [], advantage: null }, errors: [], correct: true };
  const log = [entry];
  const grade = gradeMatch(log);
  const facts = matchFacts(log);
  const cond = conditionsSummary({ ...withWeather('storm', 'heavy'), storylines: [{ id: 'final', label: 'Final', text: 'Uma final: quem perder fica sem o título.', tension: 10 }], injuryReturn: { team: 'home', number: 9, name: 'Moura' } }, { late: true, returnFouled: 1 });
  const r = buildReport({ log, grade, facts, conditions: cond });
  assert.ok(r.context.some((t) => t.includes('Chuva forte') && t.includes('escorregadias')));
  assert.ok(r.context.some((t) => t.includes('Uma final')));
  assert.ok(r.context.some((t) => t.includes('Moura (#9) voltou de lesão e sofreu 1 falta')));
  assert.ok(r.context.some((t) => t.includes('minutos finais')));
  assert.ok(r.context[r.context.length - 1].includes('Nada disso muda o que é certo'));
  assert.equal(r.summary.nota, buildReport({ log, grade, facts }).summary.nota);
  assert.deepEqual(buildReport({ log, grade, facts }).context, []);
  assert.ok(reportToHtml(r).includes('Contexto da partida'));
  assert.ok(!reportToHtml(buildReport({ log, grade, facts })).includes('Contexto da partida'));
});
