import test from 'node:test';
import assert from 'node:assert/strict';
import { createMatch, runMatch } from './helpers/harness.mjs';
import { FIELD_RECT } from '../src/config.js';
import { DURATIONS } from '../src/config.js';
import { contactGrade, tacticalLevel, buildExpected, evaluateDecision, incidentLabel, describeIncident, PERSISTENT_FOULS, INCIDENT } from '../src/systems/MatchRules.js';
import { describeEntry } from '../src/systems/RefereeGrading.js';
import { ownGoalX } from '../src/systems/PlayerAI.js';

const L = FIELD_RECT;
const standard = DURATIONS.find((d) => d.id === 'standard').ms;

// Partida em jogo corrido, com todos os jogadores afastados para eu montar cada cena sozinho.
function scene(seed = 3) {
  const m = createMatch({ seed, durationMs: standard });
  for (let i = 0; i < 60 * 30 && m.sim.state !== 'playing'; i++) m.advance('manual');
  assert.equal(m.sim.state, 'playing');
  for (const p of m.players) Object.assign(p, { x: L.left + 20, y: L.top + 20, vx: 0, vy: 0, fallTimer: 0, freezeTimer: 0, tackleCooldown: 0 });
  return m;
}
const pick = (m, team, role) => m.players.filter((p) => p.team === team && p.role === role);
function capture(m, fn) {
  let inc = null;
  m.events.once('incident-registered', (i) => (inc = i));
  fn();
  return inc;
}
// Faz a próxima rolagem do sorteio valer `values` (em ordem) e depois volta ao sorteio normal.
function rig(m, values) {
  const real = m.sim.rng;
  const queue = [...values];
  m.sim.rng = { ...real, frac: () => (queue.length ? queue.shift() : real.frac()) };
  return () => (m.sim.rng = real);
}

test('grau de contato: leve, moderado e forte pela velocidade relativa', () => {
  assert.deepEqual([contactGrade(10).text, contactGrade(29.9).level], ['contato leve', 1]);
  assert.deepEqual([contactGrade(30).text, contactGrade(60).text], ['contato moderado', 'contato moderado']);
  assert.deepEqual([contactGrade(61).text, contactGrade(120).level], ['contato forte', 3]);
});

test('falta tática: ataque promissor é amarelo, último defensor perto do gol é vermelho, o resto não é tática', () => {
  const base = { inAttackHalf: true, speed: 60, forward: 0.9, defendersAhead: 2, distGoal: 120 };
  assert.equal(tacticalLevel(base).level, 'yellow');
  assert.equal(tacticalLevel({ ...base, defendersAhead: 0 }).level, 'red');
  assert.equal(tacticalLevel({ ...base, defendersAhead: 0, distGoal: 300 }).level, 'yellow', 'longe do gol não é chance clara');
  assert.equal(tacticalLevel({ ...base, inAttackHalf: false }), null);
  assert.equal(tacticalLevel({ ...base, defendersAhead: 6 }), null, 'muitos defensores: não era ataque promissor');
  assert.equal(tacticalLevel({ ...base, forward: 0.1 }), null);
});

test('na simulação: falta que para ataque promissor vira amarelo mesmo com contato leve', () => {
  const m = scene(4);
  const h = pick(m, 'home', 'FWD')[0];
  const t = pick(m, 'away', 'DEF')[0];
  const d = h.attackDir;
  Object.assign(h, { x: L.cx + d * 140, y: L.cy, vx: d * 40, vy: 0 });
  Object.assign(t, { x: h.x + d * 8, y: L.cy, vx: d * 5, vy: 0 });
  const others = pick(m, 'away', 'DEF').concat(pick(m, 'away', 'MID')).filter((p) => p !== t);
  others.forEach((p, i) => Object.assign(p, { x: h.x + d * (60 + i * 5), y: L.cy + 20 })); // todos à frente: não é tática
  const rest = rig(m, [0.99]); // a disputa NÃO é limpa
  const none = capture(m, () => m.sim.resolveTackle(t, h));
  rest();
  assert.ok(!none.evidence.some((e) => e.startsWith('falta tática')));

  const m2 = scene(4);
  const h2 = pick(m2, 'home', 'FWD')[0];
  const t2 = pick(m2, 'away', 'DEF')[0];
  const d2 = h2.attackDir;
  Object.assign(h2, { x: L.cx + d2 * 140, y: L.cy, vx: d2 * 40, vy: 0 });
  Object.assign(t2, { x: h2.x + d2 * 8, y: L.cy, vx: d2 * 5, vy: 0 });
  pick(m2, 'away', 'DEF').concat(pick(m2, 'away', 'MID')).filter((p) => p !== t2).forEach((p) => Object.assign(p, { x: h2.x - d2 * 120, y: L.cy })); // atrás do jogador: nenhum à frente
  t2.aggression = 0.1;
  const restore = rig(m2, [0.99]);
  const inc = capture(m2, () => m2.sim.resolveTackle(t2, h2));
  restore();
  assert.equal(inc.type, INCIDENT.SERIOUS_FOUL);
  assert.equal(inc.level, 'red', 'último defensor perto do gol');
  assert.equal(inc.expected.card, 'red');
  assert.ok(inc.evidence.includes('falta tática: evitou chance clara de gol'));
  assert.ok(inc.evidence.includes('contato leve') || inc.evidence.includes('contato moderado'));
});

test('falta tática com muitos defensores à frente não sobe a gravidade (e a gravidade nunca desce)', () => {
  const m = scene(5);
  const h = pick(m, 'home', 'FWD')[0];
  const t = pick(m, 'away', 'DEF')[0];
  const d = h.attackDir;
  Object.assign(h, { x: L.cx + d * 140, y: L.cy, vx: d * 40, vy: 0 });
  Object.assign(t, { x: h.x + d * 8, y: L.cy, vx: d * 5, vy: 0 });
  t.aggression = 0.9; // imprudente
  pick(m, 'away', 'DEF').concat(pick(m, 'away', 'MID')).filter((p) => p !== t).forEach((p, i) => Object.assign(p, { x: h.x + d * (50 + i * 4), y: L.cy }));
  const restore = rig(m, [0.99]);
  const inc = capture(m, () => m.sim.resolveTackle(t, h));
  restore();
  assert.ok(!inc.evidence.some((e) => e.startsWith('falta tática')));
  assert.ok(inc.evidence.includes('entrada imprudente'));
});

test('reincidência: a partir da 3ª falta marcada, falta leve pede amarelo e não aceita vantagem', () => {
  assert.equal(PERSISTENT_FOULS, 2);
  const ex = buildExpected(INCIDENT.LIGHT_FOUL, 'light', { persistent: true });
  assert.deepEqual([ex.card, ex.cardTarget, ex.advantageAllowed], ['yellow', 'offender', false]);
  assert.equal(buildExpected(INCIDENT.LIGHT_FOUL, 'light').card, null);

  const m = scene(6);
  const off = pick(m, 'away', 'DEF')[0];
  const vic = pick(m, 'home', 'FWD')[0];
  const mk = () => capture(m, () => m.sim.registerIncident({ type: INCIDENT.LIGHT_FOUL, level: 'light', offender: off, victim: vic, evidence: ['contato antes da bola'], contact: true }));
  off.foulsCommitted = 1;
  assert.equal(mk().persistent, false);
  off.foulsCommitted = 2;
  const inc = mk();
  assert.equal(inc.persistent, true);
  assert.equal(inc.expected.card, 'yellow');
  assert.ok(inc.evidence.includes('reincidente: 3ª falta'));

  // Falta sem cartão é erro; com amarelo para o autor é certo.
  inc.actual = { foulCalled: true, cards: [], advantage: null, decided: true };
  assert.deepEqual(evaluateDecision(inc).errors, ['CARD_MISSED']);
  inc.actual.cards = [{ player: off, color: 'yellow' }];
  assert.equal(evaluateDecision(inc).correct, true);
});

test('a falta marcada entra no contador do jogador e o contador volta junto com o VAR', () => {
  const m = scene(7);
  const off = pick(m, 'away', 'DEF')[0];
  const vic = pick(m, 'home', 'FWD')[0];
  const inc = capture(m, () => m.sim.registerIncident({ type: INCIDENT.LIGHT_FOUL, level: 'light', offender: off, victim: vic, evidence: ['contato antes da bola'], contact: true }));
  inc.actual.foulCalled = true;
  const snap = m.sim.captureState();
  m.dec.finalize(inc);
  assert.equal(off.foulsCommitted, 1);
  const ignored = capture(m, () => m.sim.registerIncident({ type: INCIDENT.LIGHT_FOUL, level: 'light', offender: off, victim: vic, evidence: ['contato antes da bola'], contact: true }));
  m.dec.finalize(ignored); // ignorada: não conta
  assert.equal(off.foulsCommitted, 1);
  m.sim.restoreState(snap);
  assert.equal(off.foulsCommitted, 0, 'voltar no tempo desfaz a contagem');
  assert.equal(off.suspectFalls, 0);
});

test('mão na bola com braço afastado é falta (pênalti na área); com braço junto ao corpo não é falta', () => {
  const m = scene(8);
  const p = pick(m, 'home', 'MID')[0];
  const o = pick(m, 'away', 'DEF')[0];
  const d = p.attackDir;
  // Fora da área: falta leve.
  Object.assign(p, { x: L.cx, y: L.cy });
  Object.assign(o, { x: L.cx + d * 40, y: L.cy });
  const rest = rig(m, [0.01, 0.1]); // acontece e é intencional
  const foul = capture(m, () => m.sim.checkHandball(p, { type: 'pass', vx: d * 100, vy: 0 }));
  rest();
  assert.equal(foul.subtype, 'handball');
  assert.equal(foul.type, INCIDENT.LIGHT_FOUL);
  assert.equal(foul.expected.foul, true);
  assert.equal(incidentLabel(foul), 'Mão na bola');
  assert.ok(foul.evidence.includes('braço afastado do corpo'));
  assert.ok(describeIncident(foul).includes('braço'));

  // Dentro da área do defensor: pênalti. O intervalo de espera entre mãos na bola vale.
  assert.equal(capture(m, () => m.sim.checkHandball(p, { type: 'pass', vx: d * 100, vy: 0 })), null, 'só uma mão na bola a cada 30 s');
  m.sim.lastHandballTime = -Infinity;
  Object.assign(p, { x: ownGoalX(o.attackDir) + o.attackDir * 70, y: L.cy });
  Object.assign(o, { x: ownGoalX(o.attackDir) + o.attackDir * 30, y: L.cy });
  const rest2 = rig(m, [0.01, 0.1]);
  const pen = capture(m, () => m.sim.checkHandball(p, { type: 'cross', vx: -o.attackDir * 100, vy: 0 }));
  rest2();
  assert.equal(pen.type, INCIDENT.PENALTY);
  assert.equal(pen.inArea, true);

  // Acidental: não é falta; marcar é erro.
  m.sim.lastHandballTime = -Infinity;
  Object.assign(p, { x: L.cx, y: L.cy });
  Object.assign(o, { x: L.cx + d * 40, y: L.cy });
  const rest3 = rig(m, [0.01, 0.99]);
  const acc = capture(m, () => m.sim.checkHandball(p, { type: 'shoot', vx: d * 200, vy: 0 }));
  rest3();
  assert.equal(acc.type, INCIDENT.CHALLENGE);
  assert.equal(acc.expected.foul, false);
  assert.ok(acc.evidence.includes('braço junto ao corpo'));
  acc.actual = { foulCalled: true, cards: [], advantage: null, decided: true };
  assert.deepEqual(evaluateDecision(acc).errors, ['FOUL_WRONG']);
  m.dec.finalize(acc);
  assert.equal(describeEntry(m.dec.log[m.dec.log.length - 1]).label, 'Mão na bola');
});

test('jogando de verdade: os novos lances aparecem, são coerentes e uma arbitragem perfeita continua sem erros', () => {
  let hand = 0, exag = 0, persistent = 0, tactical = 0, falls = 0, errors = 0, lances = 0;
  for (let seed = 1; seed <= 10; seed++) {
    const r = runMatch({ mode: 'perfect', seed, durationMs: standard });
    for (const e of r.dec.log) {
      lances++;
      if (!e.correct) errors++;
      if (e.subtype === 'handball') hand++;
      if (e.persistent) {
        persistent++;
        assert.equal(e.expected.card, 'yellow');
      }
      if ((e.evidence || []).some((x) => x.startsWith('falta tática'))) {
        tactical++;
        assert.ok(e.expected.card === 'yellow' || e.expected.card === 'red');
      }
      if (e.type === 'simulation' && e.evidence.includes('queda exagerada')) {
        exag++;
        assert.equal(e.expected.foul, false);
        assert.equal(e.expected.card, 'yellow');
      }
    }
    falls += r.sim.players.reduce((a, p) => a + (p.suspectFalls || 0), 0);
  }
  assert.equal(errors, 0, 'o jogador perfeito (que lê as evidências) nunca erra');
  assert.ok(hand >= 5 && exag >= 3 && falls >= 3, `mão ${hand}, exagero ${exag}, quedas ${falls}`);
  assert.ok(persistent + tactical >= 1, `reincidência ${persistent}, tática ${tactical}`);
  assert.ok(lances / 10 >= 10, 'ritmo de lances preservado');
});
