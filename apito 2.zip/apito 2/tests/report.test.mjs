import test from 'node:test';
import assert from 'node:assert/strict';
import { gradeMatch, matchFacts, varFacts } from '../src/systems/RefereeGrading.js';
import { buildReport, tipFor, consistencyIssues } from '../src/systems/TechnicalReport.js';
import { reportToHtml } from '../src/ui/reportHtml.js';
import { createCareer, applyMatch } from '../src/systems/CareerSystem.js';
import { runMatch } from './helpers/harness.mjs';
import { DURATIONS } from '../src/config.js';

const P = (team, n = 9) => ({ team, number: n, name: `J${n}` });
let id = 0;
function entry(over = {}) {
  id += 1;
  return {
    incidentId: id, type: 'light_foul', level: 'light', time: id * 1000, clock: `${String(10 + id).padStart(2, '0')}:00`, period: 1, refDistance: 20,
    offender: P('away'), victim: P('home', 10), evidence: ['contato antes da bola', 'contato leve'],
    expected: { foul: true, card: null, restart: 'free_kick', cardTarget: null, advantageAllowed: true },
    actual: { foulCalled: true, cards: [], advantage: null, decided: true },
    errors: [], notes: [], correct: true, varChanged: false, tension: 0, ...over,
  };
}
const ignored = (over = {}) => entry({ actual: { foulCalled: false, cards: [], advantage: null, decided: true }, errors: ['FOUL_MISSED'], correct: false, ...over });
const report = (log, extra = {}) => {
  const grade = gradeMatch(log);
  const facts = { ...matchFacts(log), ...varFacts(extra.varReviews) };
  return { grade, facts, r: buildReport({ log, grade, facts, varReviews: extra.varReviews || [], mood: extra.mood || null, refStats: extra.refStats || null }) };
};

test('arbitragem perfeita: sem lances a melhorar nem recomendações urgentes, e o texto explica o que não entra na nota', () => {
  const log = [entry(), entry({ type: 'challenge', evidence: ['bola jogada primeiro', 'contato leve'], expected: { foul: false, card: null }, actual: { foulCalled: false, cards: [], decided: true } }), entry()];
  const { r, grade } = report(log, { mood: { peak: 10, label: 'Calmo', crowd: 0, graveSpikes: 0 }, refStats: { travel: 5600, fieldWidth: 560 } });
  assert.equal(r.misses.length, 0);
  assert.equal(r.recommendations.length, 0);
  assert.equal(r.summary.nota, grade.nota);
  assert.ok(r.summary.headline.includes('alto nível'));
  assert.ok(r.outside.some((t) => t.includes('não altera a nota')) && r.outside.some((t) => t.includes('Quantidade de cartões')));
  assert.equal(r.positioning.fieldLengths, 10);
  assert.ok(JSON.stringify(r).length < 8000, 'compacto o bastante para guardar no histórico');
});

test('relatório não recalcula nem altera a nota', () => {
  const log = [entry(), ignored(), entry()];
  const grade = gradeMatch(log);
  const snap = JSON.stringify(grade);
  buildReport({ log, grade, facts: matchFacts(log), varReviews: [], mood: null, refStats: null });
  assert.equal(JSON.stringify(grade), snap);
});

test('lances mal interpretados vêm ordenados por gravidade, com o que o painel mostrava e a dica certa', () => {
  const sim = entry({ type: 'simulation', level: 'none', evidence: ['contato mínimo (leve)', 'queda exagerada'], expected: { foul: false, card: 'yellow', cardTarget: 'victim', restart: 'indirect_free_kick' }, actual: { foulCalled: true, cards: [], advantage: null, decided: true }, errors: ['FOUL_WRONG'], correct: false });
  const off = entry({ type: 'offside', level: 'none', evidence: ['impedido no passe'], actual: { foulCalled: false, cards: [], advantage: null, decided: true }, errors: ['FOUL_MISSED'], correct: false });
  const serious = entry({ type: 'serious_foul', level: 'yellow', evidence: ['entrada por trás', 'alta velocidade'], expected: { foul: true, card: 'yellow', cardTarget: 'offender', restart: 'free_kick', advantageAllowed: false }, actual: { foulCalled: true, cards: [{ team: 'away', number: 9, name: 'J9', color: 'warning' }], advantage: null, decided: true }, errors: ['CARD_MISSED'], correct: false });
  const { r } = report([entry(), ignored(), sim, off, serious]);
  assert.ok(r.misses.length === 4);
  const tips = r.misses.map((m) => m.tip).join(' | ');
  assert.ok(tips.includes('Contato mínimo com queda exagerada'));
  assert.ok(tips.includes('Confira a posição do atacante'));
  assert.ok(tips.includes('Conte as agravantes'));
  assert.ok(r.misses.every((m) => m.evidence.length && m.did && m.should));
  assert.ok(r.misses.find((m) => m.label === 'Simulação').evidence.includes('queda exagerada'));
  const sev = r.misses.map((m) => m.label);
  assert.ok(sev.indexOf('Falta leve') >= 0);
});

test('recomendações de treino: no máximo 3, com motivo real e o treino correspondente', () => {
  const log = [entry(), ignored(), ignored({ clock: '33:00' }), entry({ type: 'offside', level: 'none', evidence: ['impedido'], actual: { foulCalled: false, cards: [], advantage: null, decided: true }, errors: ['FOUL_MISSED'], correct: false }), entry({ type: 'simulation', level: 'none', evidence: ['sem contato'], expected: { foul: false, card: 'yellow', cardTarget: 'victim' }, actual: { foulCalled: true, cards: [], advantage: null, decided: true }, errors: ['FOUL_WRONG'], correct: false })];
  const { r } = report(log);
  assert.ok(r.recommendations.length >= 2 && r.recommendations.length <= 3);
  const ids = r.recommendations.map((x) => x.id);
  assert.ok(ids.includes('faltas'));
  const faltas = r.recommendations.find((x) => x.id === 'faltas');
  assert.ok(faltas.reason.includes('33:00') && faltas.training === 'Reconhecer faltas em situações ilustradas');
  assert.ok(r.recommendations.every((x) => x.training && x.reason));
});

test('VAR: alteração que continuou errada vira recomendação; uso do VAR aparece com os números reais', () => {
  const reviews = [
    { clock: '20:00', label: 'Pênalti', kind: 'change', initial: 'Nada marcado (o jogo segue)', final: 'Pênalti marcado', eligible: true, finalCorrect: false },
    { clock: '40:00', label: 'Falta leve', kind: 'keep', initial: 'Falta marcada', final: 'Falta marcada', eligible: false, finalCorrect: true },
  ];
  const { r } = report([entry(), entry()], { varReviews: reviews });
  assert.equal(r.var.used, true);
  assert.deepEqual([r.var.reviews, r.var.changed, r.var.worsened], [2, 1, 1]);
  assert.ok(r.recommendations.some((x) => x.id === 'var'));
  assert.ok(r.var.lines[0].includes('continuou errado'));
  assert.equal(report([entry()]).r.var.used, false);
});

test('posicionamento: longe dos lances gera alerta e recomendação; perto não', () => {
  const far = [entry({ refDistance: 220, clock: '15:00' }), entry({ refDistance: 200, clock: '25:00' }), entry({ refDistance: 10 })];
  const { r } = report(far);
  assert.equal(r.positioning.far, 2);
  assert.equal(r.positioning.near, 1);
  assert.deepEqual(r.positioning.farClocks, ['15:00', '25:00']);
  assert.ok(r.recommendations.some((x) => x.id === 'posicionamento'));
  assert.ok(!report([entry({ refDistance: 10 }), entry({ refDistance: 25 })]).r.recommendations.some((x) => x.id === 'posicionamento'));
});

test('consistência: mesma situação marcada e ignorada, ou cartões diferentes, é apontada; vantagem não conta', () => {
  assert.equal(consistencyIssues([entry(), entry()]).issues.length, 0);
  const a = consistencyIssues([entry(), ignored({ clock: '44:00' })]);
  assert.equal(a.issues.length, 1);
  assert.ok(a.issues[0].text.includes('44:00') && a.issues[0].text.includes('1 marcado e 1 ignorado'));
  const adv = consistencyIssues([entry(), entry({ actual: { foulCalled: false, cards: [], advantage: 'success', decided: true }, errors: [], correct: true })]);
  assert.equal(adv.issues.length, 0, 'vantagem bem aplicada é critério, não inconsistência');
  const card = (color) => entry({ type: 'serious_foul', level: 'yellow', expected: { foul: true, card: 'yellow', cardTarget: 'offender', advantageAllowed: false }, actual: { foulCalled: true, cards: [{ team: 'away', number: 9, name: 'J9', color }], advantage: null, decided: true } });
  assert.ok(consistencyIssues([card('yellow'), card('red')]).issues.some((i) => i.kind === 'card'));
  const { r } = report([entry(), ignored()]);
  assert.equal(r.consistency.verdict, 'bad');
});

test('dicas cobrem os lances novos do Upgrade 1', () => {
  assert.ok(tipFor({ type: 'unnecessary_whistle', errors: [] }).includes('Só apite'));
  assert.ok(tipFor(entry({ type: 'goal_check', errors: ['FOUL_MISSED'] })).includes('anulado'));
  assert.ok(tipFor(entry({ type: 'goal_check', errors: ['FOUL_WRONG'] })).includes('o gol vale'));
  assert.ok(tipFor(entry({ subtype: 'handball', evidence: ['mão na bola', 'braço afastado do corpo'], errors: ['FOUL_MISSED'] })).includes('Braço afastado'));
  assert.ok(tipFor(entry({ subtype: 'handball', evidence: ['mão na bola', 'braço junto ao corpo'], errors: ['FOUL_WRONG'] })).includes('Braço junto'));
  assert.ok(tipFor(entry({ evidence: ['falta tática: interrompeu ataque promissor'], errors: ['CARD_MISSED'] })).includes('ataque promissor'));
  assert.ok(tipFor(entry({ persistent: true, evidence: ['reincidente: 3ª falta'], errors: ['CARD_MISSED'] })).includes('3ª falta'));
});

test('a seção "fora da nota" mostra decisões impopulares e populares sem mexer na nota', () => {
  const log = [entry({ favored: 'away' }), ignored({ favored: 'home' }), entry()];
  const { r, grade } = report(log, { mood: { peak: 30, label: 'Tenso', crowd: -40, graveSpikes: 0 } });
  assert.ok(r.outside.some((t) => t.includes('Irritada')));
  assert.ok(r.outside.some((t) => t.includes('mal recebida') && t.includes('contam como acerto')));
  assert.ok(r.outside.some((t) => t.includes('agradou') && t.includes('contam como erro')));
  assert.equal(grade.nota, gradeMatch(log).nota);
});

test('HTML do relatório: todas as seções, texto escapado e estado vazio', () => {
  const { r } = report([entry(), ignored({ evidence: ['<b>x</b>'] })]);
  const html = reportToHtml(r);
  for (const t of ['Relatório da Comissão de Arbitragem', 'Por que essa nota', 'Posicionamento e movimentação', 'Consistência', 'Controle disciplinar', 'Uso do VAR', 'melhor interpretados', 'Recomendações de treinamento', 'O que não entra na nota']) assert.ok(html.includes(t), t);
  assert.ok(!html.includes('<b>x</b>') && html.includes('&lt;b&gt;x&lt;/b&gt;'));
  assert.ok(reportToHtml(null).includes('não tem relatório'));
});

test('na carreira: o relatório fica no histórico (sem duplicar) e a supervisão recomenda o treino', () => {
  const c = createCareer('Ana', 41);
  const log = [entry(), ignored(), ignored({ clock: '33:00' })];
  const { r, grade, facts } = report(log);
  const res = { nota: grade.nota, label: grade.label, categories: grade.categories, mistakes: grade.mistakes, hits: grade.hits, counts: { unnecessaryWhistles: 0 }, score: { home: 1, away: 0 }, extras: facts, report: r };
  const fixture = { competitionId: 'varzea', homeId: 'tamarindo', awayId: 'moinho', importance: 1, matchId: 'r1', duration: 'standard' };
  applyMatch(c, fixture, res);
  assert.equal(c.history[0].report.summary.nota, grade.nota);
  assert.ok(c.history[0].report.recommendations.length);
  const mail = c.inbox.find((m) => m.key === 'r1:mail:report');
  assert.ok(mail.lines.some((l) => l.startsWith('Recomendação de treino: Reconhecer faltas')));
  assert.equal(applyMatch(c, fixture, res), null);
  assert.equal(c.history.length, 1);
});

test('partida de verdade: o relatório fica coerente com a nota e nunca explode', () => {
  const standard = DURATIONS.find((d) => d.id === 'standard').ms;
  for (const seed of [1, 2, 3]) {
    for (const mode of ['perfect', 'random', 'ignore']) {
      const m = runMatch({ mode, seed, durationMs: standard });
      const grade = gradeMatch(m.dec.log);
      const facts = { ...matchFacts(m.dec.log), ...varFacts([]) };
      const r = buildReport({ log: m.dec.log, grade, facts, varReviews: [], mood: m.dec.mood.summary(), refStats: { travel: 4000, fieldWidth: 560 } });
      assert.equal(r.summary.nota, grade.nota);
      assert.equal(r.decisions.right + (r.decisions.total - r.decisions.right), r.decisions.total);
      assert.ok(r.why.length === grade.categories.length && r.recommendations.length <= 3);
      assert.ok(reportToHtml(r).length > 500);
      if (mode === 'perfect') assert.equal(r.misses.length, 0);
    }
  }
});
