import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createCareer, applyMatch, getOffers, skipWeek, declineOffer, migrateCareer, SEASON_ROUNDS, CAREER_VERSION,
} from '../src/systems/CareerSystem.js';
import { unreadCount, setRead, markAllRead, publicImage, toneOf, COMMS_LIMITS, syncWeekEmail, publish } from '../src/systems/CommsSystem.js';
import { gradeMatch, matchFacts } from '../src/systems/RefereeGrading.js';
import { runMatch } from './helpers/harness.mjs';

const BASE_FACTS = {
  decisions: 10, correct: 9, yellow: 0, red: 0, redWrong: 0, fouls: 3, penalties: 0, penaltiesCorrect: 0, penaltiesMissed: 0, wrongCalls: 0,
  missedFouls: 0, simulationsPunished: 0, simulationsMissed: 0, offsides: 0, offsidesCorrect: 0, offsidesMissed: 0, advantageOk: 0, advantageFailed: 0, whistles: 0,
};
const result = (nota, over = {}) => ({
  nota,
  label: nota >= 7.5 ? 'Muito bom' : nota >= 5 ? 'Regular' : 'Precisa melhorar',
  categories: [{ label: 'Posicionamento', points: 4, max: 10, ratio: 0.4 }, { label: 'Cartões', points: 14, max: 15, ratio: 0.93 }, { label: 'Decisões corretas', points: 27, max: 30, ratio: 0.9 }],
  mistakes: [],
  hits: [{ clock: '12:00', label: 'Falta leve', text: 'Falta leve marcada corretamente' }],
  counts: { unnecessaryWhistles: 0 },
  score: { home: 2, away: 1 },
  extras: { ...BASE_FACTS },
  ...over,
});
function play(career, res, offerIndex = 0, id = `m${career.totalMatches}-${career.season.number}`) {
  const offers = getOffers(career).filter((o) => o.status === 'offered');
  const f = offers[Math.min(offerIndex, offers.length - 1)].fixture;
  return applyMatch(career, { competitionId: f.competitionId, homeId: f.home, awayId: f.away, importance: f.importance, fixtureId: f.id, matchId: id, duration: 'quick' }, res);
}
const allText = (c) => JSON.stringify([c.news, c.inbox, c.social]).toLowerCase();

test('nova carreira tem e-mail de boas-vindas e a escala da primeira rodada', () => {
  const c = createCareer('Ana', 3);
  assert.equal(c.version, CAREER_VERSION);
  const subjects = c.inbox.map((m) => m.subject);
  assert.ok(subjects.includes('Bem-vindo, Ana'));
  assert.ok(subjects.includes('Escala da rodada 1'));
  assert.equal(unreadCount(c), 2);
  assert.deepEqual([c.news.length, c.social.length], [0, 0]);
});

test('escala da semana: um e-mail por rodada, atualizado no lugar (nunca duplicado)', () => {
  const c = createCareer('Ana', 3);
  const before = c.inbox.length;
  syncWeekEmail(c);
  syncWeekEmail(c);
  assert.equal(c.inbox.length, before);
  const mail = c.inbox.find((m) => m.key === 'week:1:1');
  assert.ok(mail.offers.length >= 2 && mail.offers.every((o) => o.home && o.away && o.competition && o.stadium));
  play(c, result(7));
  assert.ok(c.inbox.some((m) => m.key === 'week:1:2'), 'a rodada seguinte ganha a sua escala');
  assert.equal(c.inbox.filter((m) => m.key === 'week:1:1').length, 1);
});

test('uma partida gera notícias, e-mails e publicações ligados a ela', () => {
  const c = createCareer('Ana', 4);
  const s = play(c, result(8.2), 0, 'jogo-1');
  assert.ok(s.comms.news >= 2 && s.comms.emails >= 1 && s.comms.posts >= 5);
  for (const n of c.news.filter((x) => x.matchId)) {
    assert.equal(n.matchId, 'jogo-1');
    assert.ok(n.headline && n.summary && n.category && n.source && n.date && n.competitionId);
    assert.ok(['positive', 'neutral', 'negative'].includes(n.tone));
  }
  const report = c.inbox.find((m) => m.key === 'jogo-1:mail:report');
  assert.ok(report.lines.some((l) => l.includes('Nota final: 8,2')) && report.lines.some((l) => l.includes('9 de 10')));
  assert.ok(c.social.every((p) => p.matchId === 'jogo-1' && p.author.name && p.tag));
  assert.ok(c.social.some((p) => p.author.kind === 'oficial') && c.social.some((p) => p.author.kind === 'torcedor'));
});

test('as notícias só falam do que realmente aconteceu', () => {
  const clean = createCareer('Ana', 5);
  play(clean, result(8));
  const text = allText(clean);
  for (const word of ['pênalti', 'vermelho', 'impedimento', 'simulação', 'expuls']) assert.ok(!text.includes(word), `"${word}" não aconteceu e não pode aparecer`);

  const busy = createCareer('Ana', 5);
  play(busy, result(5.5, { extras: { ...BASE_FACTS, penalties: 1, penaltiesCorrect: 0, penaltiesMissed: 1, missedFouls: 1, red: 1, redWrong: 1, wrongCalls: 1, offsidesMissed: 1 } }));
  const lance = busy.news.filter((n) => n.category === 'lance').map((n) => n.headline.toLowerCase()).join(' | ');
  assert.ok(lance.length > 0 && busy.news.filter((n) => n.category === 'lance').length <= 2, 'no máximo 2 notícias de lance');
  assert.ok(/expuls|pênalti não marcado|falta marcada sem infração|impedimento/.test(lance));
});

test('tom: positivo, neutro ou negativo conforme a nota e os erros graves', () => {
  assert.equal(toneOf(8, 0), 'positive');
  assert.equal(toneOf(8, 1), 'neutral');
  assert.equal(toneOf(6, 0), 'neutral');
  assert.equal(toneOf(4.5, 0), 'negative');
  assert.equal(toneOf(7, 2), 'negative');
  const c = createCareer('Ana', 6);
  play(c, result(8.5));
  play(c, result(3.8, { mistakes: [{ severity: 3, clock: '10:00', label: 'Pênalti', errors: ['falta não marcada'], expected: 'pênalti' }] }));
  const tones = c.news.filter((n) => n.category === 'arbitragem').map((n) => n.tone);
  assert.deepEqual(tones.sort(), ['negative', 'positive']);
});

test('sem manchetes repetidas em sequência', () => {
  const c = createCareer('Ana', 7);
  for (let i = 0; i < 12; i++) play(c, result(8 + (i % 2) * 0.3));
  const perf = c.news.filter((n) => n.category === 'arbitragem');
  assert.equal(perf.length, 12);
  for (let i = 0; i < perf.length - 1; i++) {
    assert.notEqual(perf[i].variant, perf[i + 1].variant, 'mesma variante em sequência');
    assert.notEqual(perf[i].headline, perf[i + 1].headline, 'mesma manchete em sequência');
  }
  assert.ok(new Set(perf.map((n) => n.variant)).size >= 3, 'os textos variam');
});

test('rede social: opinião é marcada como opinião e a avaliação técnica só aparece em dado ou análise', () => {
  const c = createCareer('Ana', 8);
  play(c, result(8.4));
  for (const p of c.social) {
    if (p.author.kind === 'torcedor' || p.author.kind === 'comentarista') {
      assert.equal(p.tag, 'opinião');
      assert.equal(p.technical, false);
      assert.ok(!/nota \d/.test(p.text.toLowerCase()), 'opinião não cita a nota como se fosse dado');
    }
    if (p.technical) assert.equal(p.tag, 'análise');
  }
  const analysis = c.social.find((p) => p.tag === 'análise');
  assert.ok(analysis.text.includes('8,4') && analysis.text.includes('9 de 10'));
});

test('a repercussão pública não altera nota, reputação nem experiência', () => {
  const a = createCareer('Ana', 9);
  const b = createCareer('Ana', 9);
  play(a, result(7.2));
  b.news = []; // mesmo jogo, mas cada um com um histórico de notícias diferente
  b.social = [];
  play(b, result(7.2));
  assert.equal(a.rep, b.rep);
  assert.equal(a.xp, b.xp);
  assert.equal(a.history[0].nota, b.history[0].nota);
});

test('processar o mesmo jogo duas vezes não duplica nada', () => {
  const c = createCareer('Ana', 10);
  const f = getOffers(c)[0].fixture;
  const fixture = { competitionId: f.competitionId, homeId: f.home, awayId: f.away, importance: f.importance, fixtureId: f.id, matchId: 'unico' };
  assert.ok(applyMatch(c, fixture, result(8)));
  const snap = JSON.stringify([c.news, c.inbox, c.social, c.comms]);
  assert.equal(applyMatch(c, fixture, result(8)), null);
  assert.equal(JSON.stringify([c.news, c.inbox, c.social, c.comms]), snap);
  const pub = publish(c, { news: c.news.map((n) => ({ ...n })), emails: [], posts: [] });
  assert.equal(pub.news, 0, 'chaves iguais nunca entram duas vezes');
});

test('mesma semente e mesmo jogo geram os mesmos textos', () => {
  const run = () => {
    const c = createCareer('Ana', 11);
    play(c, result(7.8), 0, 'igual');
    return JSON.stringify([c.news.map((n) => n.headline), c.social.map((p) => p.text)]);
  };
  assert.equal(run(), run());
});

test('e-mails: ler, marcar como lida e marcar todas', () => {
  const c = createCareer('Ana', 12);
  play(c, result(9.2));
  const total = unreadCount(c);
  assert.ok(total >= 3);
  const first = c.inbox[0];
  assert.ok(setRead(c, first.id, true));
  assert.equal(setRead(c, first.id, true), false, 'já estava lida');
  assert.equal(unreadCount(c), total - 1);
  assert.ok(setRead(c, first.id, false));
  assert.ok(markAllRead(c) >= 1);
  assert.equal(unreadCount(c), 0);
  assert.ok(c.inbox.some((m) => m.category === 'reconhecimento'), 'nota 9 ou mais gera reconhecimento');
  assert.ok(c.inbox.some((m) => m.category === 'objetivo'), 'objetivo concluído gera aviso');
});

test('recusar a convocação pelo e-mail ou pela aba usa a mesma regra e não custa nada', () => {
  const c = createCareer('Ana', 13);
  const [a] = getOffers(c);
  const before = { rep: c.rep, xp: c.xp };
  assert.ok(declineOffer(c, a.fixture.id));
  assert.equal(declineOffer(c, a.fixture.id), false, 'não processa duas vezes');
  assert.deepEqual({ rep: c.rep, xp: c.xp }, before);
  const mail = c.inbox.find((m) => m.key === 'week:1:1');
  assert.ok(mail.offers.some((o) => o.fixtureId === a.fixture.id), 'o e-mail guarda o jogo');
});

test('suspensão gera e-mail disciplinar com o motivo e atualiza a escala', () => {
  const c = createCareer('Ana', 14);
  const s = play(c, result(5, { mistakes: Array.from({ length: 4 }, () => ({ severity: 3 })) }));
  assert.ok(s.suspension);
  const mail = c.inbox.find((m) => m.category === 'disciplinar');
  assert.ok(mail && mail.lines[0].includes(s.suspension));
  const week = c.inbox.find((m) => m.key === `week:${c.world.season}:${c.world.week}`);
  assert.ok(week.lines.some((l) => l.includes('oportunidades limitadas')));
});

test('fim de temporada: decisão do comitê por e-mail, campeões nas notícias e nos posts', () => {
  const c = createCareer('Ana', 15);
  for (let i = 0; i < SEASON_ROUNDS; i++) play(c, result(8.3));
  const decision = c.inbox.find((m) => m.key === 'season:1:mail:decision');
  assert.ok(decision && decision.criteria.length === 5 && decision.lines.length >= 4);
  assert.ok(decision.category === 'promoção' || decision.category === 'comunicado' || decision.category === 'disciplinar');
  assert.ok(c.news.some((n) => n.key.startsWith('season:1:news:champ')));
  assert.ok(c.news.some((n) => n.key === 'season:1:news:decision'));
  assert.ok(c.social.some((p) => p.key.startsWith('season:1:post:champ')));
  const champsInNews = c.news.filter((n) => n.key.startsWith('season:1:news:champ')).length;
  assert.ok(champsInNews >= 1 && champsInNews <= 3);
});

test('passar a rodada não gera notícias nem publicações de partida', () => {
  const c = createCareer('Ana', 16);
  skipWeek(c);
  assert.equal(c.news.length, 0);
  assert.equal(c.social.length, 0);
  assert.ok(c.inbox.some((m) => m.key === 'week:1:2'));
});

test('imagem pública vem do tom das últimas notícias e é só narrativa', () => {
  const c = createCareer('Ana', 17);
  assert.equal(publicImage(c), null);
  for (let i = 0; i < 4; i++) play(c, result(8.4));
  assert.equal(publicImage(c).label, 'Positiva');
  for (let i = 0; i < 5; i++) play(c, result(3.5, { mistakes: [{ severity: 3 }, { severity: 3 }] }));
  assert.equal(publicImage(c).label, 'Crítica');
});

test('o histórico de comunicação tem limite e persiste no salvamento', () => {
  const c = createCareer('Ana', 18);
  for (let i = 0; i < 40; i++) play(c, result(7 + (i % 3) * 0.4));
  assert.ok(c.news.length <= COMMS_LIMITS.news && c.inbox.length <= COMMS_LIMITS.inbox && c.social.length <= COMMS_LIMITS.social);
  const ids = c.inbox.map((m) => m.seq);
  assert.equal(new Set(ids).size, ids.length, 'ids únicos');
  assert.ok(ids.every((v, i) => i === 0 || ids[i - 1] > v), 'mais recente primeiro');
  const reloaded = JSON.parse(JSON.stringify(c));
  assert.deepEqual(reloaded.news, c.news);
  assert.deepEqual(reloaded.social, c.social);
  assert.deepEqual(reloaded.inbox, c.inbox);
  const again = migrateCareer(reloaded);
  assert.equal(again.migrated, false, 'recarregar não migra nem duplica nada');
  assert.equal(again.career.inbox.length, c.inbox.length);
});

test('migração v4 -> v5 ativa a central sem inventar partidas passadas', () => {
  const v5 = createCareer('Antigo', 19);
  play(v5, result(8));
  const v4 = JSON.parse(JSON.stringify(v5));
  for (const k of ['inbox', 'news', 'social', 'comms']) delete v4[k];
  v4.version = 4;
  const r = migrateCareer(v4);
  assert.ok(r.migrated);
  assert.equal(r.career.version, CAREER_VERSION);
  assert.equal(r.career.news.length, 0);
  assert.equal(r.career.social.length, 0);
  assert.ok(r.career.inbox.some((m) => m.subject === 'Central de mensagens ativada'));
  assert.ok(r.career.inbox.some((m) => m.key === `week:${r.career.world.season}:${r.career.world.week}`));
});

test('com partidas reais: fatos vêm do registro de decisões e as mensagens batem com eles', () => {
  const r = runMatch({ mode: 'perfect', seed: 21 });
  const facts = matchFacts(r.dec.log);
  assert.equal(facts.decisions, r.dec.log.length);
  assert.equal(facts.correct, r.dec.log.filter((e) => e.correct).length);
  const grade = gradeMatch(r.dec.log);
  const c = createCareer('Ana', 20);
  const f = getOffers(c)[0].fixture;
  applyMatch(c, { competitionId: f.competitionId, homeId: f.home, awayId: f.away, importance: f.importance, fixtureId: f.id, matchId: 'real' }, {
    nota: grade.nota, label: grade.label, categories: grade.categories, mistakes: grade.mistakes, hits: grade.hits, counts: grade.counts, score: r.sim.score, extras: facts,
  });
  const report = c.inbox.find((m) => m.key === 'real:mail:report');
  assert.ok(report.lines[0].includes(String(grade.nota).replace('.', ',')));
  assert.ok(report.lines.some((l) => l.includes(`${facts.correct} de ${facts.decisions}`)));
  const text = allText(c);
  if (facts.penalties === 0 && facts.penaltiesMissed === 0) assert.ok(!text.includes('pênalti'));
  if (facts.red === 0) assert.ok(!text.includes('expuls') && !text.includes('vermelho'));
});
