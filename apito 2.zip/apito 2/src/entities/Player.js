import Character from './Character.js';

const ROLE_SPEED = { GK: 62, DEF: 66, MID: 70, FWD: 72 };

export default class Player extends Character {
  // cfg: { team, role, attackDir, nx, ny, number, texture }
  constructor(scene, x, y, cfg) {
    super(scene, x, y, cfg.texture);
    this.team = cfg.team;
    this.role = cfg.role;
    this.attackDir = cfg.attackDir;
    this.nx = cfg.nx;
    this.ny = cfg.ny;
    this.number = cfg.number;
    this.moveSpeed = ROLE_SPEED[cfg.role];

    this.touchCooldown = 0; // segundos até poder tocar na bola de novo
    this.holdTimer = 0; // ms com a posse da bola
  }

  // Deitado no chão (após falta ou simulação).
  setFallen(on) {
    this.setAngle(on ? (this.flipX ? -90 : 90) : 0);
  }

  // Expulso: sai de cena apagando aos poucos. O sprite só é escondido (não destruído) para o VAR poder
  // desfazer um cartão vermelho e trazer o jogador de volta.
  fadeOutSentOff() {
    if (this.body) this.body.enable = false;
    this.scene.tweens.add({
      targets: [this, this.shadow],
      alpha: 0,
      duration: 900,
      onComplete: () => {
        this.setVisible(false);
        this.shadow.setVisible(false);
      },
    });
  }

  // Volta ao jogo depois de uma expulsão desfeita pelo VAR.
  revive() {
    if (this.scene && this.scene.tweens) this.scene.tweens.killTweensOf([this, this.shadow]);
    if (this.body) this.body.enable = true;
    this.setAlpha(1).setVisible(true);
    this.shadow.setAlpha(1).setVisible(true);
  }
}
