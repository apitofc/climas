import Character from './Character.js';

export default class Referee extends Character {
  constructor(scene, x, y) {
    super(scene, x, y, 'referee');
    this.moveSpeed = 80; // um pouco mais rápido que os jogadores
  }
}
