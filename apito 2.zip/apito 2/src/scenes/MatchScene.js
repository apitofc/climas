import Phaser from 'phaser';
import { FIELD, FIELD_RECT, TEAMS, WORLD_WIDTH, WORLD_HEIGHT, COLORS, matchDurationMs, CUSTOM_EVENTS, applyClubs } from '../config.js';
import { QUICK_MATCH } from '../data/competitions.js';
import { makeRoster } from '../data/names.js';
import { createTeamTextures, createRefereeTexture } from '../utils/pixelTextures.js';
import { getLook } from '../data/referees.js';
import { loadCareer, loadSettings } from '../utils/storage.js';
import { toggleMuted, startCrowd, stopCrowd, playBlip } from '../utils/audio.js';
import { makeRng, hashString } from '../utils/rng.js';
import { FORMATION_442 } from '../data/formations.js';
import Referee from '../entities/Referee.js';
import Player from '../entities/Player.js';
import Ball from '../entities/Ball.js';
import Controls from '../systems/Controls.js';
import MatchSimulation from '../systems/MatchSimulation.js';
import RefereeDecisionSystem from '../systems/RefereeDecisionSystem.js';
import HUD from '../ui/HUD.js';
import Effects from '../ui/Effects.js';
import DecisionPanel from '../ui/DecisionPanel.js';
import VarSystem from '../systems/VarSystem.js';
import { conditionsFor, conditionsSummary, returnFouls, withWeather } from '../systems/MatchConditions.js';
import WeatherFx from '../ui/WeatherFx.js';
import { trainingEffects } from '../systems/TrainingSystem.js';
import { ensureCrew, generateCrew } from '../systems/CrewSystem.js';
import CrewSprites from '../ui/CrewSprites.js';
import DissentPanel from '../ui/DissentPanel.js';
import { HighlightPlanner, finalizeShots, findFeud, isControversial } from '../systems/Highlights.js';
import VarReplay from '../ui/VarReplay.js';
import VarPanel from '../ui/VarPanel.js';

export default class MatchScene extends Phaser.Scene {
  constructor() {
    super('MatchScene');
  }

  init(data) {
    this.mode = data && data.mode ? data.mode : 'quick';
    this.fixture = (data && data.fixture) || {
      competitionId: null,
      home: QUICK_MATCH.home,
      away: QUICK_MATCH.away,
      importance: QUICK_MATCH.importance,
      seed: `quick-${Date.now()}`,
    };
    // A duração é escolhida antes da partida e não muda durante ela.
    this.durationId = (data && data.duration) || loadSettings().duration;
    this.matchId = `${this.fixture.seed}:${Date.now()}`;
  }

  create() {
    applyClubs(this.fixture.home, this.fixture.away);
    createTeamTextures(this, this.fixture.home, this.fixture.away);
    // Aparência do árbitro: a escolhida na carreira (ou a padrão na partida rápida).
    const career = loadCareer();
    createRefereeTexture(this, getLook(career && career.profile ? career.profile.look : 0));
    this.rosters = { home: makeRoster(this.fixture.home.id), away: makeRoster(this.fixture.away.id) };

    this.drawField();
    this.drawStands();

    this.physics.world.setBounds(0, 0, WORLD_WIDTH, WORLD_HEIGHT);

    this.controls = new Controls(this);
    this.ball = new Ball(this, FIELD_RECT.cx, FIELD_RECT.cy);
    this.players = this.createTeams();
    this.referee = new Referee(this, FIELD_RECT.cx + 12, FIELD_RECT.cy + 22);

    const rng = new Phaser.Math.RandomDataGenerator(['ref-whistle', String(this.fixture.seed)]);
    const DIFFICULTY = {
      1: { tackleGap: 8, aggressionBonus: 0, diveChance: 0.25 },
      2: { tackleGap: 7, aggressionBonus: 0.05, diveChance: 0.3 },
      3: { tackleGap: 6, aggressionBonus: 0.1, diveChance: 0.4 },
    };
    this.sim = new MatchSimulation(this.events, {
      ball: this.ball,
      players: this.players,
      referee: this.referee,
      rng,
      matchDurationMs: matchDurationMs(this.durationId),
      difficulty: DIFFICULTY[this.fixture.importance] || DIFFICULTY[2],
    });

    const cam = this.cameras.main;
    cam.setBounds(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
    cam.centerOn(this.referee.x, this.referee.y);
    cam.startFollow(this.referee, true, 0.1, 0.1);
    cam.setDeadzone(24, 14);

    this.decisions = new RefereeDecisionSystem(this.events, this.sim);
    // Tensão inicial do jogo: importância da partida e rivalidade entre os clubes (só contexto, não é punição).
    // Condições do jogo (tempo, gramado, clássico, final, disputa de título, retorno de lesão): mesma partida, mesmas condições.
    this.conditions = conditionsFor(career, { ...this.fixture, homeId: this.fixture.home.id, awayId: this.fixture.away.id });
    const forced = typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('weather') : null; // só para testes
    if (forced) this.conditions = withWeather(this.conditions, forced);
    this.sim.setConditions(this.conditions);
    this.decisions.mood.setBase(((this.fixture.importance || 1) - 1) * 6 + this.conditions.baseTension, this.conditions.crowdFactor);
    this.varSys = new VarSystem(this.events, this.sim, this.decisions);
    this.setupHighlights();
    // Treino: velocidade do árbitro, tempo para apitar, clima da partida e dicas do painel (só nas partidas da carreira).
    this.training = trainingEffects(this.mode === 'career' ? career : null);
    this.referee.moveSpeed *= this.training.positionSpeedMul;
    this.decisions.setTraining(this.training);
    // Equipe de arbitragem: a da carreira (com a experiência e o entrosamento dela) ou uma equipe padrão na partida rápida.
    this.decisions.setCrew(this.mode === 'career' && career ? ensureCrew(career) : generateCrew('rapida', 3), this.fixture.seed || 'rapida');
    this.hud = new HUD(this);
    this.hud.setConditions(this.conditions);
    this.weatherFx = new WeatherFx(this, this.conditions);
    this.crewSprites = new CrewSprites(this, this.sim);
    this.effects = new Effects(this, this.referee);
    this.varReplay = new VarReplay(this, this.varSys);
    this.varPanel = new VarPanel(this, this.varSys, (r) => this.closeVar(r));
    this.panel = new DecisionPanel(this, (choice) => this.decisions.resolveDecision(choice));
    this.dissentPanel = new DissentPanel(this, (choice) => this.decisions.resolveDissent(choice));
    this.panel.hints = { varTag: this.training.varTag, ruleHint: this.training.ruleHint, agravantes: this.training.agravantes };
    this.paused = false;
    this.finishing = false;

    this.events.on('halftime', () => this.decisions.closeAll());
    this.events.on('fulltime', () => {
      this.decisions.closeAll();
      this.time.delayedCall(2500, () => this.finishMatch());
    });
    this.events.once('shutdown', () => {
      if (this.varSys.active) this.varSys.close();
      if (this.varReplay.running) this.varReplay.stop();
    });

    // Torcida de fundo e tremor de câmera no gol.
    startCrowd();
    this.events.on('goal', () => this.cameras.main.shake(180, 0.006));

    this.events.once('shutdown', () => {
      stopCrowd();
      for (const name of CUSTOM_EVENTS) this.events.removeAllListeners(name);
    });

    this.sim.startSetPiece('kickoff', 'home');

    this.debugOn = false;
    this.debugG = this.add.graphics().setDepth(9999);
    this.input.keyboard.on('keydown-F2', () => {
      this.debugOn = !this.debugOn;
      this.debugG.clear();
    });
  }

  // Abre a revisão do VAR: a partida fica pausada e a imagem passa a vir da gravação.
  requestVar() {
    if (this.paused || this.finishing || this.varSys.active) return;
    // Chamado de dentro do painel de decisão: o VAR abre já no lance que está sendo decidido.
    const deciding = this.panel.isOpen && this.decisions.isDeciding();
    const r = this.varSys.open({ incident: deciding ? this.decisions.stoppage.incident : null });
    if (!r.ok) {
      if (r.reason) this.events.emit('feedback', { kind: 'info', text: r.reason });
      return;
    }
    if (deciding) this.panel.suspend();
    this.physics.world.pause();
    this.varReplay.start();
    this.varPanel.open();
    this.hud.setReviewMode(true);
    playBlip();
  }

  // Encerra a revisão e devolve a partida (com a decisão alterada, se foi o caso).
  closeVar() {
    if (!this.varSys.active) return;
    this.varSys.close();
    this.varPanel.close();
    this.varReplay.stop();
    this.panel.resume();
    this.hud.setReviewMode(false);
    this.physics.world.resume();
    playBlip();
  }

  // Prints reais para as redes sociais: captura a tela do jogo em momentos marcantes (gol, vermelho, gol anulado, VAR,
  // pênalti e lance polêmico). A decisão de quais valem print fica em Highlights.js; aqui só se tira a foto.
  setupHighlights() {
    this.highlights = new HighlightPlanner();
    const ev = this.events;
    const clock = () => ({ clock: this.sim.getClock().text, period: this.sim.period, score: { ...this.sim.score } });
    ev.on('goal', (g) => this.captureShot({ kind: 'goal', team: g.team, scorer: g.scorer ? `${g.scorer.name} (#${g.scorer.number})` : null, ...clock() }));
    ev.on('card', (c) => c.effective === 'red' && this.captureShot({ kind: 'red', team: c.player.team, player: `${c.player.name} (#${c.player.number})`, ...clock() }));
    ev.on('goal-disallowed', () => this.captureShot({ kind: 'disallowed', ...clock() }));
    ev.on('var-decision', (d) => this.captureShot({ kind: 'var', incidentId: d.incidentId, ...clock() }));
    ev.on('decision-result', (e) => {
      if (e.type === 'penalty') this.captureShot({ kind: 'penalty', incidentId: e.incidentId, ...clock() });
      else if (isControversial(e)) this.captureShot({ kind: 'controversy', incidentId: e.incidentId, ...clock() });
    });
  }

  captureShot(meta) {
    if (!this.highlights || this.mode !== 'career') return; // prints só nas partidas da carreira
    const shot = this.highlights.reserve(meta, this.sim.time);
    if (!shot) return;
    try {
      this.game.renderer.snapshot((img) => {
        try {
          const c = document.createElement('canvas');
          c.width = 320;
          c.height = 180;
          c.getContext('2d').drawImage(img, 0, 0, 320, 180);
          shot.image = c.toDataURL('image/jpeg', 0.6);
        } catch (e) {
          shot.image = null;
        }
      });
    } catch (e) {
      shot.image = null;
    }
  }

  finishMatch() {
    if (this.finishing) return;
    this.finishing = true;
    if (this.varSys.active) this.closeVar();
    const f = this.fixture;
    // Histórico auditável do VAR, com o desfecho real de cada decisão revista (certa ou errada segundo a nota).
    const varReviews = this.varSys.audit.map((a) => {
      const entry = [...this.decisions.log].reverse().find((e) => e.incidentId === a.incidentId);
      return { ...a, finalCorrect: entry ? !!entry.correct : null };
    });
    this.scene.start('ResultScene', {
      mode: this.mode,
      fixture: {
        competitionId: f.competitionId,
        homeId: f.home.id,
        awayId: f.away.id,
        importance: f.importance,
        duration: this.durationId,
        matchId: this.matchId,
        fixtureId: f.fixtureId || null,
      },
      score: { ...this.sim.score },
      stats: JSON.parse(JSON.stringify(this.sim.stats)),
      cards: JSON.parse(JSON.stringify(this.decisions.cards)),
      log: this.decisions.log,
      mood: this.decisions.mood.summary(),
      crew: this.decisions.crewSummary(),
      conditions: conditionsSummary(this.conditions, { returnFouled: returnFouls(this.conditions, this.decisions.log), late: this.decisions.mood.lateSeen }),
      refStats: { travel: Math.round(this.refTravel || 0), fieldWidth: FIELD.width },
      varStats: { ...this.varSys.stats },
      // Histórico auditável do VAR, com o desfecho real de cada decisão revista (certa ou errada segundo a nota).
      varReviews,
      shots: finalizeShots(this.highlights ? this.highlights.shots : [], this.decisions.log, this.sim.score, varReviews),
      feud: findFeud(this.decisions.log),
    });
  }

  // Arquibancadas e placas de publicidade em volta do campo (desenhadas uma vez, em textura).
  drawStands() {
    if (this.textures.exists('stands')) this.textures.remove('stands');
    const W = WORLD_WIDTH;
    const H = WORLD_HEIGHT;
    const g = this.make.graphics({ x: 0, y: 0, add: false });
    const rng = makeRng(hashString(`stands:${this.fixture.home.id}:${this.fixture.away.id}`));
    const colors = [this.fixture.home.shirt, this.fixture.away.shirt, '#d9d9d9', '#3a3f4a', '#8a8f9a', '#2a2d36'];
    const hex = (h) => parseInt(h.slice(1), 16);

    const band = (x, y, w, h) => {
      g.fillStyle(0x1b1e26, 1);
      g.fillRect(x, y, w, h);
      for (let cy = y; cy < y + h - 2; cy += 3) {
        for (let cx = x; cx < x + w - 2; cx += 3) {
          if (rng.frac() < 0.72) {
            g.fillStyle(hex(colors[Math.floor(rng.frac() * colors.length)]), 1);
            g.fillRect(cx, cy, 2, 2);
          }
        }
      }
    };
    band(0, 0, W, 12);
    band(0, H - 12, W, 12);
    band(0, 12, 10, H - 24);
    band(W - 10, 12, 10, H - 24);

    const ads = ['#c8422e', '#2f6fd6', '#e8c24a', '#2f8f4e', '#9b3fd0', '#f2f2f2'];
    for (let x = 10, i = 0; x < W - 10; x += 24, i++) {
      g.fillStyle(hex(ads[i % ads.length]), 1);
      g.fillRect(x, 12, 22, 4);
      g.fillRect(x, H - 16, 22, 4);
    }
    g.generateTexture('stands', W, H);
    g.destroy();
    this.add.image(0, 0, 'stands').setOrigin(0, 0).setDepth(0.5);
  }

  setPaused(paused) {
    this.paused = paused;
    if (paused) this.physics.world.pause();
    else this.physics.world.resume();
    this.hud.setPaused(paused);
  }

  createTeams() {
    const players = [];
    for (const team of Object.values(TEAMS)) {
      const d = team.attackDir;
      const ownX = d > 0 ? FIELD_RECT.left : FIELD_RECT.right;
      FORMATION_442.forEach((slot, i) => {
        const spawnNx = slot.role === 'GK' ? slot.nx : Math.min(slot.nx, 0.46);
        const x = ownX + d * spawnNx * FIELD.width;
        const y = FIELD_RECT.top + slot.ny * FIELD.height;
        const player = new Player(this, x, y, {
          team: team.id,
          role: slot.role,
          attackDir: d,
          nx: slot.nx,
          ny: slot.ny,
          number: i + 1,
          texture: slot.role === 'GK' ? team.gkTexture : team.texture,
        });
        player.name = this.rosters[team.id][i].last;
        players.push(player);
      });
    }
    return players;
  }

  update(_time, delta) {
    const actions = this.controls.getActions();
    if (actions.mute) {
      const muted = toggleMuted();
      this.events.emit('feedback', { kind: 'info', text: muted ? 'Som desligado' : 'Som ligado' });
    }
    const deciding = this.decisions.isDeciding();

    // Revisão do VAR em andamento: a partida está congelada; só a reprodução da gravação anda.
    if (this.varSys.active) {
      this.varSys.update(delta);
      this.varReplay.render();
      this.varPanel.update();
      return;
    }

    if (actions.pause && !deciding) this.setPaused(!this.paused);
    if (this.paused) {
      if (actions.menu) this.scene.start('MenuScene');
      return;
    }

    if (actions.var) {
      this.requestVar();
      if (this.varSys.active) return;
    }

    this.varSys.beforeStep(delta);
    const rx = this.referee.x;
    const ry = this.referee.y;
    this.referee.update(delta, deciding ? { x: 0, y: 0 } : this.controls.getMove());
    const step = Math.hypot(this.referee.x - rx, this.referee.y - ry);
    if (step < 12) this.refTravel = (this.refTravel || 0) + step; // ignora saltos (reposicionamentos)
    this.sim.update(delta);

    const atHalftime = this.sim.state === 'stopped' && this.sim.stopReason === 'halftime';
    if (atHalftime) {
      if (actions.whistle) this.sim.startSecondHalf();
    } else if (!deciding) {
      // Na pausa depois do gol, apitar (Espaço) ou marcar falta (F) anula o gol, como o G. Fora dela, é o apito de sempre.
      if (this.decisions.isGoalCheckOpen()) {
        if (actions.annulGoal || actions.whistle || actions.foul) this.decisions.annulGoal();
      } else {
        if (actions.whistle || actions.foul || actions.yellow || actions.red) this.decisions.whistle();
        if (actions.advantage) this.decisions.signalAdvantage();
        if (actions.fourth) this.decisions.callFourth();
      }
    }
    this.decisions.update(delta);
    this.varSys.afterStep();

    this.hud.setVarAvailable(this.varSys.canOpen().ok);
    this.hud.update(delta, this.decisions.getPrompt(), this.sim, this.decisions.mood);
    this.effects.update();
    if (this.weatherFx && !this.paused) this.weatherFx.update(delta);
    if (this.crewSprites && !this.paused) this.crewSprites.update(delta);
    // Painel de reclamação: abre quando a súmula pede e fecha se a reclamação deixou de valer (fim de jogo, VAR).
    if (this.decisions.dissent && !this.dissentPanel.isOpen) this.dissentPanel.open(this.decisions.dissent);
    else if (!this.decisions.dissent && this.dissentPanel.isOpen) this.dissentPanel.close();

    if (this.debugOn) {
      const g = this.debugG;
      g.clear();
      g.lineStyle(1, 0xffff00, 1);
      for (const id of ['home', 'away']) {
        const c = this.sim.chaser[id];
        if (c) g.strokeCircle(c.x, c.y - 2, 7);
      }
      const h = this.ball.holder;
      if (h) {
        g.lineStyle(1, 0xffffff, 1);
        g.strokeCircle(h.x, h.y - 2, 10);
      }
    }
  }

  drawField() {
    const g = this.add.graphics();
    const m = FIELD.margin;
    const L = FIELD.line;
    const fx = m;
    const fy = m;
    const fw = FIELD.width;
    const fh = FIELD.height;
    const cx = fx + fw / 2;
    const cy = fy + fh / 2;

    const stripes = 14;
    const stripeW = WORLD_WIDTH / stripes;
    for (let i = 0; i < stripes; i++) {
      g.fillStyle(i % 2 === 0 ? COLORS.grassA : COLORS.grassB, 1);
      g.fillRect(Math.floor(i * stripeW), 0, Math.ceil(stripeW), WORLD_HEIGHT);
    }

    g.fillStyle(COLORS.line, 1);
    g.fillRect(fx, fy, fw, L);
    g.fillRect(fx, fy + fh - L, fw, L);
    g.fillRect(fx, fy, L, fh);
    g.fillRect(fx + fw - L, fy, L, fh);
    g.fillRect(cx - L / 2, fy, L, fh);
    this.pixelCircle(g, cx, cy, FIELD.centerRadius, L);
    g.fillRect(cx - 2, cy - 2, 4, 4);

    for (const side of [-1, 1]) {
      const edgeX = side === -1 ? fx : fx + fw;
      const dir = -side;

      this.box(g, edgeX, cy, FIELD.penaltyDepth, FIELD.penaltyWidth, dir, L);
      this.box(g, edgeX, cy, FIELD.boxDepth, FIELD.boxWidth, dir, L);

      const px = edgeX + dir * FIELD.penaltySpot;
      g.fillRect(px - 1, cy - 1, 3, 3);

      const gx = side === -1 ? edgeX - FIELD.goalDepth : edgeX;
      g.fillStyle(COLORS.net, 0.6);
      g.fillRect(gx, cy - FIELD.goalWidth / 2, FIELD.goalDepth, FIELD.goalWidth);
      g.fillStyle(COLORS.goal, 1);
      g.fillRect(gx, cy - FIELD.goalWidth / 2 - 1, FIELD.goalDepth, 2);
      g.fillRect(gx, cy + FIELD.goalWidth / 2 - 1, FIELD.goalDepth, 2);
      const backX = side === -1 ? gx : gx + FIELD.goalDepth - 2;
      g.fillRect(backX, cy - FIELD.goalWidth / 2, 2, FIELD.goalWidth);
      g.fillStyle(COLORS.line, 1);
    }

    const corners = [
      [fx, fy],
      [fx + fw, fy],
      [fx, fy + fh],
      [fx + fw, fy + fh],
    ];
    for (const [x, y] of corners) g.fillRect(x - 1, y - 1, 3, 3);

    g.setDepth(0);
  }

  box(g, edgeX, cy, depth, width, dir, L) {
    const top = cy - width / 2;
    const innerX = edgeX + dir * depth;
    const x1 = Math.min(edgeX, innerX);
    const w = Math.abs(innerX - edgeX);
    g.fillRect(x1, top, w, L); // topo
    g.fillRect(x1, top + width - L, w, L);
    g.fillRect(dir === 1 ? innerX - L : innerX, top, L, width);
  }

  pixelCircle(g, cx, cy, r, thickness) {
    const steps = Math.ceil(2 * Math.PI * r);
    for (let i = 0; i < steps; i++) {
      const a = (i / steps) * Math.PI * 2;
      const x = Math.round(cx + Math.cos(a) * r);
      const y = Math.round(cy + Math.sin(a) * r);
      g.fillRect(x, y, thickness, thickness);
    }
  }
}
