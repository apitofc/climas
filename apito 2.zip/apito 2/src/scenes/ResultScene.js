import Phaser from 'phaser';
import { TEAMS, getDuration } from '../config.js';
import { gradeMatch, describeEntry, matchFacts, varFacts } from '../systems/RefereeGrading.js';
import { crowdLabel } from '../systems/MatchMood.js';
import { buildReport } from '../systems/TechnicalReport.js';
import { sideImpact } from '../systems/MemorySystem.js';
import { reportToHtml } from '../ui/reportHtml.js';
import { applyMatch, comma, SEASON_ROUNDS } from '../systems/CareerSystem.js';
import { getCompetition, getClub } from '../data/competitions.js';
import { loadCareer, saveCareer } from '../utils/storage.js';

const stars = (n) => '★'.repeat(n) + '☆'.repeat(3 - n);

const pct = (r) => (r >= 0.8 ? 'good' : r >= 0.5 ? 'mid' : 'bad');

export default class ResultScene extends Phaser.Scene {
  constructor() {
    super('ResultScene');
  }

  init(result) {
    this.result = result || {};
  }

  create() {
    this.cameras.main.setBackgroundColor('#10241a');
    this.report = gradeMatch(this.result.log || []);
    const facts = { ...matchFacts(this.result.log || []), ...varFacts(this.result.varReviews) };
    this.tech = buildReport({ log: this.result.log || [], grade: this.report, facts, varReviews: this.result.varReviews || [], mood: this.result.mood || null, refStats: this.result.refStats || null, conditions: this.result.conditions || null, crew: this.result.crew || null });
    this.summary = null;
    this.saved = true;
    this.isCareer = false;
    this.duplicate = false;
    if (this.result.mode === 'career') {
      const career = loadCareer();
      if (career) {
        this.isCareer = true;
        const r = this.report;
        const summary = applyMatch(career, this.result.fixture, {
          nota: r.nota,
          label: r.label,
          categories: r.categories,
          mistakes: r.mistakes,
          counts: r.counts,
          score: this.result.score,
          extras: { ...matchFacts(this.result.log || []), ...varFacts(this.result.varReviews) },
          varReviews: this.result.varReviews || [],
          mood: this.result.mood || null,
          report: this.tech,
          shots: this.result.shots || [],
          feud: this.result.feud || null,
          sides: sideImpact(this.result.log || []),
          conditions: this.result.conditions || null,
          crew: this.result.crew || null,
          hits: r.hits,
        });
        // applyMatch devolve null se este jogo já foi contabilizado (nunca duplica experiência ou reputação).
        if (summary === null) this.duplicate = true;
        else {
          this.summary = summary;
          this.saved = saveCareer(career);
        }
      }
    }
    this.tabs = [
      { id: 'grade', label: 'Nota do árbitro [1]' },
      { id: 'decisions', label: 'Decisões [2]' },
      { id: 'stats', label: 'Estatísticas [3]' },
      { id: 'report', label: 'Relatório [4]' },
      ...(this.summary ? [{ id: 'career', label: 'Carreira [5]' }] : []),
    ];

    this.root = document.createElement('div');
    this.root.id = 'result-panel';
    this.root.innerHTML = this.render();
    document.body.appendChild(this.root);

    this.root.addEventListener('mousedown', (e) => e.preventDefault());
    this.root.addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      if (btn.dataset.tab) this.showTab(btn.dataset.tab);
      else if (btn.dataset.action === 'next') this.next();
      else if (btn.dataset.action === 'menu') this.menu();
    });

    const kb = this.input.keyboard;
    kb.on('keydown-SPACE', () => this.next());
    kb.on('keydown-R', () => this.next());
    kb.on('keydown-M', () => this.menu());
    kb.on('keydown-FIVE', () => this.summary && this.showTab('career'));
    kb.on('keydown-FOUR', () => this.showTab('report'));
    kb.on('keydown-ONE', () => this.showTab('grade'));
    kb.on('keydown-TWO', () => this.showTab('decisions'));
    kb.on('keydown-THREE', () => this.showTab('stats'));

    this.events.once('shutdown', () => this.root.remove());
    this.showTab('grade');
  }

  next() {
    if (this.leaving) return;
    this.leaving = true;
    if (this.isCareer) this.scene.start('MenuScene', { screen: 'career' });
    else this.scene.start('MatchScene', { mode: 'quick' });
  }

  menu() {
    if (this.leaving) return;
    this.leaving = true;
    this.scene.start('MenuScene', { screen: this.isCareer ? 'career' : 'main' });
  }

  // Uso do VAR na partida (só aparece se foi usado).
  varSummary() {
    const v = this.result.varStats;
    if (!v || !v.reviews) return '';
    return ` · VAR: ${v.reviews} ${v.reviews === 1 ? 'revisão' : 'revisões'}, ${v.changed} ${v.changed === 1 ? 'decisão alterada' : 'decisões alteradas'}`;
  }

  showTab(id) {
    for (const el of this.root.querySelectorAll('[data-tab]')) el.classList.toggle('on', el.dataset.tab === id);
    for (const el of this.root.querySelectorAll('[data-pane]')) el.classList.toggle('on', el.dataset.pane === id);
  }

  render() {
    const { score } = this.result;
    return `
      <div class="rs-box">
        <div class="rs-head">
          <h1>FIM DE JOGO</h1>
          <p class="rs-score">${TEAMS.home.name} <b>${score.home}</b> x <b>${score.away}</b> ${TEAMS.away.name}</p>
          <p class="rs-empty">Duração: ${getDuration(this.result.fixture && this.result.fixture.duration).label}${this.varSummary()}${this.duplicate ? ' · este resultado já estava registrado na carreira' : ''}</p>
        </div>
        <div class="rs-tabs">
          ${this.tabs.map((t) => `<button class="rs-tab" data-tab="${t.id}">${t.label}</button>`).join('')}
        </div>
        <div class="rs-pane" data-pane="grade">${this.renderGrade()}</div>
        <div class="rs-pane" data-pane="decisions">${this.renderDecisions()}</div>
        <div class="rs-pane" data-pane="stats">${this.renderStats()}</div>
        <div class="rs-pane" data-pane="report">${reportToHtml(this.tech)}</div>
        ${this.summary ? `<div class="rs-pane" data-pane="career">${this.renderCareer()}</div>` : ''}
        <div class="rs-actions">
          <button class="rs-restart" data-action="next">${this.isCareer ? 'Voltar à carreira [Espaço]' : 'Jogar novamente [Espaço]'}</button>
          ${this.isCareer ? '' : '<button class="rs-secondary" data-action="menu">Menu [M]</button>'}
        </div>
      </div>`;
  }

  renderGrade() {
    const r = this.report;
    const cats = r.categories
      .map(
        (c) => `
        <div class="rs-cat">
          <span>${c.label}</span>
          <div class="rs-bar"><i class="${pct(c.ratio)}" style="width:${Math.round(c.ratio * 100)}%"></i></div>
          <span class="rs-pts">${comma(c.points)}/${c.max}</span>
          <div class="rs-detail">${c.detail}</div>
        </div>`
      )
      .join('');

    const mistakes = r.mistakes.slice(0, 3);
    const hits = r.hits.slice(0, 3);
    const mistakeItems = mistakes.length
      ? mistakes
          .map(
            (m) => `<li class="bad">${m.clock} · ${m.label}: ${m.errors.join(', ')}
              <small>Você: ${m.actual}</small><small>Correto: ${m.expected}</small></li>`
          )
          .join('')
      : '<li class="rs-empty">Nenhum erro registrado.</li>';
    const hitItems = hits.length
      ? hits.map((h) => `<li>${h.clock} · ${h.label}<small>${h.text}</small></li>`).join('')
      : '<li class="rs-empty">Nenhum acerto registrado.</li>';

    return `
      <div class="rs-grade"><b>${r.nota.toFixed(1).replace('.', ',')}</b><span>${r.label} · nota de 0 a 10</span></div>
      ${cats}
      <div class="rs-cols">
        <div><h3>Principais erros</h3><ul class="rs-list">${mistakeItems}</ul></div>
        <div><h3>Principais acertos</h3><ul class="rs-list">${hitItems}</ul></div>
      </div>`;
  }

  renderDecisions() {
    const log = [...(this.result.log || [])].sort((a, b) => a.time - b.time);
    if (!log.length) return '<p class="rs-empty">Nenhum lance aconteceu nesta partida.</p>';
    const items = log
      .map((e) => {
        const d = describeEntry(e);
        const extra = d.correct ? '' : `<small>Correto: ${d.expected}</small><small>Erro: ${d.errors.join(', ')}</small>`;
        return `<li class="${d.correct ? '' : 'bad'}">${d.correct ? '✓' : '✗'} ${d.clock} · ${d.label}${d.who ? ` — ${d.who}` : ''}
          <small>Você: ${d.actual}</small>${extra}</li>`;
      })
      .join('');
    const reviews = this.result.varReviews || [];
    const varList = reviews.length
      ? `<h3>Revisões do VAR</h3><ul class="rs-list">${reviews
          .map((r) => `<li class="${r.finalCorrect === false ? 'bad' : ''}">${r.kind === 'change' ? 'Alterada' : 'Mantida'} · ${r.clock} · ${r.label}${r.eligible ? '' : ' (fora das situações típicas de VAR)'}
            <small>Inicial: ${r.initial}</small><small>Final: ${r.final}</small>
            <small>${r.reason}${r.finalCorrect === true ? ' A avaliação considerou a decisão final correta.' : r.finalCorrect === false ? ' A avaliação ainda aponta erro nesta decisão.' : ''}</small></li>`)
          .join('')}</ul>`
      : '';
    return `<ul class="rs-list">${items}</ul>${varList}`;
  }

  renderStats() {
    const { stats, cards } = this.result;
    const poss = stats.home.possessionMs + stats.away.possessionMs || 1;
    const rows = [
      ['Posse de bola', `${Math.round((stats.home.possessionMs / poss) * 100)}%`, `${Math.round((stats.away.possessionMs / poss) * 100)}%`],
      ['Finalizações', stats.home.shots, stats.away.shots],
      ['Passes', stats.home.passes, stats.away.passes],
      ['Escanteios', stats.home.corners, stats.away.corners],
      ['Faltas cometidas', stats.home.fouls, stats.away.fouls],
      ['Cartões amarelos', cards.home.yellow, cards.away.yellow],
      ['Cartões vermelhos', cards.home.red, cards.away.red],
    ];
    const m = this.result.mood;
    const facts = matchFacts(this.result.log || []);
    const mood = m
      ? `<h3>Clima da partida</h3><ul class="rs-list">
          <li>Tensão máxima: <b>${m.label}</b> (${m.peak} de 100)${m.graveSpikes ? ` · ${m.graveSpikes} erro(s) grave(s) esquentaram o jogo` : ''}</li>
          <li>Torcida da casa: <b>${crowdLabel(m.crowd)}</b> no fim (pior momento: ${crowdLabel(m.crowdMin)})</li>
          ${facts.pressureDecisions ? `<li>Decisões com o clima quente: ${facts.pressureCorrect} de ${facts.pressureDecisions} corretas (valem um pouco mais na nota)</li>` : ''}
          ${facts.unpopularCorrect ? `<li>Decisões corretas, mas contra o time da casa (a torcida reclama, a nota não muda): ${facts.unpopularCorrect}</li>` : ''}
          ${facts.popularWrong ? `<li>Decisões erradas a favor do time da casa (a torcida gosta, a nota desconta): ${facts.popularWrong}</li>` : ''}
        </ul>`
      : '';
    return `<table class="rs-stats">
      <tr><td><b>${TEAMS.home.name}</b></td><td></td><td><b>${TEAMS.away.name}</b></td></tr>
      ${rows.map(([l, h, a]) => `<tr><td>${h}</td><td>${l}</td><td>${a}</td></tr>`).join('')}
    </table>${mood}`;
  }

  renderCareer() {
    const sm = this.summary;
    const comp = getCompetition(this.result.fixture.competitionId);
    const lvAfter = sm.after.level;
    const repSign = sm.repDelta >= 0 ? '+' : '';

    const lines = [
      `<li><b>Experiência</b> +${sm.xpGain} XP${sm.leveledUp ? ` · <span class="rs-up">subiu para o nível ${lvAfter.level}: ${lvAfter.title}!</span>` : ` · nível ${lvAfter.level} (${lvAfter.title})`}</li>`,
      `<li><b>Reputação</b> ${comma(sm.before.rep)} → ${comma(sm.after.rep)} (${repSign}${comma(sm.repDelta)} na partida)</li>`,
      `<li><b>Rodada</b> ${sm.week} de ${SEASON_ROUNDS} concluída${sm.seasonEnded ? ' (fim da temporada)' : ''}</li>`,
    ];
    for (const name of sm.newUnlocks) lines.push(`<li class="rs-up"><b>Nova competição liberada:</b> ${name}</li>`);
    for (const n of sm.memory || []) lines.push(`<li><b>Memória:</b> ${n.text}</li>`);
    if (sm.pressure && sm.pressure.level > 0) lines.push(`<li><b>Pressão do jogo:</b> ${sm.pressure.label} (${sm.pressure.tags.map((t) => t.label).join(', ')}). Não altera a nota.</li>`);
    for (const ev of sm.events || []) lines.push(`<li><b>Evento:</b> ${ev.title}</li>`);

    // Por que a experiência e a reputação mudaram (a nota técnica é a mesma da aba "Nota do árbitro").
    const why = [sm.reasons.xp, ...sm.reasons.rep].map((t) => `<li>${t}</li>`).join('');
    const goals = sm.objectivesDone
      .map((o) => `<li class="rs-up">Objetivo concluído: <b>${o.text}</b>${o.reward.xp ? ` (+${o.reward.xp} XP)` : ''}${o.reward.rep ? ` (+${o.reward.rep} de reputação)` : ''}</li>`)
      .join('');
    const suspension = sm.suspension
      ? `<p class="rs-empty">Oportunidades limitadas na próxima rodada (só jogos de importância 1): ${sm.suspension}. É por uma rodada e não impede a sua progressão.</p>`
      : '';

    let season = '';
    if (sm.seasonEnded) {
      const e = sm.seasonEnded;
      const d = e.division;
      const objs = e.objectives.map((o) => `<li class="${o.met ? '' : 'bad'}">${o.met ? '✓' : '✗'} ${o.text}</li>`).join('');
      const crit = d.criteria.map((c) => `<li class="${c.ok ? '' : 'bad'}">${c.ok ? '✓' : '✗'} ${c.text} <small>${c.detail}</small></li>`).join('');
      const title = { promoted: 'Promoção!', demoted: 'Rebaixamento', warning: 'Aviso', stayed: 'Divisão mantida', max: 'Divisão máxima' }[d.action];
      season = `
        <h3>Fim da temporada ${e.number}</h3>
        <p class="rs-empty">Média da temporada: ${e.avg === null ? '—' : comma(e.avg)} · ${e.met} de ${e.objectives.length} objetivos cumpridos · bônus de reputação +${e.repBonus}${e.eligible ? '' : ' (é preciso apitar 3 jogos ou mais para receber o bônus)'}</p>
        <ul class="rs-list">${objs}</ul>
        <h3>${title}</h3>
        <p class="${d.action === 'promoted' ? 'rs-up' : ''}">${d.reason}</p>
        ${crit ? `<ul class="rs-list">${crit}</ul>` : ''}
        ${(e.awards || []).length ? `<h3>Prêmios de temporada</h3><ul class="rs-list">${e.awards.map((a) => `<li class="rs-up">🏆 <b>${a.name}</b> (+${a.xp} XP)<small>${a.detail}</small></li>`).join('')}</ul>` : ''}
        ${e.retro ? `<h3>Retrospectiva da temporada</h3><ul class="rs-list"><li class="rs-up"><b>${e.retro.profile.label}</b><small>${e.retro.profile.text}</small></li>${e.retro.lines.map((l) => `<li>${l}</li>`).join('')}</ul><p class="rs-empty">Fica salva na aba Retrospectiva da central da carreira.</p>` : ''}
        <h3>Campeões da temporada</h3>
        <ul class="rs-list">${e.champions.map((ch) => `<li>${getCompetition(ch.competitionId).name}: <b>${getClub(ch.clubId).name}</b></li>`).join('')}</ul>`;
    }

    return `
      <p class="rs-empty">${comp ? comp.name : 'Partida'} · importância ${stars(this.result.fixture.importance)}</p>
      <ul class="rs-list">${lines.join('')}${goals}</ul>
      <h3>Por que mudou</h3>
      <ul class="rs-list compact">${why}</ul>
      ${suspension}
      ${sm.comms ? `<p class="rs-empty">Novas mensagens: ${sm.comms.news} notícia(s), ${sm.comms.emails} e-mail(s) e ${sm.comms.posts} publicação(ões). Veja nas abas Notícias, E-mails e Rede social.</p>` : ''}
      <h3>Comitê de arbitragem</h3>
      <p>${sm.committeeNote}</p>
      ${season}
      ${this.saved ? '' : '<p class="rs-empty">Não foi possível salvar a carreira neste navegador.</p>'}`;
  }
}
