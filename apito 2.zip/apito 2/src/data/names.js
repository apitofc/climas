import { hashString, makeRng } from '../utils/rng.js';

export const FIRST = ['Rafael', 'Bruno', 'Thiago', 'Caio', 'Lucas', 'Mateus', 'Diego', 'Felipe', 'André', 'Gustavo', 'Leandro', 'Rodrigo', 'Vitor', 'Henrique', 'Marcelo', 'Igor'];
export const LAST = [
  'Moura', 'Siqueira', 'Barros', 'Pacheco', 'Tavares', 'Nogueira', 'Furtado', 'Camargo', 'Brandão', 'Teles',
  'Queiroz', 'Magalhães', 'Azevedo', 'Peixoto', 'Maciel', 'Rangel', 'Duarte', 'Lacerda', 'Bezerra', 'Cordeiro',
  'Veloso', 'Xavier', 'Menezes', 'Batista', 'Cavalcante', 'Amaral', 'Seixas', 'Lopes', 'Farias', 'Guedes',
];

export function makeRoster(clubId) {
  const rng = makeRng(hashString(`roster:${clubId}`));
  const pool = [...LAST];
  const roster = [];
  for (let i = 0; i < 11; i++) {
    const k = Math.floor(rng.frac() * pool.length);
    const last = pool.splice(k, 1)[0];
    const first = FIRST[Math.floor(rng.frac() * FIRST.length)];
    roster.push({ first, last });
  }
  return roster;
}
