export const FORMATION_442 = [
  { role: 'GK', nx: 0.025, ny: 0.5 },
  { role: 'DEF', nx: 0.2, ny: 0.14 },
  { role: 'DEF', nx: 0.2, ny: 0.38 },
  { role: 'DEF', nx: 0.2, ny: 0.62 },
  { role: 'DEF', nx: 0.2, ny: 0.86 },
  { role: 'MID', nx: 0.4, ny: 0.12 },
  { role: 'MID', nx: 0.4, ny: 0.38 },
  { role: 'MID', nx: 0.4, ny: 0.62 },
  { role: 'MID', nx: 0.4, ny: 0.88 },
  { role: 'FWD', nx: 0.62, ny: 0.38 },
  { role: 'FWD', nx: 0.62, ny: 0.62 },
];
