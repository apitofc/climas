// Rivalidades fictícias (pares de clubes). Os nomes dos clássicos aparecem nos detalhes do jogo.
export const RIVALRIES = [
  { id: 'varzea', name: 'Clássico da Várzea', clubs: ['tamarindo', 'jaqueira'] },
  { id: 'litoral', name: 'Clássico do Litoral', clubs: ['maresia', 'coqueiral'] },
  { id: 'dunas', name: 'Dérbi das Dunas', clubs: ['dunas', 'jangada'] },
  { id: 'cerrado', name: 'Clássico do Cerrado', clubs: ['cerrado', 'serradourada'] },
  { id: 'sertao', name: 'Clássico do Sertão', clubs: ['sertaoun', 'valedosol'] },
  { id: 'estrelas', name: 'Clássico das Estrelas', clubs: ['aurora', 'estrelapolar'] },
  { id: 'norte', name: 'Clássico do Norte', clubs: ['falcoes', 'trovao'] },
  { id: 'nacional', name: 'Grande Clássico Nacional', clubs: ['titas', 'realhorizonte'] },
  { id: 'fenix', name: 'Clássico Imperial', clubs: ['imperial', 'fenix'] },
  { id: 'sul', name: 'Clássico do Sul', clubs: ['gigantes', 'dragoes'] },
  { id: 'continental', name: 'Clássico Continental', clubs: ['condor', 'meridian'] },
  { id: 'sol', name: 'Dérbi do Sol', clubs: ['solnascente', 'tucano'] },
];

export const rivalryOf = (homeId, awayId) => RIVALRIES.find((r) => r.clubs.includes(homeId) && r.clubs.includes(awayId)) || null;
