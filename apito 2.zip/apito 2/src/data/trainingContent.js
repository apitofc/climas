// Banco de perguntas do centro de treinamento (Upgrade 6). Tudo em português e alinhado às regras do jogo.
// Cada pergunta: { id, q, options: [texto...], answer: índice, explain }.

// Quando o VAR pode intervir (as situações típicas de revisão do jogo: gol irregular, pênalti e vermelho direto).
export const VAR_BANK = [
  { id: 'v1', q: 'Gol marcado depois de um impedimento claro que o árbitro não viu.', yes: true, explain: 'Possível gol irregular: o VAR pode intervir.' },
  { id: 'v2', q: 'Gol marcado depois de uma falta do time que marcou, não apitada.', yes: true, explain: 'Também é possível gol irregular: o VAR pode intervir (no jogo, o gol vira conferência na pausa depois dele).' },
  { id: 'v3', q: 'Defensor derruba o atacante dentro da área e o árbitro manda seguir.', yes: true, explain: 'Possível pênalti não marcado: o VAR pode intervir.' },
  { id: 'v4', q: 'Árbitro marca pênalti, mas o atacante se jogou sem contato.', yes: true, explain: 'Possível pênalti marcado errado: o VAR pode intervir nos dois sentidos.' },
  { id: 'v5', q: 'Entrada violenta, por trás e em alta velocidade, punida só com amarelo.', yes: true, explain: 'Possível vermelho direto: o VAR pode intervir.' },
  { id: 'v6', q: 'Gol anulado por um impedimento que parece legal.', yes: true, explain: 'O VAR também confere gol anulado por impedimento duvidoso.' },
  { id: 'v7', q: 'Falta leve no meio-campo, sem cartão.', yes: false, explain: 'Falta comum fora da área e sem cartão grave: decisão só do campo.' },
  { id: 'v8', q: 'Amarelo por reclamação.', yes: false, explain: 'Cartão amarelo não é revisável: decisão só do campo.' },
  { id: 'v9', q: 'Cobrança de lateral para o lado errado.', yes: false, explain: 'Reposição de bola não é situação de revisão.' },
  { id: 'v10', q: 'Disputa legal no meio-campo, sem falta.', yes: false, explain: 'Disputa legal sem consequência no gol, no pênalti ou no vermelho: só o campo decide.' },
  { id: 'v11', q: 'Segundo amarelo para o mesmo jogador.', yes: false, explain: 'O segundo amarelo não é revisável. Só o vermelho direto é.' },
  { id: 'v12', q: 'Amarelo por simulação fora da área.', yes: false, explain: 'Simulação fora da área, punida com amarelo: decisão só do campo.' },
];

// Situações de confronto: como manter o jogo sob controle. Opções: 0 seguir, 1 conversar (advertência verbal), 2 amarelo, 3 vermelho.
export const CONFRONT_OPTIONS = ['Seguir o jogo', 'Conversar (advertência verbal)', 'Cartão amarelo', 'Cartão vermelho'];
export const CONFRONT_BANK = [
  { id: 'c1', q: 'O capitão se aproxima e pergunta, calmo, por que a falta foi marcada.', answer: 1, explain: 'Explicar em poucas palavras esfria o clima e evita reclamação maior. Não precisa de cartão.' },
  { id: 'c2', q: 'Um jogador reclama da falta com gestos exagerados e grita com você.', answer: 2, explain: 'Reclamação com gestos e gritos é conduta antidesportiva: amarelo.' },
  { id: 'c3', q: 'Depois de uma falta, dois jogadores se empurram sem se agredir.', answer: 2, explain: 'O empurrão é conduta antidesportiva: amarelo (os dois, se os dois empurraram).' },
  { id: 'c4', q: 'Um jogador dá uma cabeçada no adversário longe da bola.', answer: 3, explain: 'Agressão é conduta violenta: vermelho direto.' },
  { id: 'c5', q: 'Um jogador cospe no adversário durante a discussão.', answer: 3, explain: 'Cuspir é vermelho direto.' },
  { id: 'c6', q: 'O técnico reclama alto da área técnica, mas não entra em campo.', answer: 1, explain: 'Primeiro uma conversa ou advertência verbal. Se persistir, a punição sobe.' },
  { id: 'c7', q: 'Um jogador demora a repor a bola, pela primeira vez.', answer: 1, explain: 'Na primeira vez, advertência verbal. Se repetir, amarelo.' },
  { id: 'c8', q: 'Um jogador comemora o gol tirando a camisa.', answer: 2, explain: 'Tirar a camisa na comemoração é amarelo.' },
  { id: 'c9', q: 'Um jogador aplaude de forma irônica a sua decisão.', answer: 2, explain: 'Aplauso irônico é desrespeito: amarelo.' },
  { id: 'c10', q: 'Um jogador levanta os braços, respira fundo e volta para a posição.', answer: 0, explain: 'Frustração sem desrespeito não precisa de nada: siga o jogo.' },
];

// Testes de regras e interpretação (alinhados às regras do jogo).
export const RULES_BANK = [
  { id: 'r1', q: 'Falta leve, e a equipe prejudicada continua com a bola em posição de ataque. O que fazer?', options: ['Dar vantagem', 'Parar o jogo e dar cartão', 'Marcar impedimento'], answer: 0, explain: 'Falta leve com a equipe prejudicada mantendo a bola: vantagem. Se não se confirmar, volta para a falta.' },
  { id: 'r2', q: 'Entrada por trás e em alta velocidade. Quantas agravantes e qual cartão?', options: ['Uma agravante, sem cartão', 'Duas agravantes, amarelo', 'Três agravantes, vermelho'], answer: 1, explain: 'Por trás + alta velocidade = 2 agravantes: amarelo. Com a imprudência, seriam 3: vermelho.' },
  { id: 'r3', q: 'Qual falta NUNCA aceita vantagem?', options: ['Falta leve', 'Falta pesada (grave)', 'Simulação'], answer: 1, explain: 'Falta pesada deve ser marcada na hora, com o cartão que ela pede.' },
  { id: 'r4', q: 'O mesmo jogador comete a 3ª falta leve marcada contra ele. O que a regra do jogo pede?', options: ['Nada, é só falta', 'Amarelo por falta persistente', 'Vermelho'], answer: 1, explain: 'A partir da 3ª falta marcada, a falta leve já merece amarelo (infração persistente).' },
  { id: 'r5', q: 'Defensor interrompe com falta, fora da área, um ataque promissor, mesmo com pouco contato.', options: ['Falta sem cartão', 'Falta com amarelo (falta tática)', 'Vantagem'], answer: 1, explain: 'Falta tática: amarelo. Se era o último defensor com chance clara de gol, vermelho.' },
  { id: 'r6', q: 'Atacante cai sem nenhum contato dentro da área.', options: ['Pênalti', 'Amarelo para o atacante, sem falta', 'Seguir sem punir'], answer: 1, explain: 'Simulação: amarelo para quem caiu e tiro livre indireto para o adversário.' },
  { id: 'r7', q: 'Gol marcado, mas o time que marcou cometeu uma falta no lance. O que fazer?', options: ['Confirmar o gol', 'Anular o gol', 'Dar cartão ao goleiro'], answer: 1, explain: 'Gol depois de falta ou impedimento de quem marcou deve ser anulado, com ou sem VAR.' },
  { id: 'r8', q: 'Depois de um gol anulado por impedimento, como recomeça o jogo?', options: ['Pontapé inicial', 'Tiro livre indireto para o adversário', 'Tiro de meta'], answer: 1, explain: 'Impedimento: tiro livre indireto para a equipe que defendia.' },
  { id: 'r9', q: 'Braço afastado do corpo, em direção à bola, dentro da área do defensor.', options: ['Pênalti', 'Seguir o jogo', 'Tiro de meta'], answer: 0, explain: 'Mão na bola intencional dentro da área é pênalti.' },
  { id: 'r10', q: 'Bola chutada em alta velocidade bate no braço colado ao corpo do defensor, sem tempo de reação.', options: ['Pênalti', 'Seguir o jogo', 'Amarelo para o defensor'], answer: 1, explain: 'Braço junto ao corpo e sem tempo de reação: não é falta.' },
  { id: 'r11', q: 'A bola foi jogada primeiro e depois houve contato.', options: ['É falta', 'É disputa legal', 'É simulação'], answer: 1, explain: 'Se o defensor joga a bola primeiro, a disputa é legal.' },
  { id: 'r12', q: 'Jogador que já tem um amarelo recebe outro. O que acontece?', options: ['Só advertência', 'Fica com dois amarelos e segue em campo', 'Vermelho e expulsão'], answer: 2, explain: 'O segundo amarelo vira vermelho e o jogador é expulso.' },
  { id: 'r13', q: 'A vantagem foi dada e a equipe perdeu a bola logo depois. O que fazer?', options: ['Seguir sem marcar nada', 'Voltar e marcar a falta', 'Dar escanteio'], answer: 1, explain: 'Se a vantagem não se confirma, volta para a falta e os cartões ainda valem.' },
  { id: 'r14', q: 'Atacante está na própria metade do campo, à frente do penúltimo defensor, quando recebe o passe.', options: ['Impedimento', 'Posição legal', 'Falta'], answer: 1, explain: 'Na própria metade não há impedimento.' },
  { id: 'r15', q: 'Atacante à frente do penúltimo defensor e da bola, na metade de ataque, recebe o passe.', options: ['Impedimento', 'Posição legal', 'Seguir jogando'], answer: 0, explain: 'À frente do penúltimo defensor e da bola, na metade de ataque: impedimento.' },
  { id: 'r16', q: 'Atacante à frente do penúltimo defensor, mas atrás da bola quando o passe sai.', options: ['Impedimento', 'Posição legal', 'Pênalti'], answer: 1, explain: 'Atrás da bola, ele não está em impedimento.' },
  { id: 'r17', q: 'O clima da partida está quente. Qual atitude ajuda mais a esfriar o jogo?', options: ['Ignorar as reclamações', 'Acertar as decisões e conversar a tempo', 'Dar cartões para todos'], answer: 1, explain: 'Acertar as decisões esfria o clima. Ignorar faltas reais e dar cartão demais esquentam.' },
  { id: 'r18', q: 'A torcida reclama de uma decisão que a avaliação técnica considera correta. Como isso conta?', options: ['Como erro', 'Como acerto: a torcida não altera a nota', 'Reduz a reputação'], answer: 1, explain: 'A nota avalia a decisão, não a reação da torcida.' },
  { id: 'r19', q: 'Qual é o papel das evidências no painel de decisão?', options: ['Enfeite', 'Mostrar o que o lance tinha para você interpretar', 'Dizer a resposta certa'], answer: 1, explain: 'As evidências são o que o árbitro viu. A interpretação é com você.' },
  { id: 'r20', q: 'Chuva forte e gramado pesado. O que muda na regra do jogo?', options: ['Nada: as regras e as evidências valem igual', 'Faltas passam a valer menos', 'O árbitro pode ignorar contatos leves'], answer: 0, explain: 'O tempo muda o contexto (mais contatos), mas a regra de cada lance é a mesma.' },
];
