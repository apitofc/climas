import { GAME_WIDTH, GAME_HEIGHT } from '../config.js';

// Chuva, tempestade e neblina desenhadas por código sobre a tela (pixel art simples, sem arquivos de imagem).
// É só visual: o efeito no jogo vem de MatchConditions (atrito da bola, velocidade e contatos).
const DEPTH = 8000;

export default class WeatherFx {
  constructor(scene, cond) {
    this.scene = scene;
    this.cond = cond;
    this.drops = [];
    this.flash = 0;
    this.nextFlash = 6000 + Math.random() * 8000;
    const wet = cond.weather === 'rain' || cond.weather === 'storm';
    if (wet) {
      const n = cond.weather === 'storm' ? 110 : 55;
      for (let i = 0; i < n; i++) this.drops.push({ x: Math.random() * GAME_WIDTH, y: Math.random() * GAME_HEIGHT, len: 3 + Math.random() * 3, speed: 150 + Math.random() * 90 });
      this.g = scene.add.graphics().setScrollFactor(0).setDepth(DEPTH);
      this.tint = scene.add.rectangle(0, 0, GAME_WIDTH, GAME_HEIGHT, 0x16202e, cond.weather === 'storm' ? 0.3 : 0.14).setOrigin(0).setScrollFactor(0).setDepth(DEPTH - 1);
    }
    if (cond.weather === 'fog') {
      this.fog = scene.add.rectangle(0, 0, GAME_WIDTH, GAME_HEIGHT, 0xdfe6ea, (1 - cond.visibility) * 1.0).setOrigin(0).setScrollFactor(0).setDepth(DEPTH - 1);
    }
    this.flashRect = cond.weather === 'storm' ? scene.add.rectangle(0, 0, GAME_WIDTH, GAME_HEIGHT, 0xffffff, 0).setOrigin(0).setScrollFactor(0).setDepth(DEPTH + 1) : null;
  }

  update(delta) {
    if (!this.g) return;
    const dt = delta / 1000;
    this.g.clear();
    this.g.lineStyle(1, 0xb8d4f0, 0.55);
    for (const d of this.drops) {
      d.y += d.speed * dt;
      d.x -= d.speed * 0.25 * dt;
      if (d.y > GAME_HEIGHT) {
        d.y = -d.len;
        d.x = Math.random() * (GAME_WIDTH + 40);
      }
      if (d.x < -4) d.x += GAME_WIDTH + 4;
      this.g.lineBetween(Math.round(d.x), Math.round(d.y), Math.round(d.x - d.len * 0.25), Math.round(d.y + d.len));
    }
    if (this.flashRect) {
      this.nextFlash -= delta;
      if (this.nextFlash <= 0) {
        this.flash = 1;
        this.nextFlash = 8000 + Math.random() * 12000;
      }
      this.flash = Math.max(0, this.flash - dt * 4);
      this.flashRect.setAlpha(this.flash * 0.22);
    }
  }

  destroy() {
    for (const o of [this.g, this.tint, this.fog, this.flashRect]) if (o) o.destroy();
  }
}
