import { FIELD_RECT, WORLD_WIDTH, WORLD_HEIGHT, GAME_WIDTH, GAME_HEIGHT } from '../config.js';
import { ACTOR } from '../systems/VarRecorder.js';
import { INCIDENT } from '../systems/MatchRules.js';

// Zoom por câmera (valores "redondos" para o pixel art ficar nítido).
const ZOOM = { ball: 2, incident: 3, player: 3, referee: 2, field: 0.5 };
const OVERLAY_DEPTH = 9000;
const FILM_DEPTH = 20000;
const FILM_TEXT = { fontFamily: 'monospace', fontSize: '8px', color: '#ffffff', stroke: '#000000', strokeThickness: 1 };
const INSET = 8; // margem do "visor" da câmera
const speedText = (v) => `${String(v).replace('.', ',')}x`;

// Mostra a revisão do VAR: no lugar dos sprites ao vivo (escondidos), aparecem "fantasmas" que apenas repetem
// o que o VarRecorder gravou (posição, quadro do sprite e pose de cada jogador, árbitro e bola).
export default class VarReplay {
  constructor(scene, varSys) {
    this.scene = scene;
    this.var = varSys;
    this.running = false;
    this.hidden = [];
    this.ghosts = [];
    this.overlay = null;
    this.camKey = '';
    this.film = null;
    this.uiCam = null;
  }

  // ---- Liga / desliga -------------------------------------------------------------------------------------------

  start() {
    if (this.running) return;
    const scene = this.scene;
    this.hideLive();
    this.buildGhosts();
    this.overlay = scene.add.graphics().setDepth(OVERLAY_DEPTH);

    const cam = scene.cameras.main;
    cam.stopFollow();
    cam.removeBounds();
    cam.setDeadzone(0, 0);
    this.camKey = '';
    this.buildFilm();
    this.running = true;
    this.render();
  }

  stop() {
    if (!this.running) return;
    const scene = this.scene;
    this.running = false;
    for (const g of this.ghosts) {
      g.sprite.destroy();
      if (g.shadow) g.shadow.destroy();
    }
    this.ghosts = [];
    if (this.overlay) this.overlay.destroy();
    this.overlay = null;
    this.destroyFilm();
    this.showLive();

    // Câmera de volta ao árbitro, como era antes da revisão.
    const cam = scene.cameras.main;
    cam.stopFollow();
    cam.setZoom(1);
    cam.setBounds(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
    cam.setDeadzone(24, 14);
    cam.centerOn(scene.referee.x, scene.referee.y);
    cam.startFollow(scene.referee, true, 0.1, 0.1);
  }

  // Esconde tudo o que é da partida ao vivo e guarda o que estava visível para devolver depois.
  hideLive() {
    const scene = this.scene;
    const objs = [];
    for (const p of this.var.sim.allPlayers) objs.push(p, p.shadow);
    objs.push(scene.referee, scene.referee.shadow, scene.ball, scene.ball.shadow, scene.ball.trailG);
    if (scene.effects) {
      for (const m of scene.effects.markers.values()) objs.push(m);
      for (const c of scene.effects.cards) for (const r of c.rects) objs.push(r.rect);
    }
    this.hidden = objs.filter((o) => o && o.setVisible).map((o) => ({ o, visible: o.visible }));
    for (const h of this.hidden) h.o.setVisible(false);
  }

  showLive() {
    for (const h of this.hidden) if (h.o.scene) h.o.setVisible(h.visible);
    this.hidden = [];
  }

  buildGhosts() {
    const scene = this.scene;
    this.ghosts = this.var.rec.actors.map((e, i) => {
      const key = e.texture && e.texture.key;
      if (i === ACTOR.BALL) {
        return {
          sprite: scene.add.image(e.x, e.y, key || 'ball').setOrigin(0.5, 0.5),
          shadow: scene.add.image(e.x, e.y + 2, 'ball_shadow').setDepth(1),
        };
      }
      return {
        sprite: scene.add.sprite(e.x, e.y, key, 0).setOrigin(0.5, 1),
        shadow: scene.add.image(e.x, e.y - 1, 'shadow').setDepth(1),
      };
    });
  }

  // ---- Quadro a quadro ------------------------------------------------------------------------------------------

  render() {
    if (!this.running) return;
    const v = this.var.current();
    for (let i = 0; i < this.ghosts.length; i++) {
      const a = v.actors[i];
      const g = this.ghosts[i];
      const x = Math.round(a.x);
      const y = Math.round(a.y);
      const visible = i < ACTOR.FIRST_PLAYER || a.present;
      g.sprite.setVisible(visible);
      if (g.shadow) g.shadow.setVisible(visible);
      g.sprite.setPosition(x, y);
      g.sprite.setDepth(y);
      if (i === ACTOR.BALL) {
        g.shadow.setPosition(x, y + 2);
      } else {
        g.sprite.setFrame(a.frame);
        g.sprite.setFlipX(a.flipX);
        g.sprite.setAngle(a.angle);
        g.shadow.setPosition(x, y - 1);
      }
    }
    this.drawOverlay(v);
    this.applyCamera();
    this.renderFilm();
  }

  // ---- Visual de câmera/VHS ---------------------------------------------------------------------------------------
  // O zoom da câmera principal também afetaria elementos fixos na tela, então o visor é desenhado por uma
  // segunda câmera (sem zoom) que só enxerga estes objetos.

  buildFilm() {
    const scene = this.scene;
    const mk = (x, y, text, origin = [0, 0]) => scene.add.text(x, y, text, FILM_TEXT).setOrigin(...origin).setDepth(FILM_DEPTH + 1);
    const g = scene.add.graphics().setDepth(FILM_DEPTH);
    this.film = {
      g,
      mode: mk(INSET + 6, INSET + 4, 'PLAY'),
      rec: mk(INSET + 6, INSET + 15, 'REC'),
      speed: mk(GAME_WIDTH - INSET - 6, INSET + 4, '', [1, 0]),
      line1: mk(INSET + 6, GAME_HEIGHT - INSET - 25, ''),
      line2: mk(INSET + 6, GAME_HEIGHT - INSET - 14, ''),
      last: {},
    };
    this.filmObjects = [g, this.film.mode, this.film.rec, this.film.speed, this.film.line1, this.film.line2];
    scene.cameras.main.ignore(this.filmObjects);
    this.uiCam = scene.cameras.add(0, 0, GAME_WIDTH, GAME_HEIGHT);
    this.uiCam.ignore(scene.children.list.filter((o) => !this.filmObjects.includes(o)));
  }

  destroyFilm() {
    if (!this.film) return;
    if (this.uiCam) this.scene.cameras.remove(this.uiCam);
    this.uiCam = null;
    for (const o of this.filmObjects) o.destroy();
    this.film = null;
    this.filmObjects = [];
  }

  setFilmText(key, text) {
    if (this.film.last[key] === text) return;
    this.film.last[key] = text;
    this.film[key].setText(text);
  }

  renderFilm() {
    const f = this.film;
    if (!f) return;
    const g = f.g;
    const v = this.var;
    const now = this.scene.time.now;
    g.clear();

    // Imagem levemente escurecida, chuvisco e falhas horizontais, como fita antiga.
    g.fillStyle(0x000000, 0.12);
    g.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
    for (let i = 0; i < 60; i++) {
      g.fillStyle(0xffffff, 0.1 + Math.random() * 0.35);
      g.fillRect(Math.floor(Math.random() * GAME_WIDTH), Math.floor(Math.random() * GAME_HEIGHT), 1, 1);
    }
    for (let i = 0; i < 10; i++) {
      g.fillStyle(0xffffff, 0.15 + Math.random() * 0.3);
      g.fillRect(Math.floor(Math.random() * GAME_WIDTH), Math.floor(Math.random() * GAME_HEIGHT), 4 + Math.floor(Math.random() * 16), 1);
    }
    if (Math.random() < 0.06) {
      g.fillStyle(0xffffff, 0.1);
      g.fillRect(0, Math.floor(Math.random() * GAME_HEIGHT), GAME_WIDTH, 2 + Math.floor(Math.random() * 3));
    }

    // Cantos do visor.
    const L = 14;
    const T = 2;
    const x0 = INSET;
    const y0 = INSET;
    const x1 = GAME_WIDTH - INSET;
    const y1 = GAME_HEIGHT - INSET;
    g.fillStyle(0xffffff, 0.95);
    for (const [cx, cy, dx, dy] of [[x0, y0, 1, 1], [x1, y0, -1, 1], [x0, y1, 1, -1], [x1, y1, -1, -1]]) {
      g.fillRect(dx > 0 ? cx : cx - L, dy > 0 ? cy : cy - T, L, T);
      g.fillRect(dx > 0 ? cx : cx - T, dy > 0 ? cy : cy - L, T, L);
    }

    // PLAY / PAUSE / SLOW e ícone.
    const paused = !v.playing;
    const slow = v.speed < 1;
    this.setFilmText('mode', paused ? 'PAUSE' : slow ? 'SLOW' : 'PLAY');
    const ix = f.mode.x + f.mode.width + 4;
    const iy = f.mode.y + 1;
    g.fillStyle(0xffffff, 1);
    if (paused) {
      g.fillRect(ix, iy, 2, 7);
      g.fillRect(ix + 4, iy, 2, 7);
    } else {
      g.fillTriangle(ix, iy, ix, iy + 7, ix + 6, iy + 3.5);
    }

    // REC piscando.
    if (Math.floor(now / 600) % 2 === 0) {
      g.fillStyle(0xe8262b, 1);
      g.fillCircle(f.rec.x + f.rec.width + 6, f.rec.y + 4, 2.5);
    }

    // Velocidade (no lugar do "--:--") e carimbo de data/hora, aqui o momento da partida.
    this.setFilmText('speed', speedText(v.speed));
    const clock = v.clockAtCursor();
    const view = v.current();
    this.setFilmText('line1', `${clock.period}T ${clock.text}${clock.added ? ' +' : ''}`);
    this.setFilmText('line2', v.isCursorVoided() ? 'LANCE ANULADO' : `VAR  ${view.score.home}-${view.score.away}`);
  }

  selectedIncident() {
    const ev = this.var.selectedEvent();
    const info = ev && ev.incidentId ? this.var.infoOf(ev.incidentId) : null;
    return { ev, inc: info ? info.incident : null };
  }

  // Marcações sobre a imagem: ponto do lance, quem fez e quem sofreu e, no impedimento, as linhas de referência.
  drawOverlay(v) {
    const g = this.overlay;
    g.clear();
    const { ev, inc } = this.selectedIncident();
    if (!ev) return;

    const t = this.scene.time.now;
    const pulse = 8 + Math.sin(t / 160) * 2;
    g.lineStyle(1, 0xffe066, 0.9);
    g.strokeCircle(Math.round(ev.x), Math.round(ev.y), pulse);

    if (!inc) return;
    const actors = this.var.rec.actors;
    const mark = (player, color) => {
      const i = actors.indexOf(player);
      if (i < 0) return;
      const a = v.actors[i];
      if (!a.present) return;
      const x = Math.round(a.x);
      const y = Math.round(a.y) - 19;
      g.fillStyle(0x000000, 0.8);
      g.fillTriangle(x - 4, y - 1, x + 4, y - 1, x, y + 5);
      g.fillStyle(color, 1);
      g.fillTriangle(x - 3, y, x + 3, y, x, y + 4);
    };
    const offsideLike = inc.type === INCIDENT.OFFSIDE || inc.type === INCIDENT.LEGAL_POSITION;
    mark(inc.victim, 0xffffff);
    mark(inc.offender, 0xff5a5a);

    if (offsideLike) {
      // Linhas na posição real dos dois jogadores neste instante da gravação.
      const line = (player, color) => {
        const i = actors.indexOf(player);
        if (i < 0 || !v.actors[i].present) return;
        const x = Math.round(v.actors[i].x);
        g.lineStyle(1, color, 0.85);
        g.lineBetween(x, FIELD_RECT.top, x, FIELD_RECT.bottom);
      };
      line(inc.victim, 0xffe066);
      line(inc.offender, 0xff5a5a);
    }
  }

  applyCamera() {
    const scene = this.scene;
    const cam = scene.cameras.main;
    const mode = this.var.camera;
    const { ev, inc } = this.selectedIncident();
    const key = `${mode}:${ev ? ev.id : '-'}`;
    if (key === this.camKey) return;
    this.camKey = key;

    cam.stopFollow();
    cam.setZoom(ZOOM[mode] || 1);
    const follow = (sprite) => cam.startFollow(sprite, true, 0.18, 0.18);
    const ghostOf = (player) => {
      const i = this.var.rec.actors.indexOf(player);
      return i >= 0 ? this.ghosts[i].sprite : null;
    };

    if (mode === 'field') {
      cam.centerOn(FIELD_RECT.cx, FIELD_RECT.cy);
    } else if (mode === 'incident' && ev) {
      cam.centerOn(ev.x, ev.y);
    } else if (mode === 'player' && inc && ghostOf(inc.offender)) {
      follow(ghostOf(inc.offender));
    } else if (mode === 'referee') {
      follow(this.ghosts[ACTOR.REFEREE].sprite);
    } else {
      follow(this.ghosts[ACTOR.BALL].sprite);
    }
  }
}
