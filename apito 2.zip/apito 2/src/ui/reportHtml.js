// Desenha o relatório técnico (TechnicalReport.buildReport) como HTML. Usado na tela de resultado e no histórico da carreira.
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const comma = (n) => String(n).replace('.', ',');
const dot = (v) => `<span class="rp-dot ${v}"></span>`;
const list = (items) => (items.length ? `<ul class="rp-list">${items.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : '');

export function reportToHtml(r) {
  if (!r) return '<p class="rs-empty">Esta partida não tem relatório salvo.</p>';
  const s = r.summary;
  const p = r.positioning;
  const d = r.discipline;
  const v = r.var;
  const parts = [];

  parts.push(`<div class="rp-head"><b>Relatório da Comissão de Arbitragem</b><span>Nota ${comma(s.nota)} · ${esc(s.label)}</span></div>
    <p class="rp-lead">${esc(s.headline)}</p>
    ${s.strengths.length ? `<h4>O que funcionou</h4>${list(s.strengths)}` : ''}
    ${s.attention.length ? `<h4>Pontos de atenção</h4>${list(s.attention)}` : ''}`);

  if (r.context && r.context.length) parts.push(`<h3>Contexto da partida</h3>${list(r.context)}`);

  parts.push(`<h3>Por que essa nota</h3><ul class="rp-list">${r.why.map((w) => `<li>${dot(w.verdict)}<b>${esc(w.label)}</b> ${w.points} de ${w.max}: ${esc(w.text)}</li>`).join('')}</ul>`);

  parts.push(`<h3>Decisões</h3><p>${r.decisions.right} de ${r.decisions.total} lances decididos corretamente${r.decisions.whistles ? ` · ${r.decisions.whistles} apito(s) sem lance` : ''}.</p>
    ${list(r.decisions.byType.map((t) => `${t.label}: ${t.right} de ${t.total}`))}`);

  const pos = [];
  if (p.avgDistance !== null) pos.push(`Distância média até os lances: ${p.avgDistance} px (${p.near} lance(s) bem perto, ${p.far} longe${p.farClocks.length ? `, aos ${p.farClocks.join(', ')}` : ''}).`);
  else pos.push('Sem lances para avaliar a posição.');
  if (p.fieldLengths !== null) pos.push(`Movimentação: percorreu cerca de ${p.fieldLengths} comprimentos de campo${p.perLance ? ` (uns ${p.perLance} px por lance)` : ''}.`);
  parts.push(`<h3>${dot(p.verdict)}Posicionamento e movimentação</h3>${list(pos)}`);

  parts.push(`<h3>${dot(r.consistency.verdict)}Consistência na aplicação das regras</h3>${r.consistency.issues.length ? list(r.consistency.issues) : `<p>${r.consistency.groups ? 'Situações parecidas foram decididas do mesmo jeito.' : 'Poucos lances parecidos para comparar.'}</p>`}<p class="rp-small">${esc(r.consistency.detail)}</p>`);

  const disc = [`${d.yellow} amarelo(s) e ${d.red} vermelho(s). ${d.detail}.`];
  if (d.tension) disc.push(`Tensão máxima: ${d.tension.label} (${d.tension.peak} de 100)${d.tension.graveSpikes ? `, com ${d.tension.graveSpikes} erro(s) grave(s) esquentando o jogo` : ''}.`);
  parts.push(`<h3>${dot(d.verdict)}Controle disciplinar</h3>${list(disc.concat(d.problems))}`);

  if (r.crew) parts.push(`<h3>${dot(r.crew.verdict)}Equipe de arbitragem</h3>${list(r.crew.lines)}`);

  parts.push(`<h3>Uso do VAR</h3>${v.used ? `<p>${v.reviews} revisão(ões): ${v.changed} decisão(ões) alterada(s), ${v.fixed} corrigida(s) com acerto e ${v.worsened} que continuou(aram) errada(s).</p>${list(v.lines)}` : '<p>O VAR não foi usado nesta partida.</p>'}`);

  parts.push(`<h3>Lances que poderiam ter sido melhor interpretados</h3>${
    r.misses.length
      ? `<ul class="rp-list">${r.misses.map((m) => `<li class="bad"><b>${esc(m.clock)} · ${esc(m.label)}</b>${m.who ? ` (${esc(m.who)})` : ''}
          <small>Você: ${esc(m.did)} · O certo: ${esc(m.should)}</small>
          ${m.evidence.length ? `<small>O painel mostrava: ${esc(m.evidence.join(', '))}</small>` : ''}
          <small class="rp-tip">${esc(m.tip)}</small></li>`).join('')}</ul>`
      : '<p>Nenhum lance com erro. Boa leitura do jogo.</p>'
  }`);

  parts.push(`<h3>Recomendações de treinamento</h3>${
    r.recommendations.length
      ? `<ul class="rp-list">${r.recommendations.map((x) => `<li><b>${esc(x.training)}</b><small>${esc(x.reason)}</small><small class="rp-tip">Faça na aba Treino da carreira.</small></li>`).join('')}</ul>`
      : '<p>Sem recomendações urgentes: mantenha o padrão e foque nos lances difíceis dos próximos jogos.</p>'
  }`);

  parts.push(`<h3>O que não entra na nota</h3>${list(r.outside)}`);
  return `<div class="rp">${parts.join('')}</div>`;
}
