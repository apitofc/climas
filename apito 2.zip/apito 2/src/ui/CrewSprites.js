import { FIELD_RECT } from '../config.js';

// Assistentes e quarto árbitro desenhados por código nas linhas laterais (sem arquivos de imagem).
// Os assistentes acompanham a jogada pela linha lateral e levantam a bandeira quando sinalizam um impedimento;
// o quarto árbitro fica na área técnica, com a placa.
const L = FIELD_RECT;
const DEPTH = 7000;
const SHIRT = 0xf2c94c;

export default class CrewSprites {
  constructor(scene, sim) {
    this.scene = scene;
    this.sim = sim;
    this.g = scene.add.graphics().setDepth(DEPTH);
    this.x = { a1: L.cx, a2: L.cx };
    this.flagUntil = { a1: 0, a2: 0 };
    scene.events.on('crew-flag', ({ who }) => {
      this.flagUntil[who] = scene.time.now + 1800;
    });
    scene.events.once('shutdown', () => this.g.destroy());
  }

  person(x, y, flag) {
    const g = this.g;
    g.fillStyle(0x111111, 1).fillRect(x - 3, y - 5, 6, 10); // contorno
    g.fillStyle(SHIRT, 1).fillRect(x - 2, y - 3, 4, 7);
    g.fillStyle(0xf0c8a0, 1).fillRect(x - 2, y - 7, 4, 3);
    if (flag) {
      g.fillStyle(0xdddddd, 1).fillRect(x + 3, y - 14, 1, 10); // haste
      g.fillStyle(0xe8553a, 1).fillRect(x + 4, y - 14, 6, 4); // bandeira levantada
    } else {
      g.fillStyle(0xe8553a, 1).fillRect(x + 3, y - 1, 4, 3); // bandeira baixa
    }
  }

  update(delta) {
    const g = this.g;
    g.clear();
    const now = this.scene.time.now;
    const bx = this.sim.ball.x;
    for (const [id, y] of [['a1', L.top - 8], ['a2', L.bottom + 8]]) {
      this.x[id] += (Math.max(L.left + 12, Math.min(L.right - 12, bx)) - this.x[id]) * Math.min(1, delta / 400);
      this.person(Math.round(this.x[id]), y, now < this.flagUntil[id]);
    }
    // Quarto árbitro: perto do meio da linha lateral de baixo, com a placa.
    const fx = L.cx - 70;
    const fy = L.bottom + 16;
    this.person(fx, fy, false);
    g.fillStyle(0xffffff, 1).fillRect(fx + 6, fy - 4, 8, 6);
    g.fillStyle(0x111111, 1).fillRect(fx + 8, fy - 2, 4, 2);
  }
}
