import { TEAMS } from '../config.js';
import { playerLabel } from '../utils/labels.js';

// Painel curto de reclamação: aparece depois de uma falta marcada quando um jogador protesta. O jogo fica parado até a
// escolha: seguir, advertência verbal ou cartão amarelo.
export default class DissentPanel {
  constructor(scene, onChoose) {
    this.scene = scene;
    this.onChoose = onChoose;
    this.open_ = false;
    this.opened = 0;
    this.root = document.createElement('div');
    this.root.id = 'dissent-panel';
    document.body.appendChild(this.root);
    this.root.addEventListener('mousedown', (e) => e.preventDefault());
    this.root.addEventListener('click', (e) => {
      const btn = e.target.closest('button[data-choice]');
      if (btn) this.choose(btn.dataset.choice);
    });
    this.onKey = (e) => {
      if (!this.open_ || performance.now() - this.opened < 250) return;
      const k = e.key.toLowerCase();
      const map = { i: 'ignore', a: 'warning', 1: 'yellow' };
      if (map[k]) {
        e.preventDefault();
        e.stopPropagation();
        this.choose(map[k]);
      }
    };
    window.addEventListener('keydown', this.onKey, true);
    scene.events.once('shutdown', () => this.destroy());
  }

  get isOpen() {
    return this.open_;
  }

  open(d) {
    const p = d.player;
    this.open_ = true;
    this.opened = performance.now();
    this.root.innerHTML = `
      <div class="dp-box">
        <h2>RECLAMAÇÃO</h2>
        <p class="dp-desc">${playerLabel(p)} (${TEAMS[p.team].name}) protesta contra a falta marcada.</p>
        <p class="dp-evidence">Evidências: ${d.evidence.join(' · ')}</p>
        <div class="dp-row dp-center">
          <button class="dp-btn" data-choice="ignore">Seguir o jogo [I]</button>
          <button class="dp-btn" data-choice="warning">Advertência verbal [A]</button>
          <button class="dp-btn yellow" data-choice="yellow">Cartão amarelo [1]</button>
        </div>
      </div>`;
    this.root.classList.add('open');
  }

  choose(choice) {
    this.close();
    this.onChoose(choice);
  }

  close() {
    this.open_ = false;
    this.root.classList.remove('open');
  }

  destroy() {
    window.removeEventListener('keydown', this.onKey, true);
    this.root.remove();
  }
}
