// Ilustrações dos exercícios do centro de treinamento: SVG pixel art desenhado por código (sem arquivos de imagem).
const W = 320;
const H = 150;


const RED = '#d9534f';
const BLUE = '#4a86d9';

const rect = (x, y, w, h, fill, extra = '') => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" ${extra}/>`;
const text = (x, y, s, fill = '#fff', size = 8, anchor = 'middle') => `<text x="${x}" y="${y}" fill="${fill}" font-size="${size}" font-family="monospace" font-weight="bold" text-anchor="${anchor}">${s}</text>`;
const line = (x1, y1, x2, y2, stroke, w = 1, dash = '') => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${stroke}" stroke-width="${w}" ${dash ? `stroke-dasharray="${dash}"` : ''}/>`;

// Jogador: corpo de 6x9 px com cabeça, como na partida.
const player = (x, y, fill, label = '') => `${rect(x - 3, y - 4, 6, 9, fill, 'stroke="#111" stroke-width="1"')}${rect(x - 2, y - 7, 4, 3, '#f0c8a0')}${label ? text(x, y + 16, label, '#fff', 7) : ''}`;
const ball = (x, y) => `<circle cx="${x}" cy="${y}" r="2.5" fill="#fff" stroke="#111" stroke-width="1"/>`;
const arrow = (x1, y1, x2, y2, stroke = '#ffe066') => {
  const a = Math.atan2(y2 - y1, x2 - x1);
  const hx = (d) => x2 - 6 * Math.cos(a + d);
  const hy = (d) => y2 - 6 * Math.sin(a + d);
  return `${line(x1, y1, x2, y2, stroke, 2)}${line(x2, y2, hx(0.5), hy(0.5), stroke, 2)}${line(x2, y2, hx(-0.5), hy(-0.5), stroke, 2)}`;
};

function pitch(extra = '') {
  const stripes = Array.from({ length: 8 }, (_, i) => rect(i * 40, 0, 40, H, i % 2 ? '#3f8f4a' : '#46985a')).join('');
  return `${stripes}${rect(2, 2, W - 4, H - 4, 'none', 'stroke="#e8f4e8" stroke-width="1"')}${line(W / 2, 2, W / 2, H - 2, '#e8f4e8', 1)}${extra}`;
}

function foulScene(sc) {
  const d = 1; // ataque para a direita
  const cx = 130;
  const cy = 75;
  const tx = sc.fromBehind ? cx - 16 : sc.hand ? cx + 40 : cx + 14;
  const parts = [];
  if (sc.inArea) parts.push(rect(W - 90, 30, 88, 90, 'none', 'stroke="#e8f4e8" stroke-width="1"'), rect(W - 40, 55, 38, 40, 'none', 'stroke="#e8f4e8" stroke-width="1"'));
  const ballX = sc.inArea ? W - 100 : cx;
  const carX = sc.inArea ? W - 100 : cx;
  parts.push(player(carX, cy, BLUE, 'atacante'));
  parts.push(ball(carX + 6, cy + 5));
  parts.push(arrow(carX + 10, cy - 14, carX + 46, cy - 14));
  if (sc.hand) {
    parts.push(player(carX + 34, cy + 2, RED, 'defensor'));
    parts.push(line(carX + 37, cy - 2, carX + 44, cy - 8, '#f0c8a0', 2));
    parts.push(arrow(carX + 10, cy + 22, carX + 32, cy + 8, '#fff'));
  } else if (sc.dive) {
    parts.push(player(tx + 30, cy + 4, RED, 'defensor'));
    parts.push(rect(carX - 8, cy + 6, 16, 5, BLUE, 'transform="rotate(0)"'));
    if (sc.contact) parts.push(text(carX + 18, cy + 4, '·', '#ffe066', 14));
  } else {
    parts.push(player(tx, cy + 2, RED, 'defensor'));
    if (sc.contact) parts.push(text(Math.min(carX, tx) + Math.abs(tx - carX) / 2, cy - 4, '✱', '#ffe066', 12));
    parts.push(arrow(tx - (sc.fromBehind ? 12 : -12), cy + 18, tx - (sc.fromBehind ? -4 : 4), cy + 6, '#fff'));
  }
  if (sc.tactical) parts.push(text(W - 34, 20, 'GOL', '#fff', 8), rect(W - 8, 55, 6, 40, '#e8f4e8'));
  return parts.join('');
}

function offsideScene(sc) {
  const parts = [];
  parts.push(line(sc.half, 2, sc.half, H - 2, '#e8f4e8', 1, '4 3'), text(sc.half, 12, 'meio', '#e8f4e8', 6));
  parts.push(line(sc.line, 8, sc.line, H - 8, '#ffe066', 1, '5 3'), text(sc.line, 22, 'penúltimo defensor', '#ffe066', 6));
  for (const p of sc.players) parts.push(player(p.x, p.y, p.team === 'att' ? BLUE : RED, p.label === 'G' ? 'gol' : ''));
  const passer = sc.players.find((p) => p.label === 'P');
  const att = sc.players.find((p) => p.label === 'A');
  parts.push(ball(passer.x + 6, passer.y + 6), arrow(passer.x + 8, passer.y - 8, Math.max(passer.x + 20, att.x - 6), att.y - 8, '#fff'));
  parts.push(text(att.x, att.y - 12, 'A', '#fff', 9));
  parts.push(text(passer.x, passer.y - 12, 'P', '#fff', 9));
  return parts.join('');
}

function positionScene(sc) {
  const parts = [];
  parts.push(player(sc.ball.x, sc.ball.y, BLUE, 'bola'), ball(sc.ball.x + 6, sc.ball.y + 5));
  parts.push(arrow(sc.ball.x + sc.dir * 10, sc.ball.y, sc.ball.x + sc.dir * 50, sc.ball.y));
  parts.push(player(sc.ball.x + sc.dir * 26, sc.ball.y - 14, RED), player(sc.ball.x + sc.dir * 40, sc.ball.y + 16, BLUE));
  for (const s of sc.spots) parts.push(`<circle cx="${s.x}" cy="${s.y}" r="9" fill="#111" fill-opacity="0.75" stroke="#fff" stroke-width="1"/>${text(s.x, s.y + 3, s.letter, '#fff', 10)}`);
  return parts.join('');
}

export function sceneSvg(scene) {
  if (!scene) return '';
  const body = scene.kind === 'foul' ? foulScene(scene) : scene.kind === 'offside' ? offsideScene(scene) : positionScene(scene);
  return `<svg class="tr-scene" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Ilustração do lance" shape-rendering="crispEdges">${pitch()}${body}</svg>`;
}
