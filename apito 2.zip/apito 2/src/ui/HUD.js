import { GAME_WIDTH, GAME_HEIGHT, TEAMS } from '../config.js';
import { tensionLabel, crowdLabel, TENSION_HIGH, TENSION_CALM } from '../systems/MatchMood.js';

const STYLE = {
  fontFamily: 'monospace',
  fontSize: '8px',
  color: '#ffffff',
  stroke: '#000000',
  strokeThickness: 2,
};
const COLORS = { good: '#8dff8d', bad: '#ff8d8d', info: '#ffffff' };
const MESSAGE_MS = 2200;
const DEPTH = 10000;

export default class HUD {
  constructor(scene) {
    this.scene = scene;
    this.queue = [];
    this.messageTimer = 0;

    this.bar = scene.add
      .rectangle(0, 0, GAME_WIDTH, 24, 0x000000, 0.5)
      .setOrigin(0, 0)
      .setScrollFactor(0)
      .setDepth(DEPTH - 1);
    this.homeName = scene.add
      .text(GAME_WIDTH / 2 - 26, 3, TEAMS.home.name.toUpperCase(), { ...STYLE, color: '#ff9a9a' })
      .setOrigin(1, 0)
      .setScrollFactor(0)
      .setDepth(DEPTH);
    this.awayName = scene.add
      .text(GAME_WIDTH / 2 + 26, 3, TEAMS.away.name.toUpperCase(), { ...STYLE, color: '#9ac0ff' })
      .setOrigin(0, 0)
      .setScrollFactor(0)
      .setDepth(DEPTH);
    this.scoreText = scene.add
      .text(GAME_WIDTH / 2, 1, '0 - 0', { ...STYLE, fontSize: '12px' })
      .setOrigin(0.5, 0)
      .setScrollFactor(0)
      .setDepth(DEPTH);
    this.clockText = scene.add
      .text(GAME_WIDTH / 2, 14, '00:00  1º TEMPO', { ...STYLE, fontSize: '7px', color: '#d8e2f0' })
      .setOrigin(0.5, 0)
      .setScrollFactor(0)
      .setDepth(DEPTH);

    // Clima da partida: tensão e humor da torcida (informação para o árbitro ler o contexto).
    this.moodText = scene.add
      .text(4, 3, '', { ...STYLE, fontSize: '6px', align: 'left' })
      .setOrigin(0, 0)
      .setScrollFactor(0)
      .setDepth(DEPTH);

    this.conditionsText = '';

    // Aviso grande no centro (gol, intervalo, fim de jogo, reinícios).
    this.banner = scene.add
      .text(GAME_WIDTH / 2, 62, '', { ...STYLE, fontSize: '16px', align: 'center', strokeThickness: 3 })
      .setOrigin(0.5)
      .setScrollFactor(0)
      .setDepth(DEPTH + 2)
      .setVisible(false);
    this.bannerTimer = 0;

    this.controlsHint = scene.add
      .text(GAME_WIDTH / 2, GAME_HEIGHT - 3, 'Espaço apito/anula gol · V vantagem · R VAR · N som · Esc pausa', STYLE)
      .setOrigin(0.5, 1)
      .setScrollFactor(0)
      .setDepth(DEPTH)
      .setAlpha(0.6);

    this.prompt = scene.add
      .text(GAME_WIDTH / 2, GAME_HEIGHT - 16, '', { ...STYLE, color: '#ffe066' })
      .setOrigin(0.5, 1)
      .setScrollFactor(0)
      .setDepth(DEPTH);

    this.message = scene.add
      .text(GAME_WIDTH / 2, 130, '', { ...STYLE, align: 'center', wordWrap: { width: 300 } })
      .setOrigin(0.5, 0)
      .setScrollFactor(0)
      .setDepth(DEPTH)
      .setVisible(false);

    this.pauseText = scene.add
      .text(GAME_WIDTH / 2, GAME_HEIGHT / 2, 'PAUSA\nEsc continuar · M sair para o menu', { ...STYLE, fontSize: '12px', align: 'center' })
      .setOrigin(0.5)
      .setScrollFactor(0)
      .setDepth(DEPTH + 1)
      .setVisible(false);

    // Botão do VAR (canto superior direito): clicável com o mouse ou pela tecla R.
    this.varBtn = scene.add
      .rectangle(GAME_WIDTH - 3, 3, 40, 14, 0x1c2433)
      .setOrigin(1, 0)
      .setStrokeStyle(1, 0x8fa3c7)
      .setScrollFactor(0)
      .setDepth(DEPTH)
      .setInteractive({ useHandCursor: true });
    this.varBtnText = scene.add
      .text(GAME_WIDTH - 23, 10, 'VAR [R]', { ...STYLE, fontSize: '7px', strokeThickness: 1 })
      .setOrigin(0.5)
      .setScrollFactor(0)
      .setDepth(DEPTH + 1);
    this.varBtn.on('pointerdown', () => scene.requestVar());
    this.varAvailable = true;

    this.reviewing = false;

    scene.events.on('var-rollback', () => this.hideBanner());
    scene.events.on('var-decision', ({ kind }) => {
      if (kind === 'change') {
        this.showBanner('VAR\nDECISÃO ALTERADA', 2200, '#ffe066', 12);
        this.enqueue('info', 'VAR: decisão alterada');
      }
      else this.enqueue('info', 'VAR: decisão mantida');
    });

    scene.events.on('feedback', ({ kind, text }) => this.enqueue(kind, text));
    scene.events.on('goal', ({ team }) => this.showBanner(`GOL!\n${TEAMS[team].name}`, 2600, '#ffe066'));
    scene.events.on('goal-disallowed', () => {
      this.hideBanner();
      this.showBanner('GOL ANULADO', 2200, '#ff8a7a');
    });
    scene.events.on('late-drama', () => this.showBanner('MINUTOS FINAIS\nJogo decidido nos detalhes', 2400, '#ffb35a', 12));
    scene.events.on('bench-protest', ({ team }) => this.enqueue('info', `Banco do ${TEAMS[team].name} reclama (B: quarto árbitro)`));
    scene.events.on('dissent-open', ({ player }) => this.enqueue('info', `#${player.number} ${player.name} reclama!`));
    scene.events.on('crew-flag', ({ name }) => this.enqueue('info', `Bandeira levantada: ${name} sinaliza impedimento`));
    this.lastRestartToast = 0;
    scene.events.on('setpiece-start', ({ type, team }) => {
      const label = { throw_in: 'lateral', corner: 'escanteio', goal_kick: 'tiro de meta' }[type];
      const now = performance.now();
      if (!label || now - this.lastRestartToast < 12000) return;
      this.lastRestartToast = now;
      this.enqueue('info', `Assistente sinaliza ${label} para o ${TEAMS[team].name}`);
    });
    scene.events.on('crowd-pressure', () => this.enqueue('info', 'A torcida pressiona o árbitro'));
    scene.events.on('halftime', () => this.showBanner('INTERVALO\nEspaço: iniciar o 2º tempo', Infinity, '#ffffff'));
    scene.events.on('fulltime', () => this.showBanner('FIM DE JOGO', Infinity, '#ffffff'));
    scene.events.on('setpiece-start', ({ type }) => {
      this.hideBanner();
      const labels = { kickoff: 'Pontapé inicial', throw_in: 'Lateral', corner: 'Escanteio', goal_kick: 'Tiro de meta' };
      if (labels[type]) this.showBanner(labels[type], 1200, '#ffffff', 10);
    });
  }

  enqueue(kind, text) {
    if (this.queue.length >= 3) this.queue.shift();
    this.queue.push({ kind, text });
  }

  showBanner(text, ms, color = '#ffffff', size = 16) {
    this.banner.setText(text).setColor(color).setFontSize(size).setVisible(true);
    this.bannerTimer = ms;
  }

  hideBanner() {
    this.banner.setVisible(false);
    this.bannerTimer = 0;
  }

  setPaused(paused) {
    this.pauseText.setVisible(paused);
  }

  // Durante a revisão do VAR a câmera usa zoom, que também afetaria o HUD (fixo na tela): então ele some e o
  // painel do VAR mostra relógio e placar da reprodução. Ao voltar, o que ainda vale reaparece.
  setReviewMode(on) {
    this.reviewing = on;
    for (const o of [this.bar, this.homeName, this.awayName, this.scoreText, this.clockText, this.moodText, this.varBtn, this.varBtnText, this.prompt, this.controlsHint]) o.setVisible(!on);
    this.message.setVisible(!on && this.messageTimer > 0);
    this.banner.setVisible(!on && this.bannerTimer > 0);
  }

  setVarAvailable(ok) {
    if (this.varAvailable === ok) return;
    this.varAvailable = ok;
    this.varBtn.setAlpha(ok ? 1 : 0.4);
    this.varBtnText.setAlpha(ok ? 1 : 0.4);
  }

  setConditions(cond) {
    this.conditionsText = cond ? cond.text : '';
  }

  update(delta, promptText, sim, mood) {
    if (this.prompt.text !== promptText) this.prompt.setText(promptText);
    if (mood) {
      const text = `Clima: ${tensionLabel(mood.tension)}\nTorcida: ${crowdLabel(mood.crowd)}${this.conditionsText ? `\n${this.conditionsText}` : ''}`;
      if (this.moodText.text !== text) {
        this.moodText.setText(text);
        this.moodText.setColor(mood.tension >= TENSION_HIGH ? '#ff9a8a' : mood.tension >= TENSION_CALM ? '#ffe08a' : '#b8e8b8');
      }
    }

    if (sim) {
      const score = `${sim.score.home} - ${sim.score.away}`;
      if (this.scoreText.text !== score) this.scoreText.setText(score);
      const clock = sim.getClock();
      const label = `${clock.text}  ${clock.period}º TEMPO${clock.added ? ' +' : ''}`;
      if (this.clockText.text !== label) this.clockText.setText(label);
    }

    if (this.bannerTimer > 0 && this.bannerTimer !== Infinity) {
      this.bannerTimer -= delta;
      if (this.bannerTimer <= 0) this.banner.setVisible(false);
    }


    if (this.messageTimer > 0) {
      this.messageTimer -= delta;
      if (this.messageTimer <= 0) this.message.setVisible(false);
    }
    if (this.messageTimer <= 0 && this.queue.length) {
      const { kind, text } = this.queue.shift();
      this.message.setText(text).setColor(COLORS[kind] || COLORS.info).setVisible(true);
      this.messageTimer = MESSAGE_MS;
    }
  }
}