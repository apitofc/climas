export const GAME_WIDTH = 320;
export const GAME_HEIGHT = 180;

export const FIELD = {
  margin: 24,
  width: 560,
  height: 320,
  line: 2,
  goalDepth: 10,
  goalWidth: 56,
  penaltyDepth: 56,
  penaltyWidth: 140,
  boxDepth: 22,
  boxWidth: 76,
  centerRadius: 36,
  penaltySpot: 40,
};

export const WORLD_WIDTH = FIELD.width + FIELD.margin * 2;
export const WORLD_HEIGHT = FIELD.height + FIELD.margin * 2;

export const COLORS = {
  grassA: 0x3f8f3a,
  grassB: 0x46993f,
  line: 0xf2f2e8,
  goal: 0xdadada,
  net: 0x9aa4a8,
};

export const FIELD_RECT = {
  left: FIELD.margin,
  top: FIELD.margin,
  right: FIELD.margin + FIELD.width,
  bottom: FIELD.margin + FIELD.height,
  cx: FIELD.margin + FIELD.width / 2,
  cy: FIELD.margin + FIELD.height / 2,
};

export const TEAMS = {
  home: { id: 'home', name: 'Vermelhos', attackDir: 1, texture: 'player_home', gkTexture: 'gk_home' },
  away: { id: 'away', name: 'Azuis', attackDir: -1, texture: 'player_away', gkTexture: 'gk_away' },
};

export function applyClubs(home, away) {
  TEAMS.home.name = home.name;
  TEAMS.away.name = away.name;
}

const params = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;

// Opções de duração (tempo real, somando os dois tempos). O relógio exibido vai sempre de 00:00 a 90:00;
// a opção só muda a velocidade desse relógio. O relógio da partida (`ms`) para nas paradas de jogo
// (apito, decisão, gol, intervalo), então o tempo real total fica dentro da faixa anunciada em `minutes`.
export const DURATIONS = [
  { id: 'quick', label: 'Rápida', minutes: '2 a 3', ms: 135000 },
  { id: 'standard', label: 'Padrão', minutes: '4 a 5', ms: 245000 },
  { id: 'long', label: 'Longa', minutes: '6 a 7', ms: 365000 },
];
export const DEFAULT_DURATION = 'standard';
// Ids de versões anteriores (salvos em preferências ou no histórico da carreira) apontam para a opção equivalente.
const LEGACY_DURATION_IDS = { short: 'quick' };
export const getDuration = (id) => DURATIONS.find((d) => d.id === (LEGACY_DURATION_IDS[id] || id)) || DURATIONS.find((d) => d.id === DEFAULT_DURATION);

// Para testes: ?duration=60 (segundos) na URL sobrepõe a opção escolhida.
export function matchDurationMs(id) {
  const override = Number(params && params.get('duration'));
  return override > 0 ? override * 1000 : getDuration(id).ms;
}

export const CUSTOM_EVENTS = [
  'incident', 'incident-registered', 'whistle', 'decision-needed', 'card', 'advantage', 'decision-result',
  'feedback', 'player-touch', 'referee-bump', 'play-stopped', 'play-resumed', 'setpiece-start',
  'player-sent-off', 'goal', 'goal-disallowed', 'goal-decision', 'late-drama', 'bench-protest', 'crowd-pressure', 'crew-flag', 'crew-consult', 'crew-bench', 'dissent-open', 'dissent-result', 'halftime', 'fulltime',
  'var-open', 'var-close', 'var-rollback', 'var-decision',
];
