// Destaques da partida para as redes sociais (prints) e rixa entre jogadores. Funções puras, sem Phaser.
//
// Os "prints" são capturas reais da tela do jogo, tiradas pela MatchScene em momentos marcantes da partida que o jogador
// apita. Aqui ficam só as regras: quais momentos valem um print, limites de quantidade e de tamanho, e a conferência
// final (um gol anulado pelo VAR ou um lance que sumiu da súmula não vira publicação).
import { describeEntry } from './RefereeGrading.js';

export const MAX_SHOTS = 4; // prints por partida
export const MIN_GAP_MS = 20000; // tempo de jogo entre dois prints (os mais importantes furam a fila)
export const MAX_IMAGE_CHARS = 60000; // tamanho máximo de cada imagem (texto base64)
export const MAX_STORED_IMAGES = 14; // imagens guardadas na carreira (as mais antigas perdem a imagem, o texto fica)

const PRIORITY = { red: 5, disallowed: 5, goal: 4, var: 4, controversy: 3, penalty: 3 };

export const isShotImage = (u) => typeof u === 'string' && u.startsWith('data:image/jpeg;base64,') && u.length <= MAX_IMAGE_CHARS;

export class HighlightPlanner {
  constructor() {
    this.shots = [];
    this.lastTime = -Infinity;
  }

  // Reserva um print para o momento. Devolve o registro (a imagem chega depois) ou null se não vale.
  reserve(meta, time) {
    const priority = PRIORITY[meta.kind] ?? 0;
    if (!priority || this.shots.length >= MAX_SHOTS) return null;
    if (this.shots.length >= 2 && priority < 4) return null; // depois de 2 prints, só os mais importantes
    if (time - this.lastTime < MIN_GAP_MS && priority < 5) return null;
    this.lastTime = time;
    const shot = { ...meta, priority, image: null };
    this.shots.push(shot);
    return shot;
  }
}

// Um erro que rende discussão: falta real ignorada em lance sério, dois erros no mesmo lance ou erro de cartão pesado.
export function isControversial(entry) {
  if (!entry || !entry.errors || !entry.errors.length) return false;
  if (entry.type === 'unnecessary_whistle' || entry.type === 'goal_check') return false;
  const serious = ['serious_foul', 'penalty'].includes(entry.type);
  return entry.errors.length >= 2 || (serious && entry.errors.some((c) => c === 'FOUL_MISSED' || c === 'FOUL_WRONG' || c === 'CARD_WRONG_PLAYER'));
}

// Confere os prints no fim do jogo contra a súmula, o placar final e as revisões do VAR. Devolve só os prints válidos,
// já com os dados finais do lance (a revisão do VAR pode ter mudado a decisão depois do print).
export function finalizeShots(shots, log, score, varReviews = []) {
  const goalsLeft = { home: score.home, away: score.away };
  const out = [];
  const goals = shots.filter((s) => s.kind === 'goal' && isShotImage(s.image));
  const keepGoals = new Set();
  for (const team of ['home', 'away']) {
    const mine = goals.filter((s) => s.team === team);
    const n = goalsLeft[team];
    (n > 0 ? mine.slice(-n) : []).forEach((s) => keepGoals.add(s)); // fica o(s) gol(s) mais recente(s) que ainda valem no placar final
  }
  for (const s of shots) {
    if (!isShotImage(s.image)) continue;
    const base = { kind: s.kind, clock: s.clock, period: s.period, team: s.team || null, score: s.score, image: s.image };
    if (s.kind === 'goal') {
      if (keepGoals.has(s)) out.push({ ...base, scorer: s.scorer || null });
      continue;
    }
    if (s.kind === 'red') {
      out.push({ ...base, player: s.player || null });
      continue;
    }
    if (s.kind === 'disallowed') {
      const e = [...log].reverse().find((x) => x.type === 'goal_check' && x.actual && x.actual.foulCalled);
      out.push({ ...base, correct: e ? !!e.correct : null });
      continue;
    }
    if (s.kind === 'var') {
      const r = [...varReviews].reverse().find((x) => x.incidentId === s.incidentId);
      if (r) out.push({ ...base, label: r.label, varKind: r.kind, correct: r.finalCorrect ?? null });
      continue;
    }
    // controversy / penalty
    const e = [...log].reverse().find((x) => x.incidentId === s.incidentId);
    if (!e) continue;
    const d = describeEntry(e);
    out.push({ ...base, label: d.label, correct: !!e.correct, errors: d.errors, favored: e.favored || null });
  }
  return out;
}

// Rixa: dois jogadores de times diferentes que se envolveram em 2 ou mais lances da partida (falta, simulação, disputa).
export function findFeud(log) {
  const pairs = new Map();
  for (const e of log) {
    if (!e.offender || !e.victim || ['unnecessary_whistle', 'goal_check'].includes(e.type)) continue;
    if (e.offender.team === e.victim.team || e.offender.name === 'equipe' || e.victim.name === 'equipe') continue;
    const a = e.offender.team === 'home' ? e.offender : e.victim;
    const b = e.offender.team === 'home' ? e.victim : e.offender;
    const key = `${a.number}-${b.number}`;
    const cur = pairs.get(key) || { a: { team: a.team, number: a.number, name: a.name }, b: { team: b.team, number: b.number, name: b.name }, count: 0, labels: [], cards: 0 };
    cur.count += 1;
    const label = describeEntry(e).label.toLowerCase();
    if (!cur.labels.includes(label)) cur.labels.push(label);
    cur.cards += (e.actual.cards || []).filter((c) => c.color !== 'warning').length;
    pairs.set(key, cur);
  }
  const best = [...pairs.values()].filter((p) => p.count >= 2).sort((x, y) => y.count - x.count || y.cards - x.cards)[0];
  return best || null;
}

// Mantém só as imagens mais recentes nas publicações (as antigas ficam sem imagem, o texto continua).
export function trimImages(career, max = MAX_STORED_IMAGES) {
  let kept = 0;
  let trimmed = 0;
  for (const p of career.social || []) {
    if (!p.image) continue;
    if (!isShotImage(p.image.src)) {
      delete p.image;
      trimmed++;
    } else if (++kept > max) {
      delete p.image;
      trimmed++;
    }
  }
  return trimmed;
}
