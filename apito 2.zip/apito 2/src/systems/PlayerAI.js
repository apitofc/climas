import { FIELD, FIELD_RECT } from '../config.js';

const L = FIELD_RECT;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);

export const ownGoalX = (d) => (d > 0 ? L.left : L.right);
export const opponentGoalX = (d) => (d > 0 ? L.right : L.left);

export function inOwnPenaltyArea(d, x, y) {
  const depth = (x - ownGoalX(d)) * d;
  return depth >= -2 && depth <= FIELD.penaltyDepth && Math.abs(y - L.cy) <= FIELD.penaltyWidth / 2;
}

const ADVANCE = { GK: 0, DEF: 0.06, MID: 0.1, FWD: 0.14 };

export function getTarget(p, ctx) {
  const d = p.attackDir;
  const ball = ctx.ball;

  if (p.role === 'GK') {
    if (ctx.chaser[p.team] === p) {
      return { x: ball.x + ball.vx * 0.2, y: ball.y + ball.vy * 0.2, speed: 1 };
    }
    const half = FIELD.goalWidth * 0.55;
    return {
      x: ownGoalX(d) + d * 10,
      y: clamp(ball.y, L.cy - half, L.cy + half),
      speed: 0.7,
    };
  }

  if (ctx.chaser[p.team] === p) {
    return {
      x: clamp(ball.x + ball.vx * 0.3, L.left + 2, L.right - 2),
      y: clamp(ball.y + ball.vy * 0.3, L.top + 2, L.bottom - 2),
      speed: 1,
    };
  }

  const ownX = ownGoalX(d);
  const ballNx = clamp(((ball.x - ownX) * d) / FIELD.width, 0, 1);
  const ballNy = clamp((ball.y - L.top) / FIELD.height, 0, 1);
  const state = ctx.possessionTeam === null ? 'neutral' : ctx.possessionTeam === p.team ? 'attack' : 'defend';

  const follow = state === 'attack' ? 0.4 : state === 'defend' ? 0.25 : 0.3;
  const lateral = state === 'defend' ? 0.45 : 0.35;
  let shift = 0;
  if (state === 'attack') shift = ADVANCE[p.role];
  else if (state === 'defend') shift = p.role === 'FWD' ? 0 : -0.04;

  // Expulsão: quem ficou com um a menos recua e joga mais compacto; o adversário sobe um pouco.
  const md = ctx.manDown || { home: 0, away: 0 };
  const mine = md[p.team] || 0;
  const theirs = md[p.team === 'home' ? 'away' : 'home'] || 0;
  if (mine) shift = shift * 0.5 - 0.04 * Math.min(mine, 2);
  else if (theirs && state === 'attack') shift += 0.03 * Math.min(theirs, 2);

  const tnx = clamp(p.nx + (ballNx - p.nx) * follow + shift, 0.06, 0.92);
  const tny = clamp(p.ny + (ballNy - p.ny) * lateral, 0.06, 0.94);
  let tx = ownX + d * tnx * FIELD.width;
  let ty = L.top + tny * FIELD.height;

  for (const o of ctx.players) {
    if (o === p || o.team !== p.team || o.role === 'GK') continue;
    const dd = dist(p.x, p.y, o.x, o.y);
    if (dd < 24 && dd > 0.01) {
      tx += ((p.x - o.x) / dd) * (24 - dd) * 0.8;
      ty += ((p.y - o.y) / dd) * (24 - dd) * 0.8;
    }
  }

  // Atacantes sobem até a linha do penúltimo defensor; alguns ficam um pouco atrás, outros arriscam passar dela.
  if (state === 'attack' && p.role === 'FWD') {
    const depths = ctx.players
      .filter((o) => o.team !== p.team)
      .map((o) => o.x * d)
      .sort((a, b) => b - a);
    if (depths.length) {
      const line = depths.length >= 2 ? depths[1] : depths[0];
      const wanted = line + (p.lineBias || 0);
      const limit = (d > 0 ? L.right : L.left) * d - 12;
      const depth = Math.min(wanted, limit);
      if (depth > tx * d) tx = depth * d;
    }
  }

  tx = clamp(tx, L.left + 3, L.right - 3);
  ty = clamp(ty, L.top + 3, L.bottom - 3);
  const dd = dist(p.x, p.y, tx, ty);
  return { x: tx, y: ty, speed: clamp(dd / 24, 0, 1) * 0.85 };
}

function withError(action, ctx, maxAngle) {
  const a = (ctx.rng.frac() * 2 - 1) * maxAngle;
  const cos = Math.cos(a);
  const sin = Math.sin(a);
  return { ...action, vx: action.vx * cos - action.vy * sin, vy: action.vx * sin + action.vy * cos };
}

function segmentDistance(px, py, ax, ay, bx, by) {
  const abx = bx - ax;
  const aby = by - ay;
  const len2 = abx * abx + aby * aby;
  if (len2 === 0) return { d: dist(px, py, ax, ay), t: 0 };
  const t = clamp(((px - ax) * abx + (py - ay) * aby) / len2, 0, 1);
  return { d: dist(px, py, ax + abx * t, ay + aby * t), t };
}

function nearestOpponentDistance(p, ctx, x, y) {
  let best = Infinity;
  for (const o of ctx.players) {
    if (o.team === p.team) continue;
    best = Math.min(best, dist(x, y, o.x, o.y - 2));
  }
  return best;
}

// Posição de impedimento no momento do passe: atacante na metade adversária, à frente da bola e do penúltimo
// defensor (o goleiro conta como defensor). `close` = legal, mas a menos de 7 px da linha.
export function offsideInfo(passer, players, ballX) {
  const d = passer.attackDir;
  const defenders = players.filter((o) => o.team !== passer.team).sort((a, b) => b.x * d - a.x * d);
  if (!defenders.length) return { line: null, lineDefender: null, offside: [], close: [] };

  const lineDefender = defenders.length >= 2 ? defenders[1] : defenders[0];
  const limit = Math.max(lineDefender.x * d, ballX * d);
  const half = L.cx * d;
  const offside = [];
  const close = [];
  for (const a of players) {
    if (a.team !== passer.team || a === passer) continue;
    const depth = a.x * d;
    if (depth <= half) continue;
    const margin = depth - limit;
    if (margin > 1) offside.push({ player: a, margin });
    else if (margin > -7) close.push({ player: a, margin });
  }
  return { line: lineDefender.x, lineDefender, offside, close };
}

export function choosePass(p, ctx, { relaxed = false, minDist = 40, maxDist = 210 } = {}) {
  const d = p.attackDir;
  const px = p.x;
  const py = p.y - 2;
  let best = null;
  const offsideSet = new Set(offsideInfo(p, ctx.players, px).offside.map((e) => e.player));

  for (const t of ctx.players) {
    if (t === p || t.team !== p.team) continue;
    if (ctx.ball.lastPasser === t && ctx.now - ctx.ball.lastPassTime < 3000) continue;
    // Os times costumam evitar passar para quem está em impedimento, mas nem sempre acertam.
    if (offsideSet.has(t) && ctx.rng.frac() < 0.55) continue;

    const ty = t.y - 2;
    const distance = dist(px, py, t.x, ty);
    if (distance < minDist || distance > maxDist) continue;

    const forward = (t.x - px) * d;
    if (forward < (relaxed ? -50 : -5)) continue;

    const openness = nearestOpponentDistance(p, ctx, t.x, ty);
    // Atacantes na frente recebem em espaços mais apertados (bolas em profundidade).
    if (openness < (t.role === 'FWD' ? 14 : 24)) continue;

    let blocked = false;
    for (const o of ctx.players) {
      if (o.team === p.team) continue;
      const seg = segmentDistance(o.x, o.y - 2, px, py, t.x, ty);
      if (seg.d < (t.role === 'FWD' ? 8 : 12) && seg.t > 0.05 && seg.t < 0.95) {
        blocked = true;
        break;
      }
    }
    if (blocked) continue;

    const score = forward + openness * 0.6 - distance * 0.15 + (t.role === 'FWD' ? 12 : 0) - (t.role === 'GK' ? 100 : 0);
    if (!best || score > best.score) best = { receiver: t, score };
  }
  return best;
}

function passAction(p, receiver, ctx, scale = 1) {
  const px = p.x;
  const py = p.y - 2;
  const tx = receiver.x + receiver.vx * 0.35;
  const ty = receiver.y - 2 + receiver.vy * 0.35;
  const distance = dist(px, py, tx, ty) || 1;
  const speed = clamp(distance * 1.15 + 45, 100, 255) * scale;
  const action = { type: 'pass', vx: ((tx - px) / distance) * speed, vy: ((ty - py) / distance) * speed, receiver };
  return withError(action, ctx, 0.05 + distance * 0.0006);
}

export function decideTouch(p, ctx) {
  const d = p.attackDir;
  const px = p.x;
  const py = p.y - 2;
  const goalX = opponentGoalX(d);
  const goalY = L.cy;

  if (p.role === 'GK') {
    if (Math.hypot(ctx.ball.vx, ctx.ball.vy) > 120 && ctx.rng.frac() < 0.6) {
      const side = py < L.cy ? L.top : L.bottom;
      const tx = ownGoalX(d) - d * 10;
      const dd = dist(px, py, tx, side) || 1;
      return { type: 'clear', vx: ((tx - px) / dd) * 150, vy: ((side - py) / dd) * 150 };
    }
    const option = choosePass(p, ctx, { relaxed: true, minDist: 60, maxDist: 260 });
    if (option) {
      const a = passAction(p, option.receiver, ctx);
      return { ...a, type: 'clear' };
    }
    const ty = py < L.cy ? L.cy + 70 : L.cy - 70;
    const tx = L.cx;
    const dd = dist(px, py, tx, ty) || 1;
    return withError({ type: 'clear', vx: ((tx - px) / dd) * 200, vy: ((ty - py) / dd) * 200 }, ctx, 0.35);
  }

  const dGoal = dist(px, py, goalX, goalY);
  if (dGoal < 165 && (p.role !== 'DEF' || dGoal < 110)) {
    const ty = goalY + (ctx.rng.frac() * 2 - 1) * FIELD.goalWidth * 0.42;
    const dd = dist(px, py, goalX, ty) || 1;
    return withError({ type: 'shoot', vx: ((goalX - px) / dd) * 235, vy: ((ty - py) / dd) * 235 }, ctx, 0.2);
  }

  const pressured = nearestOpponentDistance(p, ctx, px, py) < 26;

  const ballSpeed = Math.hypot(ctx.ball.vx, ctx.ball.vy);
  const depthOwn = (px - ownGoalX(d)) * d;
  const inBox = inOwnPenaltyArea(d, px, py);
  if (p.role !== 'GK' && depthOwn < FIELD.width * 0.3 && (pressured || (inBox && ballSpeed > 120))) {
    const side = py < L.cy ? L.top : L.bottom;
    const behind = inBox && ctx.rng.frac() < 0.3;
    const tx = behind ? ownGoalX(d) - d * 10 : px + d * 70;
    const dd = dist(px, py, tx, side) || 1;
    return withError({ type: 'clear', vx: ((tx - px) / dd) * 170, vy: ((side - py) / dd) * 170 }, ctx, 0.15);
  }

  if (pressured || p.holdTimer > 1100) {
    const option = choosePass(p, ctx, { relaxed: pressured });
    if (option) return passAction(p, option.receiver, ctx);
  }

  // Bola em profundidade: às vezes o jogador lança para um atacante na linha do último defensor ou além dela.
  // É daqui que saem os impedimentos e as posições legais "no limite" que o árbitro precisa julgar.
  if (p.holdTimer > 250) {
    const info = offsideInfo(p, ctx.players, px);
    const runners = [...info.offside, ...info.close].filter((e) => {
      const dd = dist(px, py, e.player.x, e.player.y - 2);
      return dd >= 40 && dd <= 230;
    });
    if (runners.length && ctx.rng.frac() < 0.6) {
      runners.sort((a, b) => b.margin - a.margin);
      return passAction(p, runners[0].player, ctx);
    }
  }

  let dx = goalX - px;
  let dy = goalY - py;
  const dl = Math.hypot(dx, dy) || 1;
  dx /= dl;
  dy /= dl;

  const perpX = -dy;
  const perpY = dx;
  let sx = 0;
  let sy = 0;
  for (const o of ctx.players) {
    if (o.team === p.team) continue;
    const ox = o.x - px;
    const oy = o.y - 2 - py;
    const od = Math.hypot(ox, oy);
    if (od > 0 && od < 38 && (ox * dx + oy * dy) / od > 0.2) {
      const s = ox * perpX + oy * perpY;
      const sign = s >= 0 ? -1 : 1;
      const w = ((38 - od) / 38) * 1.2;
      sx += perpX * sign * w;
      sy += perpY * sign * w;
    }
  }
  dx += sx;
  dy += sy;
  if (py < L.top + 14) dy += 0.8;
  if (py > L.bottom - 14) dy -= 0.8;

  const n = Math.hypot(dx, dy) || 1;
  const speed = Math.max(95, p.moveSpeed * 1.35);
  return { type: 'dribble', vx: (dx / n) * speed, vy: (dy / n) * speed };
}

export function penaltyShot(p, ctx) {
  const goalX = opponentGoalX(p.attackDir);
  const side = ctx.rng.frac() < 0.5 ? -1 : 1;
  const ty = L.cy + side * FIELD.goalWidth * 0.3;
  const px = p.x;
  const py = p.y - 2;
  const dd = dist(px, py, goalX, ty) || 1;
  return { type: 'shoot', vx: ((goalX - px) / dd) * 235, vy: ((ty - py) / dd) * 235 };
}

export function restartAction(p, ctx, type) {
  const d = p.attackDir;
  const px = p.x;
  const py = p.y - 2;

  if (type === 'penalty') return penaltyShot(p, ctx);

  if (type === 'corner') {
    const tx = opponentGoalX(d) - d * FIELD.penaltySpot;
    const ty = L.cy + (ctx.rng.frac() * 2 - 1) * 20;
    const dd = dist(px, py, tx, ty) || 1;
    const speed = clamp(dd * 1.1 + 40, 120, 230);
    return withError({ type: 'cross', vx: ((tx - px) / dd) * speed, vy: ((ty - py) / dd) * speed }, ctx, 0.18);
  }

  if (type === 'goal_kick') {
    const option = choosePass(p, ctx, { relaxed: true, minDist: 60, maxDist: 260 });
    if (option) return passAction(p, option.receiver, ctx);
    const ty = L.cy + (ctx.rng.frac() - 0.5) * 100;
    const dd = dist(px, py, L.cx, ty) || 1;
    return withError({ type: 'clear', vx: ((L.cx - px) / dd) * 200, vy: ((ty - py) / dd) * 200 }, ctx, 0.25);
  }

  if (type === 'throw_in') {
    const option = choosePass(p, ctx, { relaxed: true, minDist: 15, maxDist: 130 });
    if (option) return passAction(p, option.receiver, ctx, 0.8);
    const tx = px + d * 30;
    const dd = dist(px, py, tx, L.cy) || 1;
    return { type: 'clear', vx: ((tx - px) / dd) * 90, vy: ((L.cy - py) / dd) * 90 };
  }

  if (type === 'kickoff') {
    const option = choosePass(p, ctx, { relaxed: true, minDist: 20, maxDist: 150 });
    if (option) return passAction(p, option.receiver, ctx, 0.9);
  }

  return decideTouch(p, ctx);
}