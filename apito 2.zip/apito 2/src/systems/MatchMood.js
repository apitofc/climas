// Clima da partida (Upgrade 2): tensão, calor de cada time e humor da torcida. Funções puras, sem Phaser.
//
// Regras de projeto:
//  - O clima muda o comportamento dos JOGADORES (mais agressivos quando esquenta), nunca a chance de o árbitro errar.
//  - Decisão correta e decisão popular são coisas diferentes: a torcida (do time da casa) reage a quem a decisão favorece,
//    não a quem tem razão. Isso só aparece como informação (HUD, relatório, redes sociais): não mexe na nota.
//  - Decisões tomadas com a tensão alta valem um pouco mais na nota, para quem acerta e para quem erra (x1,25).
import { ERROR_SEVERITY } from './MatchRules.js';

export const LATE_MINUTE = 80;

// Minutos finais de um jogo equilibrado: decisão por 1 gol de diferença ou empate depois dos 80 minutos.
export function isLateDrama(clockText, score) {
  const minutes = Number(String(clockText || '0:0').split(':')[0]) || 0;
  return minutes >= LATE_MINUTE && Math.abs(score.home - score.away) <= 1;
}

export const TENSION_HIGH = 60;
export const TENSION_CALM = 25;
export const PRESSURE_WEIGHT = 1.25;
const MAX_HEAT_AGGRESSION = 0.15; // quanto a agressividade de um time sobe com o calor no máximo
const DECAY_PER_S = 0.12; // a tensão volta devagar à base em jogo corrido (pontos por segundo)

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const other = (t) => (t === 'home' ? 'away' : 'home');

export const tensionLabel = (t) => (t >= TENSION_HIGH ? 'Quente' : t >= TENSION_CALM ? 'Tenso' : 'Calmo');
export const crowdLabel = (c) => (c <= -35 ? 'Irritada' : c >= 35 ? 'Satisfeita' : 'Dividida');

// Qual time a decisão favoreceu (null = não favoreceu ninguém). Só olha para a decisão, nunca para quem tinha razão.
export function favoredBy(e) {
  if (!e || e.type === 'unnecessary_whistle' || e.type === 'dissent') return null;
  const a = e.actual || {};
  if (e.type === 'goal_check') {
    // Anular um gol favorece o adversário de quem marcou; confirmar um gol irregular favorece quem marcou.
    return a.foulCalled ? other(e.offender.team) : e.expected && e.expected.foul ? e.offender.team : null;
  }
  const cards = (a.cards || []).filter((c) => c.color !== 'warning');
  if (cards.length) return other(cards[0].team);
  if (a.foulCalled) return e.victim.team;
  if (e.expected && e.expected.foul) return e.offender.team; // falta real deixada passar
  return null;
}

export default class MatchMood {
  constructor(base = 0) {
    this.setBase(base);
  }

  // base: tensão de partida (importância, clássico, final, disputa de título); crowdFactor: o quanto a torcida pesa (1 a 1,5).
  setBase(base, crowdFactor = 1) {
    this.crowdFactor = crowdFactor;
    this.trainDecay = this.trainDecay ?? 1;
    this.trainError = this.trainError ?? 1;
    this.late = false;
    this.lateSeen = false;
    this.floor = 0;
    this.base = clamp(base, 0, 40);
    this.tension = this.base;
    this.peak = this.base;
    this.crowd = 0; // humor da torcida da casa: -100 (irritada) a 100 (satisfeita)
    this.crowdMin = 0;
    this.heatPts = { home: 0, away: 0 }; // 0 a 100
    this.counts = { pressureDecisions: 0, pressureCorrect: 0, unpopularCorrect: 0, popularWrong: 0, graveSpikes: 0, benchProtests: 0, crowdPressure: 0 };
    this.hot = false;
  }

  level() {
    return tensionLabel(this.tension);
  }

  // Quanto a agressividade do time sobe com o calor (usada na disputa de bola).
  heat(team) {
    const own = this.heatPts[team] / 100;
    return clamp((own * 0.7 + (this.tension / 100) * 0.3) * MAX_HEAT_AGGRESSION, 0, MAX_HEAT_AGGRESSION);
  }

  heats() {
    return { home: this.heat('home'), away: this.heat('away') };
  }

  update(ms) {
    const dec = DECAY_PER_S * (ms / 1000) * this.trainDecay;
    this.tension = Math.max(this.base, this.floor, this.tension - dec);
    for (const t of ['home', 'away']) this.heatPts[t] = Math.max(0, this.heatPts[t] - dec * 1.5);
    this.crowd += Math.sign(-this.crowd) * Math.min(Math.abs(this.crowd), dec * 0.5); // o humor também esfria
  }

  // Controle de jogo (treino): o clima esfria mais rápido e os erros esquentam menos.
  setTraining({ decayMul = 1, errorMul = 1 } = {}) {
    this.trainDecay = decayMul;
    this.trainError = errorMul;
  }

  // Minutos finais de um jogo equilibrado: o clima não esfria abaixo de 50 enquanto durar.
  setLate(on) {
    if (on === this.late) return false;
    this.late = on;
    this.floor = on ? 50 : 0;
    if (on) {
      this.lateSeen = true;
      this.tension = Math.max(this.tension, 55);
      this.peak = Math.max(this.peak, this.tension);
    }
    return on;
  }

  add(delta) {
    this.tension = clamp(this.tension + delta, this.base, 100);
    this.peak = Math.max(this.peak, this.tension);
  }

  heatUp(team, pts) {
    if (team) this.heatPts[team] = clamp(this.heatPts[team] + pts, 0, 100);
  }

  // Chamado para cada decisão da súmula, ANTES de ela entrar no log: grava a tensão em que a decisão foi tomada e quem
  // ela favoreceu, e depois aplica o efeito no clima. Devolve { crossedHot } se o clima passou do limite agora.
  onDecision(entry) {
    const pre = this.tension;
    entry.tension = Math.round(pre);
    entry.favored = favoredBy(entry);

    if (pre >= TENSION_HIGH && entry.type !== 'unnecessary_whistle') {
      this.counts.pressureDecisions += 1;
      if (entry.correct) this.counts.pressureCorrect += 1;
    }

    // Torcida: reage a quem foi favorecido, tenha ou não razão.
    if (entry.favored) {
      this.crowd = clamp(this.crowd + (entry.favored === 'home' ? 8 : -8) * this.crowdFactor, -100, 100);
      this.crowdMin = Math.min(this.crowdMin, this.crowd);
      if (entry.correct && entry.favored === 'away') this.counts.unpopularCorrect += 1;
      if (!entry.correct && entry.favored === 'home') this.counts.popularWrong += 1;
    }

    // Tensão e calor.
    const errors = entry.errors || [];
    if (entry.type === 'unnecessary_whistle') this.add(3);
    else if (!errors.length) this.add(-5);
    else {
      let up = 0;
      if (errors.includes('FOUL_MISSED')) {
        up += 12;
        if ((entry.evidence || []).includes('retorno de lesão')) up += 6; // falta ignorada em quem voltou de lesão revolta o time
        this.heatUp(entry.victim && entry.victim.team, 12);
      }
      if (errors.includes('FOUL_WRONG')) {
        up += 8;
        this.heatUp(entry.offender && entry.offender.team, 12);
      }
      if (errors.some((c) => c.startsWith('CARD_'))) up += 6;
      const grave = errors.reduce((a, c) => a + (ERROR_SEVERITY[c] ?? 1), 0) >= 3 || (entry.type === 'goal_check' && errors.length > 0);
      if (grave) {
        up += 10;
        this.counts.graveSpikes += 1;
      }
      this.add((up || 4) * this.trainError);
    }
    const crossedHot = !this.hot && this.tension >= TENSION_HIGH;
    if (crossedHot) this.hot = true;
    if (this.tension < TENSION_HIGH - 10) this.hot = false;
    return { crossedHot };
  }

  summary() {
    return {
      late: this.lateSeen,
      peak: Math.round(this.peak),
      final: Math.round(this.tension),
      crowd: Math.round(this.crowd),
      crowdMin: Math.round(this.crowdMin),
      label: tensionLabel(this.peak),
      ...this.counts,
    };
  }

  capture() {
    return { tension: this.tension, peak: this.peak, crowd: this.crowd, crowdMin: this.crowdMin, heatPts: { ...this.heatPts }, counts: { ...this.counts }, hot: this.hot, late: this.late, lateSeen: this.lateSeen, floor: this.floor };
  }

  restore(s) {
    this.tension = s.tension;
    this.peak = s.peak;
    this.crowd = s.crowd;
    this.crowdMin = s.crowdMin;
    this.heatPts = { ...s.heatPts };
    this.counts = { ...s.counts };
    this.hot = s.hot;
    this.late = s.late ?? false;
    this.lateSeen = s.lateSeen ?? false;
    this.floor = s.floor ?? 0;
  }
}
