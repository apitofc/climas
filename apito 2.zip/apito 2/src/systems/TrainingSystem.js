// Centro de treinamento (Upgrade 6): atividades curtas que melhoram atributos profissionais do árbitro. Funções puras.
//
// Regras de projeto:
//  - Os exercícios usam as MESMAS regras do jogo (MatchRules, mesma regra de impedimento da simulação), então o que se
//    aprende no treino vale na partida e a resposta certa nunca diverge.
//  - Os atributos dão pequenas vantagens explícitas (velocidade, tempo para apitar, clima da partida e dicas no painel).
//    Nenhum deles muda a resposta certa de um lance nem a nota.
//  - O treino tem limite por rodada da carreira (2 sessões), para não substituir as partidas.
//  - Cada sessão é determinística (mesma rodada, mesmo exercício) e só conta uma vez.
import { makeRng, hashString } from '../utils/rng.js';
import { INCIDENT, classifyFoul, buildExpected, contactGrade, tacticalLevel } from './MatchRules.js';
import { VAR_BANK, CONFRONT_BANK, CONFRONT_OPTIONS, RULES_BANK } from '../data/trainingContent.js';

export const SESSIONS_PER_WEEK = 2;
export const SESSION_LENGTH = 5;
export const SESSION_XP = 24; // pontos de atributo por sessão perfeita, sem o bônus
export const PERFECT_BONUS = 6;
export const CAREER_XP_PER_SESSION = 6;
export const MAX_LEVEL = 5;
export const LEVEL_XP = [0, 40, 100, 180, 280, 400]; // pontos de atributo para chegar ao nível 0, 1, 2...
export const HISTORY_LIMIT = 20;

export const ATTRIBUTES = [
  { id: 'fouls', label: 'Leitura de faltas', activity: 'Reconhecer faltas em situações ilustradas', blurb: 'Faltas, simulações, mão na bola, falta tática e cartões.', effect: (l) => `+${l * 10}% no tempo para apitar faltas` },
  { id: 'offside', label: 'Impedimentos', activity: 'Julgar impedimentos', blurb: 'A regra do impedimento com a linha desenhada.', effect: (l) => `+${l * 10}% no tempo para apitar impedimentos` },
  { id: 'position', label: 'Posicionamento', activity: 'Treinar o posicionamento', blurb: 'Onde ficar em cada jogada.', effect: (l) => `+${l * 4}% de velocidade do árbitro em campo` },
  { id: 'var', label: 'Domínio do VAR', activity: 'Aprender quando o VAR pode intervir', blurb: 'Quais lances o VAR pode rever.', effect: (l) => (l >= 2 ? 'O painel marca "lance típico de VAR"' : 'No nível 2, o painel marca "lance típico de VAR"') },
  { id: 'control', label: 'Controle de jogo', activity: 'Simular situações de confronto entre jogadores', blurb: 'Reclamações, empurrões e agressões.', effect: (l) => `Erros esquentam ${l * 4}% menos o clima e o jogo esfria ${l * 15}% mais rápido` },
  { id: 'rules', label: 'Conhecimento de regras', activity: 'Testes de regras e interpretação', blurb: 'Perguntas rápidas sobre as regras do jogo.', effect: (l) => (l >= 5 ? 'O painel mostra a regra do lance e quantas agravantes ele tem' : l >= 3 ? 'O painel mostra a regra do lance' : 'No nível 3, o painel mostra a regra do lance') },
];
export const getAttribute = (id) => ATTRIBUTES.find((a) => a.id === id) || null;

// ------------------------------------------------------------ estado da carreira
export const emptyTraining = () => ({ attrs: Object.fromEntries(ATTRIBUTES.map((a) => [a.id, 0])), week: { key: '', used: 0 }, history: [], sessions: 0 });

export function ensureTraining(career) {
  if (!career.training || typeof career.training !== 'object') career.training = emptyTraining();
  const t = career.training;
  if (!t.attrs || typeof t.attrs !== 'object') t.attrs = {};
  for (const a of ATTRIBUTES) if (!Number.isFinite(t.attrs[a.id])) t.attrs[a.id] = 0;
  if (!t.week || typeof t.week !== 'object') t.week = { key: '', used: 0 };
  if (!Array.isArray(t.history)) t.history = [];
  if (!Number.isFinite(t.sessions)) t.sessions = 0;
  return t;
}

export const levelOf = (xp) => {
  let lvl = 0;
  for (let i = 1; i < LEVEL_XP.length; i++) if (xp >= LEVEL_XP[i]) lvl = i;
  return lvl;
};

export function attrLevelInfo(xp) {
  const level = levelOf(xp);
  if (level >= MAX_LEVEL) return { level, into: xp - LEVEL_XP[level], need: 0, next: null };
  return { level, into: xp - LEVEL_XP[level], need: LEVEL_XP[level + 1] - LEVEL_XP[level], next: LEVEL_XP[level + 1] };
}

const weekKey = (career) => `${career.world.season}:${career.world.week}`;

// Sessões que ainda restam nesta rodada da carreira.
export function sessionsLeft(career) {
  const t = ensureTraining(career);
  return t.week.key === weekKey(career) ? Math.max(0, SESSIONS_PER_WEEK - t.week.used) : SESSIONS_PER_WEEK;
}

export function trainingLevels(career) {
  const t = ensureTraining(career);
  return Object.fromEntries(ATTRIBUTES.map((a) => [a.id, levelOf(t.attrs[a.id])]));
}

// Vantagens que os atributos dão em partida. Nenhuma muda a resposta certa de um lance.
export function trainingEffects(career) {
  const L = career ? trainingLevels(career) : Object.fromEntries(ATTRIBUTES.map((a) => [a.id, 0]));
  return {
    levels: L,
    positionSpeedMul: 1 + 0.04 * L.position,
    foulWindowMul: 1 + 0.1 * L.fouls,
    offsideWindowMul: 1 + 0.1 * L.offside,
    tensionDecayMul: 1 + 0.15 * L.control,
    errorTensionMul: 1 - 0.04 * L.control,
    varTag: L.var >= 2,
    ruleHint: L.rules >= 3,
    agravantes: L.rules >= 5,
  };
}

// ------------------------------------------------------------ exercícios de faltas
const pickFrom = (rng, list) => list[Math.floor(rng.frac() * list.length)];
const between = (rng, a, b) => a + rng.frac() * (b - a);

const FOUL_OPTIONS = {
  field: [
    { id: 'play_on', label: 'Seguir o jogo' },
    { id: 'foul', label: 'Falta, sem cartão' },
    { id: 'foul_y', label: 'Falta e cartão amarelo' },
    { id: 'foul_r', label: 'Falta e cartão vermelho' },
    { id: 'dive_y', label: 'Amarelo para quem caiu (simulação)' },
  ],
  area: [
    { id: 'play_on', label: 'Seguir o jogo' },
    { id: 'pen', label: 'Pênalti, sem cartão' },
    { id: 'pen_y', label: 'Pênalti e cartão amarelo' },
    { id: 'pen_r', label: 'Pênalti e cartão vermelho' },
    { id: 'dive_y', label: 'Amarelo para quem caiu (simulação)' },
  ],
};

function keyOf(type, expected) {
  if (!expected.foul) return expected.card === 'yellow' ? 'dive_y' : 'play_on';
  const base = type === INCIDENT.PENALTY ? 'pen' : 'foul';
  return base + (expected.card === 'yellow' ? '_y' : expected.card === 'red' ? '_r' : '');
}

const RULE_TEXT = {
  foul: 'Houve falta, mas sem agravantes suficientes para cartão (0 ou 1 agravante).',
  foul_y: 'Duas agravantes, falta tática ou reincidência pedem amarelo.',
  foul_r: 'Três agravantes, ou chance clara de gol evitada, pedem vermelho.',
  pen: 'Falta dentro da área é pênalti; sem agravantes suficientes, sem cartão.',
  pen_y: 'Pênalti com amarelo (duas agravantes ou falta tática).',
  pen_r: 'Pênalti com vermelho (três agravantes).',
  dive_y: 'Simulação: amarelo para quem caiu e tiro livre indireto para o adversário, sem falta.',
};

function foulItem(rng, kind, i) {
  let type = INCIDENT.LIGHT_FOUL;
  let level = 'light';
  let evidence = [];
  let inArea = false;
  let expected = null;
  let note = '';
  const scene = { kind: 'foul', fromBehind: false, inArea: false, contact: true, hand: false, dive: false, tactical: false };

  const aggravated = (wantedLevels, tries = 40) => {
    for (let t = 0; t < tries; t++) {
      const relSpeed = between(rng, 15, 100);
      const fromBehind = rng.frac() < 0.5;
      const aggression = between(rng, 0.1, 0.8);
      const cls = classifyFoul({ relSpeed, fromBehind, aggression });
      if (wantedLevels.includes(cls.level)) return { cls, relSpeed, fromBehind };
    }
    const relSpeed = wantedLevels.includes('light') ? 25 : 90;
    return { cls: classifyFoul({ relSpeed, fromBehind: !wantedLevels.includes('light'), aggression: wantedLevels.includes('light') ? 0.2 : 0.8 }), relSpeed, fromBehind: !wantedLevels.includes('light') };
  };

  switch (kind) {
    case 'clean': {
      const relSpeed = between(rng, 10, 70);
      type = INCIDENT.CHALLENGE;
      evidence = ['bola jogada primeiro', contactGrade(relSpeed).text];
      expected = buildExpected(type, 'light');
      note = 'A bola foi jogada primeiro: disputa legal, o jogo segue.';
      break;
    }
    case 'light': {
      const a = aggravated(['light']);
      evidence = [...a.cls.evidence, contactGrade(a.relSpeed).text];
      expected = buildExpected(type, 'light');
      scene.fromBehind = a.fromBehind;
      break;
    }
    case 'serious': {
      const a = aggravated(['yellow', 'red']);
      type = INCIDENT.SERIOUS_FOUL;
      level = a.cls.level;
      evidence = [...a.cls.evidence, contactGrade(a.relSpeed).text];
      expected = buildExpected(type, level);
      scene.fromBehind = a.fromBehind;
      break;
    }
    case 'area': {
      const a = aggravated(['light', 'yellow', 'red']);
      type = INCIDENT.PENALTY;
      level = a.cls.level;
      inArea = true;
      scene.inArea = true;
      scene.fromBehind = a.fromBehind;
      evidence = [...a.cls.evidence, contactGrade(a.relSpeed).text, 'dentro da área'];
      expected = buildExpected(type, level);
      break;
    }
    case 'tactical': {
      const a = aggravated(['light']);
      const defendersAhead = pickFrom(rng, [0, 1, 2]);
      const tac = tacticalLevel({ inAttackHalf: true, speed: 40, forward: 0.8, defendersAhead, distGoal: defendersAhead === 0 ? 120 : 250 });
      type = INCIDENT.SERIOUS_FOUL;
      level = tac.level;
      evidence = [...a.cls.evidence, contactGrade(a.relSpeed).text, ...tac.evidence];
      expected = buildExpected(type, level);
      scene.tactical = true;
      break;
    }
    case 'persistent': {
      const a = aggravated(['light']);
      evidence = [...a.cls.evidence, contactGrade(a.relSpeed).text, 'reincidente: 3ª falta'];
      expected = buildExpected(type, 'light', { persistent: true });
      scene.fromBehind = a.fromBehind;
      break;
    }
    case 'hand_d':
    case 'hand_a': {
      const deliberate = kind === 'hand_d';
      inArea = rng.frac() < 0.4;
      scene.inArea = inArea;
      scene.hand = true;
      scene.contact = false;
      type = deliberate ? (inArea ? INCIDENT.PENALTY : INCIDENT.LIGHT_FOUL) : INCIDENT.CHALLENGE;
      evidence = ['mão na bola', ...(deliberate ? ['braço afastado do corpo', 'movimento em direção à bola'] : ['braço junto ao corpo', 'bola em alta velocidade, sem tempo de reação'])];
      if (inArea) evidence.push('dentro da área');
      expected = buildExpected(type, 'light');
      note = deliberate ? 'Braço afastado e movimento em direção à bola: é mão na bola.' : 'Braço junto ao corpo e sem tempo de reação: não é falta.';
      break;
    }
    case 'sim_touch':
    case 'sim': {
      const touch = kind === 'sim_touch';
      inArea = rng.frac() < 0.4;
      scene.inArea = inArea;
      scene.dive = true;
      scene.contact = touch;
      type = INCIDENT.SIMULATION;
      evidence = touch ? ['contato mínimo (leve)', 'queda exagerada'] : ['sem contato', 'queda antes do contato'];
      if (inArea) evidence.push('dentro da área');
      expected = buildExpected(type, 'none');
      break;
    }
    default:
      throw new Error(`exercício desconhecido: ${kind}`);
  }

  const answer = keyOf(type, expected);
  const explain = `Evidências: ${evidence.join(', ')}. ${note || (answer === 'play_on' ? 'Não há infração que justifique parar o jogo.' : RULE_TEXT[answer])}`;
  return {
    id: `f${i}`,
    prompt: 'O que você decide neste lance?',
    scene: { ...scene, evidence },
    evidence,
    options: FOUL_OPTIONS[inArea || scene.inArea ? 'area' : 'field'],
    answer,
    explain,
  };
}

// ------------------------------------------------------------ exercícios de impedimento
// Mesma regra da simulação (PlayerAI.offsideInfo): metade de ataque e margem maior que 1 px sobre o mais recuado entre o
// penúltimo defensor e a bola. A posição de partida é na horizontal, atacando para a direita.
const HALF = 160;
export const isOffsidePosition = (attackerX, line, ballX) => attackerX > HALF && attackerX - Math.max(line, ballX) > 1;

function offsideItem(rng, kind, i) {
  const gk = 305;
  let line;
  let ball;
  let a;
  switch (kind) {
    case 'offside':
    case 'close_off':
      line = between(rng, 175, 240);
      ball = between(rng, 120, Math.min(line, 220));
      a = Math.max(line, ball) + (kind === 'close_off' ? between(rng, 6, 10) : between(rng, 14, 38));
      break;
    case 'legal_line':
    case 'close_legal':
      line = between(rng, 185, 250);
      ball = between(rng, 120, 230);
      a = Math.max(line, ball) - (kind === 'close_legal' ? between(rng, 6, 10) : between(rng, 14, 40));
      if (a < HALF + 8) a = HALF + 8; // continua na metade de ataque para a pergunta ser só sobre a linha
      break;
    case 'legal_ball':
      line = between(rng, 170, 205);
      ball = line + between(rng, 40, 70);
      a = line + between(rng, 10, 20); // à frente da linha, mas atrás da bola
      break;
    case 'own_half':
      line = between(rng, 110, 140);
      ball = between(rng, 90, 130);
      a = Math.min(HALF - 8, Math.max(line, ball) + between(rng, 10, 22)); // à frente da linha, mas na própria metade
      break;
    default:
      throw new Error(`exercício desconhecido: ${kind}`);
  }
  const defenders = [gk, line, between(rng, 80, Math.max(90, line - 15)), between(rng, 70, Math.max(80, line - 25))];
  const lane = () => 30 + Math.floor(rng.frac() * 90);
  const players = [
    ...defenders.map((x, k) => ({ team: 'def', x: Math.round(x), y: k === 0 ? 75 : lane(), label: k === 0 ? 'G' : '' })),
    { team: 'att', x: Math.round(ball), y: 85, label: 'P' }, // quem passa
    { team: 'att', x: Math.round(a), y: lane(), label: 'A' }, // quem recebe
  ];
  const offside = isOffsidePosition(a, line, ball);
  const margin = Math.round(a - Math.max(line, ball));
  let explain;
  if (a <= HALF) explain = `O atacante A está na própria metade do campo: não existe impedimento ali.`;
  else if (offside) explain = `A está ${margin} px à frente do penúltimo defensor e da bola no momento do passe: impedimento.`;
  else if (a <= line + 1 && a <= ball + 1) explain = `A está ${Math.abs(margin)} px atrás da linha do penúltimo defensor: posição legal.`;
  else explain = `A está atrás da bola no momento do passe: posição legal.`;
  return {
    id: `o${i}`,
    prompt: 'O atacante A recebe o passe de P. Impedimento?',
    scene: { kind: 'offside', players, ball: Math.round(ball), line: Math.round(line), half: HALF },
    evidence: [],
    options: [{ id: 'offside', label: 'Marcar impedimento' }, { id: 'legal', label: 'Posição legal, siga o jogo' }],
    answer: offside ? 'offside' : 'legal',
    explain,
  };
}

// ------------------------------------------------------------ exercícios de posicionamento
// Sistema diagonal: ficar perto da jogada (uns 26 px), um pouco atrás dela e do lado do meio do campo, fora da linha do
// passe e longe de atrapalhar. A resposta certa é o ponto mais perto do ideal.
export function idealSpot(ball, dir) {
  const lateral = ball.y < 75 ? 22 : -22;
  return { x: ball.x - dir * 26, y: ball.y + lateral };
}

function positionItem(rng, i) {
  const dir = rng.frac() < 0.5 ? 1 : -1;
  const ball = { x: Math.round(between(rng, 90, 230)), y: Math.round(between(rng, 45, 105)) };
  const ideal = idealSpot(ball, dir);
  const spots = [
    { kind: 'ideal', x: ideal.x, y: ideal.y, why: 'a uns 26 px, um pouco atrás da jogada e do lado do meio do campo: vê tudo e não atrapalha.' },
    { kind: 'ahead', x: ball.x + dir * 48, y: ball.y, why: 'na frente da jogada: você atrapalha o passe e fica de costas para o lance.' },
    { kind: 'far', x: ball.x - dir * 120, y: ball.y + (ball.y < 75 ? 30 : -30), why: 'muito longe: você chega atrasado ao lance e perde os detalhes.' },
    { kind: 'touch', x: ball.x - dir * 10, y: ball.y < 75 ? 8 : 142, why: 'colado na linha lateral: sem ângulo e com os jogadores entre você e a bola.' },
  ].map((s) => ({ ...s, x: Math.round(Math.max(12, Math.min(308, s.x))), y: Math.round(Math.max(8, Math.min(142, s.y))) }));
  // Embaralha as letras com o sorteio da sessão.
  const order = [0, 1, 2, 3].sort(() => rng.frac() - 0.5);
  const lettered = order.map((idx, k) => ({ ...spots[idx], letter: 'ABCD'[k] }));
  const right = lettered.find((s) => s.kind === 'ideal');
  return {
    id: `p${i}`,
    prompt: 'O time azul ataca na direção da seta. Onde você se posiciona?',
    scene: { kind: 'position', ball, dir, spots: lettered.map((s) => ({ letter: s.letter, x: s.x, y: s.y })) },
    evidence: [],
    options: lettered.map((s) => ({ id: s.letter, label: `Posição ${s.letter}` })),
    answer: right.letter,
    explain: lettered.map((s) => `${s.letter}: ${s.why}`).join(' '),
  };
}

// ------------------------------------------------------------ bancos de perguntas
function shuffle(rng, list) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng.frac() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function varItems(rng) {
  const yes = shuffle(rng, VAR_BANK.filter((x) => x.yes)).slice(0, 3);
  const no = shuffle(rng, VAR_BANK.filter((x) => !x.yes)).slice(0, 2);
  return shuffle(rng, [...yes, ...no]).map((x, i) => ({ id: `v${i}`, prompt: x.q, scene: null, evidence: [], options: [{ id: 'yes', label: 'O VAR pode intervir' }, { id: 'no', label: 'Decisão só do campo' }], answer: x.yes ? 'yes' : 'no', explain: x.explain }));
}
const controlItems = (rng) => shuffle(rng, CONFRONT_BANK).slice(0, SESSION_LENGTH).map((x, i) => ({ id: `c${i}`, prompt: x.q, scene: null, evidence: [], options: CONFRONT_OPTIONS.map((label, k) => ({ id: `o${k}`, label })), answer: `o${x.answer}`, explain: x.explain }));
const rulesItems = (rng) => shuffle(rng, RULES_BANK).slice(0, SESSION_LENGTH).map((x, i) => ({ id: `r${i}`, prompt: x.q, scene: null, evidence: [], options: x.options.map((label, k) => ({ id: `o${k}`, label })), answer: `o${x.answer}`, explain: x.explain }));

const FOUL_KINDS = ['clean', 'light', 'light', 'serious', 'serious', 'area', 'tactical', 'persistent', 'hand_d', 'hand_a', 'sim', 'sim_touch'];
const OFFSIDE_KINDS = ['offside', 'offside', 'legal_line', 'legal_ball', 'own_half', 'close_off', 'close_legal'];

// Monta a sessão de um exercício. A semente decide tudo: a mesma rodada e o mesmo exercício dão a mesma sessão.
export function buildSession(activity, seed) {
  const attr = getAttribute(activity);
  if (!attr) throw new Error(`atividade desconhecida: ${activity}`);
  const rng = makeRng(hashString(`train:${activity}:${seed}`));
  let items;
  if (activity === 'fouls') {
    const kinds = shuffle(rng, FOUL_KINDS);
    const chosen = [];
    for (const k of kinds) if (chosen.length < SESSION_LENGTH && !(chosen.includes(k) && k !== 'light' && k !== 'serious')) chosen.push(k);
    items = chosen.map((k, i) => foulItem(rng, k, i));
  } else if (activity === 'offside') items = shuffle(rng, OFFSIDE_KINDS).slice(0, SESSION_LENGTH).map((k, i) => offsideItem(rng, k, i));
  else if (activity === 'position') items = Array.from({ length: SESSION_LENGTH }, (_, i) => positionItem(rng, i));
  else if (activity === 'var') items = varItems(rng);
  else if (activity === 'control') items = controlItems(rng);
  else items = rulesItems(rng);
  return { id: `${activity}:${seed}`, activity, seed: String(seed), items };
}

// Pontuação: cada resposta certa vale 1; a sessão paga pontos de atributo proporcionais e um bônus para a sessão perfeita.
export function scoreSession(session, answers) {
  const total = session.items.length;
  const detail = session.items.map((it, i) => ({ ok: answers[i] === it.answer, chosen: answers[i] ?? null, answer: it.answer }));
  const correct = detail.filter((d) => d.ok).length;
  const xp = Math.round((SESSION_XP * correct) / total) + (correct === total ? PERFECT_BONUS : 0);
  return { correct, total, xp, detail };
}

export const sessionSeed = (career, activity) => {
  const t = ensureTraining(career);
  const used = t.week.key === weekKey(career) ? t.week.used : 0;
  return `${career.seed}:${weekKey(career)}:${used}`;
};

// Registra a sessão na carreira: pontos do atributo, XP pequeno da carreira, histórico e limite da rodada. Idempotente.
export function applySession(career, session, answers) {
  const t = ensureTraining(career);
  if (t.history.some((h) => h.id === session.id)) return { ok: false, reason: 'duplicate' };
  if (sessionsLeft(career) <= 0) return { ok: false, reason: 'limit' };
  const result = scoreSession(session, answers);
  const before = levelOf(t.attrs[session.activity]);
  t.attrs[session.activity] += result.xp;
  const after = levelOf(t.attrs[session.activity]);
  if (t.week.key !== weekKey(career)) t.week = { key: weekKey(career), used: 0 };
  t.week.used += 1;
  t.sessions += 1;
  career.xp += CAREER_XP_PER_SESSION;
  t.history.unshift({ id: session.id, activity: session.activity, correct: result.correct, total: result.total, xp: result.xp, season: career.world.season, week: career.world.week });
  t.history.length = Math.min(t.history.length, HISTORY_LIMIT);
  return { ok: true, result, levelUp: after > before ? { attr: session.activity, from: before, to: after } : null, careerXp: CAREER_XP_PER_SESSION };
}
