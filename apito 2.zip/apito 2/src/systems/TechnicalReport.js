// Relatório técnico pós-jogo (Upgrade 5): funciona como a avaliação de uma comissão de arbitragem.
// Funções puras. Tudo sai da súmula de decisões e da nota já calculadas: o relatório EXPLICA a nota, nunca a recalcula, e
// nem a torcida nem a quantidade de cartões entram nela (a seção "Fora da nota" mostra isso ao jogador).
import { describeEntry, weightOf } from './RefereeGrading.js';
import { ERROR_SEVERITY } from './MatchRules.js';
import { crowdLabel, TENSION_HIGH } from './MatchMood.js';

const sum = (list, fn) => list.reduce((a, x) => a + fn(x), 0);
const pct = (r) => `${Math.round(r * 100)}%`;
const plural = (n, a, b) => `${n} ${n === 1 ? a : b}`;
const comma = (n) => String(Math.round(n * 10) / 10).replace('.', ',');

// ------------------------------------------------------------ dicas: o que o lance mostrava
const has = (e, code) => e.errors.includes(code);
const ev = (e, text) => (e.evidence || []).some((x) => x.includes(text));

// Dica do lance + o que a equipe de arbitragem tinha mostrado (bandeira errada ou conselho errado seguido).
export function tipFor(e) {
  const base = baseTip(e);
  const extra = [];
  if (e.crew && e.crew.flag && e.crew.flag.wrong && e.errors.length) extra.push('A bandeira do assistente estava errada: assistentes também erram, confira a posição.');
  if (e.crew && e.crew.consult && e.crew.consult.followed && e.crew.consult.correct === false) extra.push('Você seguiu a opinião do assistente, que estava errada.');
  return extra.length ? `${base} ${extra.join(' ')}` : base;
}

function baseTip(e) {
  if (e.type === 'dissent') return e.dissent && e.dissent.level === 'mild' ? 'Reclamação leve e controlada (primeira vez, tom calmo) pede só uma conversa. Cartão aqui seria exagero.' : 'Gestos exagerados, gritos, reclamação insistente ou jogador já advertido: amarelo por reclamação. Só conversar deixa o clima esquentar.';
  if (e.type === 'unnecessary_whistle') return 'Só apite quando houver um lance por perto. Apito sem lance para o jogo à toa.';
  if (e.type === 'goal_check') return has(e, 'FOUL_MISSED') ? 'Gol depois de falta ou impedimento da equipe que marcou deve ser anulado (Espaço, F ou G logo depois do gol).' : 'Se não houve falta nem impedimento no lance do gol, o gol vale: não anule.';
  if (e.subtype === 'handball') return ev(e, 'braço afastado') ? 'Braço afastado do corpo e movimento em direção à bola: é mão na bola (pênalti na área).' : 'Braço junto ao corpo, bola rápida e sem tempo de reação: não é falta.';
  if (e.type === 'simulation') return ev(e, 'contato mínimo') ? 'Contato mínimo com queda exagerada continua sendo simulação: amarelo para quem caiu, sem falta.' : 'Queda antes de qualquer contato é simulação: amarelo para quem caiu, sem falta.';
  if (ev(e, 'falta tática')) return 'Falta que interrompe ataque promissor pede amarelo; se era o último defensor com chance clara de gol, vermelho.';
  if (e.persistent || ev(e, 'reincidente')) return 'A partir da 3ª falta marcada contra o mesmo jogador, uma falta leve já merece amarelo.';
  if (e.type === 'offside') return 'Confira a posição do atacante no momento do passe antes de decidir: impedimento só vale se ele participou do lance.';
  if (has(e, 'FOUL_MISSED')) return ev(e, 'contato antes da bola') ? 'Havia contato antes da bola: isso é falta. Releia a linha de evidências do painel.' : 'Havia infração no lance. Releia a linha de evidências do painel.';
  if (has(e, 'FOUL_WRONG')) return ev(e, 'bola jogada primeiro') ? 'A bola foi jogada primeiro: disputa legal, o jogo segue.' : 'Não havia infração nesse lance: nem todo contato é falta.';
  if (e.errors.some((c) => c.startsWith('CARD_'))) return 'Conte as agravantes: por trás, alta velocidade e entrada imprudente. Duas pedem amarelo, três pedem vermelho.';
  if (has(e, 'ADVANTAGE_FAILED')) return 'Vantagem só vale se a equipe prejudicada mantiver a bola. Se a jogada era perigosa, marque a falta.';
  return 'Releia as evidências do painel antes de decidir.';
}

// ------------------------------------------------------------ recomendações de treinamento
// Nomes das atividades do futuro centro de treinamento (Upgrade 6).
const TRAINING = {
  faltas: 'Reconhecer faltas em situações ilustradas',
  simulacao: 'Simular situações de confronto entre jogadores',
  impedimento: 'Julgar impedimentos',
  cartoes: 'Testes de regras e interpretação (cartões)',
  maos: 'Testes de regras e interpretação (mão na bola)',
  taticas: 'Testes de regras e interpretação (falta tática e reincidência)',
  gol: 'Aprender quando o VAR pode intervir (gols)',
  posicionamento: 'Treinar o posicionamento',
  vantagem: 'Testes de regras e interpretação (vantagem)',
  var: 'Aprender quando o VAR pode intervir',
  pressao: 'Simular situações de confronto entre jogadores',
  apito: 'Testes de regras e interpretação (quando apitar)',
  equipe: 'Testes de regras e interpretação (equipe de arbitragem)',
  reclamacao: 'Simular situações de confronto entre jogadores',
};

// Qual atividade do centro de treinamento cobre cada recomendação (ids de TrainingSystem.ATTRIBUTES).
const ACTIVITY_OF = { reclamacao: 'control', equipe: 'rules', faltas: 'fouls', simulacao: 'control', impedimento: 'offside', cartoes: 'rules', maos: 'rules', taticas: 'rules', gol: 'var', vantagem: 'rules', apito: 'rules', posicionamento: 'position', var: 'var', pressao: 'control' };

function recommendations({ log, grade, varReviews, facts, crew }) {
  const incidents = log.filter((e) => e.type !== 'unnecessary_whistle');
  const wrong = (fn) => incidents.filter((e) => e.errors.length && fn(e));
  const score = (list) => sum(list, (e) => sum(e.errors, (c) => ERROR_SEVERITY[c] ?? 1) * weightOf(e));
  const out = [];
  const add = (id, list, reason) => list.length && out.push({ id, training: TRAINING[id], reason, score: score(list) });

  const faltas = wrong((e) => has(e, 'FOUL_MISSED') && e.type !== 'offside' && e.type !== 'goal_check' && e.subtype !== 'handball');
  add('faltas', faltas, `${plural(faltas.length, 'infração deixou', 'infrações deixaram')} de ser marcada${faltas.length === 1 ? '' : 's'} (${faltas.slice(0, 3).map((e) => e.clock).join(', ')}).`);
  const sim = wrong((e) => e.type === 'simulation');
  add('simulacao', sim, `${plural(sim.length, 'simulação', 'simulações')} mal resolvida${sim.length === 1 ? '' : 's'}: contato mínimo com queda exagerada é simulação.`);
  const off = wrong((e) => e.type === 'offside');
  add('impedimento', off, `${plural(off.length, 'impedimento', 'impedimentos')} decidido${off.length === 1 ? '' : 's'} errado${off.length === 1 ? '' : 's'}.`);
  const cards = wrong((e) => e.errors.some((c) => c.startsWith('CARD_')) && e.type !== 'goal_check');
  add('cartoes', cards, `${plural(cards.length, 'cartão aplicado', 'cartões aplicados')} de forma incorreta (gravidade, jogador ou falta de cartão).`);
  const hands = wrong((e) => e.subtype === 'handball');
  add('maos', hands, `${plural(hands.length, 'lance de mão na bola', 'lances de mão na bola')} errado${hands.length === 1 ? '' : 's'}.`);
  const tact = wrong((e) => ev(e, 'falta tática') || e.persistent);
  add('taticas', tact, `${plural(tact.length, 'falta tática ou reincidente', 'faltas táticas ou reincidentes')} sem o cartão certo.`);
  const gols = wrong((e) => e.type === 'goal_check');
  add('gol', gols, `${plural(gols.length, 'conferência de gol', 'conferências de gol')} errada${gols.length === 1 ? '' : 's'}.`);
  const adv = wrong((e) => has(e, 'ADVANTAGE_FAILED'));
  add('vantagem', adv, `${plural(adv.length, 'vantagem', 'vantagens')} que não deu certo.`);
  const diss = wrong((e) => e.type === 'dissent');
  add('reclamacao', diss, `${plural(diss.length, 'reclamação', 'reclamações')} mal resolvida${diss.length === 1 ? '' : 's'}: leve pede conversa, exagerada pede amarelo.`);
  const whistles = log.filter((e) => e.type === 'unnecessary_whistle');
  if (whistles.length >= 2) out.push({ id: 'apito', training: TRAINING.apito, reason: `${whistles.length} apitos sem lance por perto.`, score: whistles.length * 1.5 });

  if (crew && crew.followedWrong > 0) out.push({ id: 'equipe', training: TRAINING.equipe, reason: `${plural(crew.followedWrong, 'opinião errada do assistente foi seguida', 'opiniões erradas do assistente foram seguidas')}: confira as evidências antes de seguir um conselho.`, score: crew.followedWrong * 3 });

  const pos = grade.categories.find((c) => c.id === 'position');
  if (pos && pos.ratio < 0.6) out.push({ id: 'posicionamento', training: TRAINING.posicionamento, reason: `Posicionamento em ${pct(pos.ratio)}: ${pos.detail}.`, score: (1 - pos.ratio) * 6 });

  const bad = (varReviews || []).filter((r) => r.kind === 'change' && r.finalCorrect === false);
  if (bad.length) out.push({ id: 'var', training: TRAINING.var, reason: `${plural(bad.length, 'decisão alterada no VAR', 'decisões alteradas no VAR')} continuou${bad.length === 1 ? '' : 'm'} errada${bad.length === 1 ? '' : 's'}.`, score: bad.length * 3 });

  const hot = incidents.filter((e) => (e.tension ?? 0) >= TENSION_HIGH && e.errors.length);
  if (hot.length) out.push({ id: 'pressao', training: TRAINING.pressao, reason: `${plural(hot.length, 'erro', 'erros')} com o clima quente (${facts.pressureCorrect} de ${facts.pressureDecisions} decisões sob pressão corretas).`, score: hot.length * 2.5 });

  return out.sort((a, b) => b.score - a.score).slice(0, 3).map(({ id, training, reason }) => ({ id, training, reason, activity: ACTIVITY_OF[id] || 'rules' }));
}

// ------------------------------------------------------------ consistência
// Mesma situação (tipo e gravidade) decidida de jeitos diferentes: marcada em um lance e ignorada em outro, ou cartão diferente.
export function consistencyIssues(log) {
  const groups = new Map();
  for (const e of log) {
    if (e.type === 'unnecessary_whistle' || e.type === 'goal_check' || !e.expected || !e.expected.foul) continue;
    if (e.actual.advantage === 'success' || e.actual.advantage === 'implicit' || e.actual.advantage === 'pending') continue; // vantagem é critério, não inconsistência
    const key = `${e.type}:${e.subtype || ''}:${e.level}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(e);
  }
  const issues = [];
  for (const list of groups.values()) {
    if (list.length < 2) continue;
    const called = list.filter((e) => e.actual.foulCalled);
    const ignored = list.filter((e) => !e.actual.foulCalled);
    const name = describeEntry(list[0]).label.toLowerCase();
    if (called.length && ignored.length) issues.push({ kind: 'foul', text: `${plural(list.length, 'lance de', 'lances de')} ${name}: ${called.length} marcado${called.length === 1 ? '' : 's'} e ${ignored.length} ignorado${ignored.length === 1 ? '' : 's'} (${ignored.map((e) => e.clock).join(', ')}).` });
    const cardOf = (e) => (e.actual.cards.find((c) => c.color !== 'warning') || {}).color || 'nenhum';
    const colors = new Set(called.map(cardOf));
    if (colors.size > 1) issues.push({ kind: 'card', text: `${name}: cartões diferentes para a mesma situação (${[...colors].join(', ')}).` });
  }
  return { issues, groups: [...groups.values()].filter((l) => l.length >= 2).length };
}

// ------------------------------------------------------------ montagem
const verdict = (r) => (r >= 0.85 ? 'good' : r >= 0.6 ? 'ok' : 'bad');
const verdictText = { good: 'forte', ok: 'regular', bad: 'fraco' };

export function buildReport({ log, grade, facts, varReviews = [], mood = null, refStats = null, conditions = null, crew = null }) {
  const incidents = log.filter((e) => e.type !== 'unnecessary_whistle');
  const whistles = log.length - incidents.length;
  const right = incidents.filter((e) => e.correct).length;
  const cats = grade.categories;
  const sorted = [...cats].sort((a, b) => b.ratio - a.ratio);
  const strong = sorted.filter((c) => c.ratio >= 0.85).slice(0, 2);
  const weak = [...cats].sort((a, b) => a.ratio - b.ratio).filter((c) => c.ratio < 0.75).slice(0, 2);

  // 1. Resumo
  const headline =
    grade.nota >= 9 ? 'Atuação de alto nível, sem pontos relevantes de crítica.'
    : grade.nota >= 7 ? 'Atuação sólida, com pontos pontuais a corrigir.'
    : grade.nota >= 5 ? 'Atuação regular: acertou o essencial, mas deixou lances importantes passarem.'
    : 'Atuação abaixo do esperado: a comissão pede revisão das regras e da leitura dos lances.';
  const summary = {
    nota: grade.nota,
    label: grade.label,
    headline,
    strengths: strong.map((c) => `${c.label} (${c.points} de ${c.max}): ${c.detail}`),
    attention: weak.map((c) => `${c.label} (${c.points} de ${c.max}): ${c.detail}`),
  };

  // 2. Por que essa nota
  const why = cats.map((c) => ({ label: c.label, points: c.points, max: c.max, verdict: verdict(c.ratio), text: `${verdictText[verdict(c.ratio)]}: ${c.detail}` }));

  // 3. Decisões
  const byType = new Map();
  for (const e of incidents) {
    const l = describeEntry(e).label;
    const cur = byType.get(l) || { right: 0, total: 0 };
    cur.total += 1;
    if (e.correct) cur.right += 1;
    byType.set(l, cur);
  }
  const decisions = {
    right,
    total: incidents.length,
    whistles,
    byType: [...byType.entries()].map(([label, v]) => ({ label, ...v })),
  };

  // 4. Posicionamento e movimentação
  const seen = incidents.filter((e) => e.refDistance !== null && e.refDistance !== undefined);
  const avg = seen.length ? sum(seen, (e) => e.refDistance) / seen.length : null;
  const near = seen.filter((e) => e.refDistance <= 30).length;
  const far = seen.filter((e) => e.refDistance >= 120);
  const posCat = cats.find((c) => c.id === 'position');
  const positioning = {
    verdict: verdict(posCat ? posCat.ratio : 1),
    avgDistance: avg === null ? null : Math.round(avg),
    near,
    far: far.length,
    farClocks: far.slice(0, 4).map((e) => e.clock),
    fieldLengths: refStats ? Math.round(refStats.travel / refStats.fieldWidth) : null,
    perLance: refStats && incidents.length ? Math.round(refStats.travel / incidents.length / 10) * 10 : null,
  };

  // 5. Consistência
  const cons = consistencyIssues(log);
  const consCat = cats.find((c) => c.id === 'consistency');
  const consistency = { verdict: cons.issues.length ? 'bad' : verdict(consCat ? consCat.ratio : 1), issues: cons.issues.map((i) => i.text), groups: cons.groups, detail: consCat ? consCat.detail : '' };

  // 6. Controle disciplinar
  const cardCat = cats.find((c) => c.id === 'cards');
  const cardErrors = incidents.filter((e) => e.errors.some((c) => c.startsWith('CARD_')));
  const discipline = {
    verdict: verdict(cardCat ? cardCat.ratio : 1),
    yellow: facts.yellow,
    red: facts.red,
    detail: cardCat ? cardCat.detail : '',
    problems: cardErrors.slice(0, 3).map((e) => `${e.clock}: ${describeEntry(e).errors.join(', ')}`),
    tension: mood ? { peak: mood.peak, label: mood.label, graveSpikes: mood.graveSpikes } : null,
  };

  // 7. VAR
  const vr = {
    used: varReviews.length > 0,
    reviews: varReviews.length,
    changed: facts.varChanged || 0,
    fixed: facts.varFixed || 0,
    worsened: facts.varWorsened || 0,
    lines: varReviews.slice(0, 4).map((r) => `${r.clock} · ${r.label}: ${r.kind === 'change' ? `alterou de "${r.initial}" para "${r.final}"` : 'manteve a decisão'}${r.finalCorrect === true ? ' (correto)' : r.finalCorrect === false ? ' (continuou errado)' : ''}`),
  };

  // 8. Lances que poderiam ter sido melhor interpretados
  const misses = log
    .filter((e) => e.errors.length)
    .map((e) => ({ e, sev: sum(e.errors, (c) => ERROR_SEVERITY[c] ?? 1) * (e.type === 'unnecessary_whistle' ? 1 : weightOf(e)) }))
    .sort((a, b) => b.sev - a.sev || a.e.time - b.e.time)
    .slice(0, 5)
    .map(({ e }) => {
      const d = describeEntry(e);
      return { clock: d.clock, label: d.label, who: d.who, did: d.actual, should: d.expected, errors: d.errors, evidence: e.evidence || [], tip: tipFor(e) };
    });

  // 9. Recomendações
  const recs = recommendations({ log, grade, varReviews, facts, crew: crew ? crewSummary(crew) : null });

  // 10. Fora da nota
  const outside = [
    mood ? `Humor da torcida da casa (${crowdLabel(mood.crowd)}): só informação, não altera a nota.` : 'Humor da torcida: só informação, não altera a nota.',
    `Quantidade de cartões (${facts.yellow + facts.red}): a nota avalia se cada cartão foi o certo, não quantos você deu.`,
    ...(facts.unpopularCorrect ? [`${plural(facts.unpopularCorrect, 'decisão correta foi', 'decisões corretas foram')} mal recebida${facts.unpopularCorrect === 1 ? '' : 's'} pela torcida da casa e contam como acerto.`] : []),
    ...(facts.popularWrong ? [`${plural(facts.popularWrong, 'decisão errada agradou', 'decisões erradas agradaram')} a torcida da casa e contam como erro.`] : []),
  ];

  // 11. Contexto da partida: como as condições do jogo podem ter pesado nos lances (só explica, não muda a nota).
  const context = [];
  if (conditions) {
    if (conditions.weather === 'rain' || conditions.weather === 'storm' || conditions.pitch === 'heavy') context.push(`${conditions.text}: disputas mais escorregadias, então eram esperados mais contatos leves e a bola corria diferente.`);
    else if (conditions.pitch === 'poor') context.push('Gramado irregular: mais contatos leves e quedas por causa do piso.');
    if (conditions.lowVisibility) context.push('Visibilidade reduzida: lances distantes eram mais difíceis de ler; chegar perto fazia diferença.');
    for (const st of conditions.stories || []) if (st.id !== 'injury_return') context.push(st.text);
    if (conditions.injuryReturn) context.push(`${conditions.injuryReturn.name} (#${conditions.injuryReturn.number}) voltou de lesão${conditions.injuryReturn.fouled ? ` e sofreu ${conditions.injuryReturn.fouled} falta(s) marcada(s)` : ''}. Faltas nele esquentam o time.`);
    if (conditions.late) context.push('Jogo decidido nos minutos finais: as decisões depois dos 80 minutos pesaram mais, porque o clima não esfriou.');
    context.push('Nada disso muda o que é certo em cada lance: as evidências do painel continuam valendo.');
  }

  const crewSection = crew ? crewReport(crew) : null;

  return { v: 1, context, crew: crewSection, summary, why, decisions, positioning, consistency, discipline, var: vr, misses, recommendations: recs, outside };
}

// Números da equipe numa partida a partir dos dados do jogo (consultas, bandeiras e quarto árbitro).
function crewSummary(c) {
  const cs = c.consults || [];
  return {
    consults: cs.length,
    followedRight: cs.filter((x) => x.followed && x.correct === true).length,
    followedWrong: cs.filter((x) => x.followed && x.correct === false).length,
    ignoredRight: cs.filter((x) => !x.followed && x.correct === true).length,
    divergences: cs.filter((x) => x.divergent).length,
    flagsRaised: c.flagsRaised || 0,
    flagsWrong: c.flagsWrong || 0,
    bench: { calls: (c.bench && c.bench.calls) || 0, ok: (c.bench && c.bench.ok) || 0 },
  };
}

function crewReport(c) {
  const s = crewSummary(c);
  const lines = [];
  lines.push(s.flagsRaised ? `Bandeiras levantadas: ${s.flagsRaised}${s.flagsWrong ? `, ${s.flagsWrong} errada(s)` : ', todas certas'}.` : 'Nenhuma bandeira levantada.');
  if (s.consults) {
    lines.push(`Consultas ao assistente: ${s.consults} (${s.followedRight} opinião(ões) certa(s) seguida(s), ${s.followedWrong} errada(s) seguida(s), ${s.ignoredRight} certa(s) ignorada(s)${s.divergences ? `, ${s.divergences} com comunicação falha` : ''}).`);
  } else lines.push('Você não consultou os assistentes.');
  if (s.bench.calls) lines.push(`Quarto árbitro: ${s.bench.ok} de ${s.bench.calls} pedido(s) de ajuda deram certo.`);
  lines.push('A equipe só dá informação: a decisão e a nota são suas.');
  return { verdict: s.followedWrong > 0 || s.flagsWrong > 0 ? 'bad' : s.consults > 0 || s.flagsRaised > 0 ? 'good' : 'ok', lines };
}

export { comma };
