// Comunicação da carreira: notícias, e-mails e rede social fictícia. Funções puras e determinísticas.
// Tudo é gerado a partir de fatos registrados (resultado, nota, decisões, carreira): nada é inventado.
// Opinião pública (torcedores, comentaristas) é sempre marcada como opinião e nunca altera nota nem reputação.
import { makeRng, hashString } from '../utils/rng.js';
import { isShotImage } from './Highlights.js';
import { COMPETITIONS, getCompetition, getClub, unlockThreshold } from '../data/competitions.js';

// Fatos de uma partida sem registro de decisões (ex.: testes ou dados antigos).
export const EMPTY_FACTS = {
  decisions: 0, correct: 0, yellow: 0, red: 0, redWrong: 0, fouls: 0, penalties: 0, penaltiesCorrect: 0, penaltiesMissed: 0,
  wrongCalls: 0, missedFouls: 0, simulationsPunished: 0, simulationsMissed: 0, offsides: 0, offsidesCorrect: 0, offsidesMissed: 0,
  advantageOk: 0, advantageFailed: 0, whistles: 0,
  goalsDisallowed: 0, goalChecksWrong: 0, dissents: 0, dissentsRight: 0, pressureDecisions: 0, pressureCorrect: 0, unpopularCorrect: 0, popularWrong: 0,
  varReviews: 0, varKept: 0, varChanged: 0, varEligible: 0, varFixed: 0, varWorsened: 0,
};

export const COMMS_LIMITS = { news: 60, inbox: 80, social: 120 };

const comma = (n) => String(Math.round(n * 10) / 10).replace('.', ',');
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const fill = (tpl, vars) => tpl.replace(/\{(\w+)\}/g, (_, k) => (vars[k] === undefined ? '' : vars[k]));

// ------------------------------------------------------------ armazenamento
export function ensureComms(career) {
  if (!Array.isArray(career.inbox)) career.inbox = [];
  if (!Array.isArray(career.news)) career.news = [];
  if (!Array.isArray(career.social)) career.social = [];
  if (!career.comms || !Number.isFinite(career.comms.seq)) career.comms = { seq: 0 };
}

function addUnique(list, item, limit) {
  if (item.key && list.some((x) => x.key === item.key)) return false;
  list.unshift(item); // mais recente primeiro
  list.length = Math.min(list.length, limit);
  return true;
}

// Publica um pacote { news, emails, posts }; itens com a mesma chave nunca são duplicados.
export function publish(career, bundle, date) {
  ensureComms(career);
  const counts = { news: 0, emails: 0, posts: 0 };
  const stamp = (item, prefix) => {
    career.comms.seq += 1;
    return { ...item, id: `${prefix}${career.comms.seq}`, seq: career.comms.seq, date: item.date || date };
  };
  for (const n of bundle.news || []) if (addUnique(career.news, stamp(n, 'n'), COMMS_LIMITS.news)) counts.news++;
  for (const m of bundle.emails || []) if (addUnique(career.inbox, stamp({ read: false, ...m }, 'e'), COMMS_LIMITS.inbox)) counts.emails++;
  for (const p of bundle.posts || []) if (addUnique(career.social, stamp(p, 's'), COMMS_LIMITS.social)) counts.posts++;
  return counts;
}

export const unreadCount = (career) => (career.inbox || []).filter((m) => !m.read).length;

export function setRead(career, id, read = true) {
  const m = career.inbox.find((x) => x.id === id);
  if (!m || m.read === read) return false;
  m.read = read;
  return true;
}

export function markAllRead(career) {
  let changed = 0;
  for (const m of career.inbox) {
    if (!m.read) {
      m.read = true;
      changed++;
    }
  }
  return changed;
}

// Imagem pública: tom das últimas notícias sobre a arbitragem. É só narrativa, não afeta nota nem reputação.
export function publicImage(career) {
  const recent = (career.news || []).filter((n) => n.category === 'arbitragem').slice(0, 5);
  if (!recent.length) return null;
  const count = (t) => recent.filter((n) => n.tone === t).length;
  const score = count('positive') - count('negative');
  return { label: score >= 2 ? 'Positiva' : score <= -2 ? 'Crítica' : 'Neutra', positive: count('positive'), neutral: count('neutral'), negative: count('negative'), total: recent.length };
}

// Escolhe uma variante evitando repetir as duas últimas da mesma categoria.
function pickVariant(variants, category, recentItems, rng) {
  const recent = recentItems.filter((x) => x.category === category).slice(0, 2).map((x) => x.variant);
  const pool = variants.filter((v) => !recent.includes(v.id));
  const list = pool.length ? pool : variants;
  return list[Math.floor(rng.frac() * list.length)];
}

const OUTLETS = ['Gazeta do Apito', 'Portal Bola Cheia', 'Rádio Campo Aberto', 'Folha Esportiva do Interior'];
const JOURNALISTS = [
  { name: 'Marcos Ventura', outlet: 'Gazeta do Apito', handle: '@marcosventura' },
  { name: 'Helena Prado', outlet: 'Portal Bola Cheia', handle: '@helenaprado' },
  { name: 'Rui Campelo', outlet: 'Rádio Campo Aberto', handle: '@ruicampelo' },
];
const COMMENTATORS = [
  { name: 'Léo Campos', outlet: 'Canal Bola Cheia', handle: '@leocampos' },
  { name: 'Dani Trindade', outlet: 'Mesa Redonda FC', handle: '@danitrindade' },
];
const FANS = [
  { name: 'Dona Lourdes', handle: '@donalourdes' },
  { name: 'Seu Zé da Bola', handle: '@seuzedabola' },
  { name: 'Carol da Arquibancada', handle: '@carolarquibancada' },
  { name: 'Tião do Bar', handle: '@tiaodobar' },
  { name: 'Maria Gol', handle: '@mariagol' },
];

// ------------------------------------------------------------ notícias da partida
const PERF = {
  positive: [
    { id: 'p1', title: 'Arbitragem segura garante avaliação positiva em {home} x {away}', summary: '{ref} concluiu a partida com {correct} de {decisions} decisões corretas e nota {nota} ({label}).' },
    { id: 'p2', title: '{ref} faz boa atuação na {comp}', summary: 'A avaliação técnica foi {nota} ({label}) no jogo entre {home} e {away}.' },
    { id: 'p3', title: 'Sem polêmicas: {ref} recebe nota {nota}', summary: 'Em {home} x {away}, foram {correct} acertos em {decisions} decisões avaliadas.' },
    { id: 'p4', title: 'Árbitro de {home} x {away} é elogiado pela supervisão', summary: 'A supervisão avaliou a atuação de {ref} com nota {nota}.' },
  ],
  neutral: [
    { id: 'n1', title: 'Arbitragem regular em {home} x {away}', summary: '{ref} recebeu nota {nota} ({label}), com {correct} de {decisions} decisões corretas.' },
    { id: 'n2', title: '{ref} cumpre sua escala na {comp}', summary: 'Atuação avaliada em {nota}. Foram {decisions} decisões registradas no jogo entre {home} e {away}.' },
    { id: 'n3', title: 'Arbitragem sem grandes destaques em {home} x {away}', summary: 'Avaliação técnica de {nota} para {ref}.' },
  ],
  negative: [
    { id: 'g1', title: 'Arbitragem sob questionamento em {home} x {away}', summary: 'A avaliação técnica de {ref} foi {nota} ({label}); {wrong} de {decisions} decisões foram consideradas incorretas.' },
    { id: 'g2', title: '{ref} tem noite difícil na {comp}', summary: 'Nota {nota} na partida entre {home} e {away}.' },
    { id: 'g3', title: 'Supervisão aponta falhas na arbitragem de {home} x {away}', summary: 'Foram {wrong} decisões incorretas em {decisions}. Nota final: {nota}.' },
  ],
};

export const toneOf = (nota, graves) => (nota >= 7.5 && graves === 0 ? 'positive' : nota < 5 || graves >= 2 ? 'negative' : 'neutral');

function matchVars(ctx, career) {
  const f = ctx.facts;
  return {
    home: ctx.home.name,
    away: ctx.away.name,
    comp: ctx.competition,
    ref: career.name,
    nota: comma(ctx.nota),
    label: ctx.label,
    correct: f.correct,
    decisions: f.decisions,
    wrong: f.decisions - f.correct,
    graves: ctx.graves,
    score: `${ctx.score.home} x ${ctx.score.away}`,
    stage: ctx.stage || '',
  };
}

// Notícias específicas de lances: só existem se o fato aconteceu (por prioridade, no máximo 2 por partida).
function lanceCandidates(ctx) {
  const f = ctx.facts;
  const list = [];
  if (f.redWrong > 0) list.push({ id: 'l-red-wrong', tone: 'negative', title: 'Expulsão contestada em {home} x {away}', summary: 'A avaliação técnica apontou erro na aplicação do cartão vermelho.' });
  if (f.penaltiesMissed > 0) list.push({ id: 'l-pen-missed', tone: 'negative', title: 'Pênalti não marcado gera debate em {home} x {away}', summary: 'A avaliação técnica registrou o lance como infração que deveria ter sido marcada.' });
  if (f.wrongCalls > 0) list.push({ id: 'l-wrong', tone: 'negative', title: 'Falta marcada sem infração gera discussão em {home} x {away}', summary: `${plural(f.wrongCalls, 'falta marcada', 'faltas marcadas')} em lance sem infração, segundo a avaliação técnica.` });
  if (f.offsidesMissed > 0) list.push({ id: 'l-off-missed', tone: 'negative', title: 'Impedimento não marcado em {home} x {away}', summary: 'A avaliação técnica registrou posição de impedimento que não foi assinalada.' });
  if (f.penalties > 0) {
    const all = f.penaltiesCorrect === f.penalties;
    list.push({ id: 'l-pen', tone: all ? 'positive' : 'neutral', title: 'Pênalti marcado em {home} x {away}', summary: `${f.penaltiesCorrect} de ${plural(f.penalties, 'pênalti marcado', 'pênaltis marcados')} ${f.penaltiesCorrect === 1 ? 'foi avaliado como correto' : 'foram avaliados como corretos'}.` });
  }
  if (f.red > 0 && f.redWrong === 0) list.push({ id: 'l-red-ok', tone: 'neutral', title: 'Cartão vermelho em {home} x {away}', summary: 'A supervisão considerou a decisão correta.' });
  if (f.simulationsPunished > 0) list.push({ id: 'l-sim', tone: 'positive', title: 'Simulação punida com cartão amarelo em {home} x {away}', summary: 'A avaliação técnica considerou a decisão correta.' });
  if (f.offsidesCorrect > 0) list.push({ id: 'l-off-ok', tone: 'neutral', title: 'Impedimento assinalado em {home} x {away}', summary: 'A marcação foi avaliada como correta.' });
  return list;
}

const RESULT_WIN = [
  { id: 'r-w1', title: '{winner} vence {loser} por {score} pela {comp}', summary: 'Jogo apitado por {ref}. {stage}' },
  { id: 'r-w2', title: '{winner} bate {loser} ({score}) em {stadium}', summary: 'Partida da {comp}, com arbitragem de {ref}. {stage}' },
  { id: 'r-w3', title: 'Vitória de {winner} sobre {loser}: {score}', summary: '{ref} foi o árbitro do jogo pela {comp}. {stage}' },
];
const RESULT_DRAW = [
  { id: 'r-d1', title: '{home} e {away} empatam em {score}', summary: 'Jogo da {comp} apitado por {ref}. {stage}' },
  { id: 'r-d2', title: 'Empate em {score} entre {home} e {away}', summary: 'Arbitragem de {ref}. {stage}' },
];

function matchNews(career, ctx, rng) {
  const vars = matchVars(ctx, career);
  const date = { season: ctx.season, week: ctx.week };
  const base = { competitionId: ctx.competitionId, fixtureId: ctx.fixtureId, matchId: ctx.matchId, date };
  const outlet = () => OUTLETS[Math.floor(rng.frac() * OUTLETS.length)];
  const out = [];

  // 1) Desempenho da arbitragem (tom pela nota e pelos erros graves).
  const tone = toneOf(ctx.nota, ctx.graves);
  const v = pickVariant(PERF[tone], 'arbitragem', career.news, rng);
  const graves = ctx.graves > 0 ? ` Erros graves registrados: ${ctx.graves}.` : '';
  out.push({ ...base, key: `${ctx.matchId}:news:perf`, category: 'arbitragem', tone, variant: v.id, source: outlet(), headline: fill(v.title, vars), summary: fill(v.summary, vars) + graves });

  // 2) Lances que realmente aconteceram.
  const recentLance = career.news.filter((n) => n.category === 'lance').slice(0, 2).map((n) => n.variant);
  let lances = lanceCandidates(ctx);
  const fresh = lances.filter((l) => !recentLance.includes(l.id));
  if (fresh.length) lances = fresh;
  for (const l of lances.slice(0, 2)) {
    out.push({ ...base, key: `${ctx.matchId}:news:${l.id}`, category: 'lance', tone: l.tone, variant: l.id, source: outlet(), headline: fill(l.title, vars), summary: fill(l.summary, vars) });
  }

  // 2b) VAR: só existe se o árbitro realmente usou a revisão nesta partida.
  const f = ctx.facts;
  if (f.varReviews > 0) {
    const n = f.varReviews;
    let vt;
    if (f.varWorsened > 0) vt = { id: 'l-var-worse', tone: 'negative', title: `Revisão do VAR não corrige o lance em ${ctx.home.name} x ${ctx.away.name}`, summary: `${plural(f.varChanged, 'decisão foi alterada', 'decisões foram alteradas')} após ${plural(n, 'revisão', 'revisões')}, mas a avaliação técnica ainda aponta erro em ${plural(f.varWorsened, 'lance', 'lances')}.` };
    else if (f.varFixed > 0) vt = { id: 'l-var-fixed', tone: 'positive', title: `VAR ajuda a corrigir decisão em ${ctx.home.name} x ${ctx.away.name}`, summary: `${plural(f.varChanged, 'decisão foi alterada', 'decisões foram alteradas')} após ${plural(n, 'revisão', 'revisões')}, e a avaliação técnica confirmou a correção.` };
    else if (f.varChanged > 0) vt = { id: 'l-var-changed', tone: 'neutral', title: `Árbitro altera decisão após revisão do VAR em ${ctx.home.name} x ${ctx.away.name}`, summary: `${plural(f.varChanged, 'decisão alterada', 'decisões alteradas')} em ${plural(n, 'revisão', 'revisões')}.` };
    else vt = { id: 'l-var-kept', tone: 'neutral', title: `Árbitro consulta o VAR e mantém as decisões em ${ctx.home.name} x ${ctx.away.name}`, summary: `${plural(n, 'revisão', 'revisões')} feitas, nenhuma decisão alterada.` };
    out.push({ ...base, key: `${ctx.matchId}:news:var`, category: 'lance', tone: vt.tone, variant: vt.id, source: outlet(), headline: vt.title, summary: vt.summary });
  }

  // 2c) Rixa em clássico (só com lances reais entre os mesmos dois jogadores).
  if (ctx.feud && ctx.rivalry) {
    const fd = ctx.feud;
    out.push({ ...base, key: `${ctx.matchId}:news:feud`, category: 'lance', tone: fd.cards ? 'negative' : 'neutral', variant: 'l-feud', source: outlet(), headline: `${ctx.rivalry}: clima pesado entre ${fd.a.name} e ${fd.b.name}`, summary: `Os dois se envolveram em ${fd.count} lances (${fd.labels.join(', ')}) em ${ctx.home.name} x ${ctx.away.name}${fd.cards ? `, com ${fd.cards === 1 ? 'um cartão' : `${fd.cards} cartões`}` : ''}.` });
  }

  // 3) Resultado do jogo.
  const s = ctx.score;
  const rv = pickVariant(s.home === s.away ? RESULT_DRAW : RESULT_WIN, 'resultado', career.news, rng);
  const winner = s.home > s.away ? ctx.home.name : ctx.away.name;
  const loser = s.home > s.away ? ctx.away.name : ctx.home.name;
  out.push({ ...base, key: `${ctx.matchId}:news:result`, category: 'resultado', tone: 'neutral', variant: rv.id, source: outlet(), headline: fill(rv.title, { ...vars, winner, loser, stadium: ctx.stadium || '' }), summary: fill(rv.summary, vars).trim() });

  // 4) Carreira: nível, nova competição, suspensão (só quando de fato ocorreram).
  const sm = ctx.summary;
  if (sm.leveledUp) out.push({ ...base, key: `${ctx.matchId}:news:level`, category: 'carreira', tone: 'positive', variant: 'c-level', source: outlet(), headline: `${career.name} alcança o nível ${sm.after.level.level}: ${sm.after.level.title}`, summary: `A experiência acumulada chegou a ${sm.after.xp} XP.` });
  for (const name of sm.newUnlocks) out.push({ ...base, key: `news:unlock:${name}`, category: 'carreira', tone: 'positive', variant: 'c-unlock', source: outlet(), headline: `${career.name} ganha acesso à ${name}`, summary: 'A reputação alcançou o requisito da competição.' });
  if (sm.suspension) out.push({ ...base, key: `${ctx.matchId}:news:susp`, category: 'carreira', tone: 'negative', variant: 'c-susp', source: outlet(), headline: `Comitê limita as convocações de ${career.name} por uma rodada`, summary: `Motivo: ${sm.suspension}.` });
  return out;
}

// ------------------------------------------------------------ e-mails da partida
function reportEmail(career, ctx) {
  const f = ctx.facts;
  const sm = ctx.summary;
  const lines = [`Nota final: ${comma(ctx.nota)} (${ctx.label}).`, `Decisões corretas: ${f.correct} de ${f.decisions}.`];
  const cats = ctx.categories.filter((c) => c.points !== undefined && c.max).sort((a, b) => b.ratio - a.ratio);
  if (cats.length) {
    lines.push(`Pontos fortes: ${cats.slice(0, 2).map((c) => `${c.label.toLowerCase()} (${comma(c.points)}/${c.max})`).join(' e ')}.`);
    const weak = cats[cats.length - 1];
    lines.push(`A melhorar: ${weak.label.toLowerCase()} (${comma(weak.points)}/${weak.max}).`);
  }
  const m = ctx.mistakes[0];
  if (m && m.errors && m.expected) lines.push(`Principal erro: ${m.clock} · ${m.label}: ${m.errors.join(', ')}. O correto seria: ${m.expected}.`);
  const h = ctx.hits[0];
  if (h && h.text) lines.push(`Principal acerto: ${h.clock} · ${h.label}: ${h.text}.`);
  if (f.varReviews > 0) {
    lines.push(`VAR: ${plural(f.varReviews, 'revisão', 'revisões')}, ${plural(f.varChanged, 'decisão alterada', 'decisões alteradas')}${f.varChanged ? ` (${f.varFixed} confirmada${f.varFixed === 1 ? '' : 's'} como correta${f.varFixed === 1 ? '' : 's'} pela avaliação)` : ''}.`);
  }
  if (f.pressureDecisions > 0) lines.push(`Sob pressão: ${f.pressureCorrect} de ${plural(f.pressureDecisions, 'decisão', 'decisões')} tomadas com o clima quente foram corretas.`);
  const top = ctx.report && ctx.report.recommendations && ctx.report.recommendations[0];
  if (top) lines.push(`Recomendação de treino: ${top.training}. ${top.reason}`);
  lines.push(`Efeito na carreira: +${sm.xpGain} XP e reputação ${sm.repDelta >= 0 ? '+' : '-'}${comma(Math.abs(sm.repDelta))}.`);
  return {
    key: `${ctx.matchId}:mail:report`,
    from: 'Supervisão de Arbitragem',
    category: 'avaliação',
    subject: `Relatório: ${ctx.home.name} x ${ctx.away.name}`,
    lines,
    matchId: ctx.matchId,
    fixtureId: ctx.fixtureId,
    date: { season: ctx.season, week: ctx.week },
  };
}

function matchEmails(career, ctx) {
  const date = { season: ctx.season, week: ctx.week };
  const sm = ctx.summary;
  const out = [reportEmail(career, ctx)];

  if (ctx.nota >= 9) {
    out.push({ key: `${ctx.matchId}:mail:recog`, from: 'Comitê de Arbitragem', category: 'reconhecimento', subject: 'Reconhecimento por desempenho', lines: [`Sua atuação em ${ctx.home.name} x ${ctx.away.name} recebeu nota ${comma(ctx.nota)}, uma das mais altas da competição. Parabéns.`], matchId: ctx.matchId, date });
  }
  for (const o of sm.objectivesDone) {
    const reward = [o.reward.xp ? `+${o.reward.xp} XP` : '', o.reward.rep ? `+${comma(o.reward.rep)} de reputação` : ''].filter(Boolean).join(' e ');
    out.push({ key: `mail:objective:${o.id}`, from: 'Comitê de Carreira', category: 'objetivo', subject: `Objetivo concluído: ${o.text}`, lines: [`Você concluiu o objetivo "${o.text}".`, reward ? `Recompensa recebida: ${reward}.` : 'Sem recompensa adicional.'], date });
  }
  if (sm.suspension) {
    out.push({ key: `${ctx.matchId}:mail:susp`, from: 'Comitê Disciplinar', category: 'disciplinar', subject: 'Oportunidades limitadas por uma rodada', lines: [`Motivo: ${sm.suspension}.`, 'Na próxima rodada você só receberá jogos de importância 1.', 'Isso não afeta sua nota, sua divisão nem sua experiência, e acaba depois de uma rodada.'], matchId: ctx.matchId, date });
  }
  for (const name of sm.newUnlocks) {
    const comp = COMPETITIONS.find((c) => c.name === name) || null;
    const need = comp ? unlockThreshold(comp, career.profile ? career.profile.region : null) : null;
    out.push({ key: `mail:unlock:${name}`, from: `Organização da ${name}`, category: 'convite', subject: `Convite: ${name}`, lines: [`Você está liberado para ser escalado na ${name}.`, need !== null ? `Requisito atendido: reputação de ${need} ou mais.` : 'Requisito de reputação atendido.', 'Os jogos aparecem nas convocações das próximas rodadas. Recusar não tem custo.'], date });
  }
  return out;
}

// ------------------------------------------------------------ rede social da partida
function matchPosts(career, ctx, rng) {
  const f = ctx.facts;
  const date = { season: ctx.season, week: ctx.week };
  const base = { competitionId: ctx.competitionId, fixtureId: ctx.fixtureId, matchId: ctx.matchId, date };
  const s = ctx.score;
  const score = `${s.home} x ${s.away}`;
  const posts = [];
  const likes = (lo, hi) => lo + Math.floor(rng.frac() * (hi - lo));
  const choose = (list) => list[Math.floor(rng.frac() * list.length)];
  const mk = (slot, author, kind, tag, text, extra = {}) => posts.push({ ...base, key: `${ctx.matchId}:post:${slot}`, author: { ...author, kind }, tag, text, likes: likes(8, 960), ...extra });

  // Perfil oficial da competição: só dados.
  mk('comp', { name: ctx.competition, handle: `@${ctx.competitionId}` }, 'oficial', 'dado oficial', `${ctx.competition}${ctx.stage ? ` · ${ctx.stage}` : ''}: ${ctx.home.name} ${score} ${ctx.away.name}.`);

  // Clubes: comunicados de cada lado.
  const homeWin = s.home > s.away;
  const awayWin = s.away > s.home;
  const clubText = (win, draw) => (win ? 'Vitória! Obrigado, torcida, pelo apoio em todo o jogo.' : draw ? 'Ponto conquistado. Seguimos trabalhando.' : 'Não foi dessa vez. Cabeça erguida e foco no próximo jogo.');
  mk('club-h', { name: ctx.home.name, handle: `@${ctx.home.id}` }, 'clube', 'comunicado do clube', `Fim de jogo: ${ctx.home.name} ${score} ${ctx.away.name}. ${clubText(homeWin, s.home === s.away)}`);
  mk('club-a', { name: ctx.away.name, handle: `@${ctx.away.id}` }, 'clube', 'comunicado do clube', `Fim de jogo: ${ctx.away.name} ${s.away} x ${s.home} ${ctx.home.name}. ${clubText(awayWin, s.home === s.away)}`);

  // Jornalista: avaliação técnica (dado), claramente separada de opinião.
  const j = choose(JOURNALISTS);
  mk('journalist', { name: `${j.name} (${j.outlet})`, handle: j.handle }, 'jornalista', 'análise', `Avaliação técnica da arbitragem de ${ctx.home.name} x ${ctx.away.name}: nota ${comma(ctx.nota)} (${ctx.label}), com ${f.correct} de ${f.decisions} decisões corretas.`, { technical: true });

  // Comentarista: debate a partir de fatos (cartões, pênaltis) ou do ritmo do jogo.
  const c = choose(COMMENTATORS);
  let cText;
  if (f.yellow + f.red > 0) {
    const parts = [f.yellow > 0 ? plural(f.yellow, 'amarelo', 'amarelos') : '', f.red > 0 ? plural(f.red, 'vermelho', 'vermelhos') : ''].filter(Boolean);
    cText = `${parts.join(' e ')} em ${ctx.home.name} x ${ctx.away.name}. Os cartões vieram na hora certa?`;
  }
  else if (f.penalties > 0) cText = `${plural(f.penalties, 'pênalti marcado', 'pênaltis marcados')} em ${ctx.home.name} x ${ctx.away.name}. Vamos debater o lance.`;
  else cText = f.decisions <= 6 ? `Jogo corrido em ${ctx.home.name} x ${ctx.away.name}, com poucas paralisações.` : `Muitos lances para o árbitro decidir em ${ctx.home.name} x ${ctx.away.name}: foram ${f.decisions} registros.`;
  mk('commentator', { name: `${c.name} (${c.outlet})`, handle: c.handle }, 'comentarista', 'opinião', cText, { technical: false });

  // VAR: dado oficial da competição e debate do comentarista, só se houve revisão.
  if (f.varReviews > 0) {
    mk('var-official', { name: ctx.competition, handle: `@${ctx.competitionId}` }, 'oficial', 'dado oficial', `VAR em ${ctx.home.name} x ${ctx.away.name}: ${plural(f.varReviews, 'revisão', 'revisões')}, ${plural(f.varChanged, 'decisão alterada', 'decisões alteradas')}.`);
    const cv = choose(COMMENTATORS);
    mk('var-debate', { name: `${cv.name} (${cv.outlet})`, handle: cv.handle }, 'comentarista', 'opinião', f.varChanged > 0 ? `O VAR mudou ${f.varChanged === 1 ? 'uma decisão' : 'decisões'} em ${ctx.home.name} x ${ctx.away.name}. Vale o debate.` : `O VAR foi consultado em ${ctx.home.name} x ${ctx.away.name} e a decisão do campo ficou. Concordam?`, { technical: false });
  }

  // Prints reais da partida (capturas da tela do jogo) com legenda feita só com os dados do lance.
  const clubOf = (team) => (team === 'home' ? ctx.home : ctx.away);
  const vs = `${ctx.home.name} x ${ctx.away.name}`;
  (ctx.shots || []).forEach((sh, i) => {
    if (!isShotImage(sh.image)) return;
    const image = { src: sh.image, alt: `Print do jogo aos ${sh.clock}`, kind: sh.kind };
    const slot = `shot${i}`;
    const at = `${sh.clock} do ${sh.period}º tempo`;
    const sc = sh.score ? `${ctx.home.name} ${sh.score.home} x ${sh.score.away} ${ctx.away.name}` : vs;
    if (sh.kind === 'goal') {
      const club = clubOf(sh.team);
      mk(slot, { name: club.name, handle: `@${club.id}` }, 'clube', 'comunicado do clube', `GOL! ${club.name} marca aos ${at}${sh.scorer ? ` com ${sh.scorer}` : ''}. ${sc}.`, { image });
    } else if (sh.kind === 'red') {
      mk(slot, { name: ctx.competition, handle: `@${ctx.competitionId}` }, 'oficial', 'dado oficial', `Cartão vermelho aos ${at}${sh.player ? ` para ${sh.player}` : ''} em ${vs}.`, { image });
    } else if (sh.kind === 'disallowed') {
      mk(slot, { name: ctx.competition, handle: `@${ctx.competitionId}` }, 'oficial', 'dado oficial', `Gol anulado aos ${at} em ${vs}.${sh.correct === true ? ' Avaliação técnica: decisão correta.' : sh.correct === false ? ' Avaliação técnica: decisão incorreta.' : ''}`, { image, technical: sh.correct !== null });
    } else if (sh.kind === 'var') {
      mk(slot, { name: ctx.competition, handle: `@${ctx.competitionId}` }, 'oficial', 'dado oficial', `Revisão do VAR aos ${at}: ${String(sh.label).toLowerCase()}, decisão ${sh.varKind === 'change' ? 'alterada' : 'mantida'}.${sh.correct === true ? ' Avaliação técnica: decisão final correta.' : sh.correct === false ? ' Avaliação técnica: decisão final incorreta.' : ''}`, { image, technical: sh.correct !== null });
    } else if (sh.correct === false) {
      const ja = choose(JOURNALISTS);
      mk(slot, { name: `${ja.name} (${ja.outlet})`, handle: ja.handle }, 'jornalista', 'análise', `Lance em discussão aos ${at} em ${vs} (${String(sh.label).toLowerCase()}). A avaliação técnica apontou: ${(sh.errors || []).join(', ')}.`, { image, technical: true });
    } else {
      const fa = choose(FANS);
      mk(slot, { name: fa.name, handle: fa.handle }, 'torcedor', 'opinião', `${sh.label} aos ${at} em ${vs}. Tem gente reclamando, mas a avaliação técnica considerou a decisão correta.`, { image, technical: false });
    }
  });

  // Condições do jogo: tempo e gramado, disputa de título ou de rebaixamento, retorno de lesão e minutos finais.
  const cd = ctx.conditions;
  if (cd) {
    const official = { name: ctx.competition, handle: `@${ctx.competitionId}` };
    if (cd.weather !== 'clear' && cd.weather !== 'cloudy' || cd.pitch !== 'good') {
      mk('cond-weather', official, 'oficial', 'dado oficial', `Jogo em ${vs} com ${cd.text.toLowerCase()}.`, { technical: false });
    }
    for (const st of cd.stories || []) {
      if (['title', 'relegation'].includes(st.id)) mk(`cond-${st.id}`, official, 'oficial', 'dado oficial', st.text, { technical: false });
    }
    if (cd.injuryReturn) {
      const r = cd.injuryReturn;
      const club = clubOf(r.team);
      mk('cond-return', { name: club.name, handle: `@${club.id}` }, 'clube', 'comunicado do clube', `${r.name} (#${r.number}) volta de lesão no jogo contra o ${clubOf(r.team === 'home' ? 'away' : 'home').name}.`, { technical: false });
      if (r.fouled > 0) {
        const fr = choose(FANS);
        mk('cond-return-fouled', { name: fr.name, handle: fr.handle }, 'torcedor', 'opinião', `${r.name} voltou de lesão e já sofreu ${r.fouled === 1 ? 'uma falta marcada' : `${r.fouled} faltas marcadas`}. O clube pede cuidado.`, { technical: false });
      }
    }
    if (cd.late) mk('cond-late', official, 'oficial', 'dado oficial', `${vs} foi decidido nos minutos finais, com o placar em aberto depois dos 80 minutos.`, { technical: false });
  }

  // Rixa em clássico: só quando os mesmos dois jogadores se envolveram em 2 ou mais lances reais do jogo.
  if (ctx.feud && ctx.rivalry) {
    const fd = ctx.feud;
    const fe = choose(FANS);
    mk('feud', { name: fe.name, handle: fe.handle }, 'torcedor', 'opinião', `${ctx.rivalry}: ${fd.a.name} (#${fd.a.number}) e ${fd.b.name} (#${fd.b.number}) se estranharam ${fd.count} vezes em ${vs}${fd.cards ? ` e o clima rendeu ${fd.cards === 1 ? 'um cartão' : `${fd.cards} cartões`}` : ''}.`, { technical: false });
  }

  // Decisão correta que a torcida da casa não gostou, e decisão errada que a favoreceu: opinião x avaliação técnica.
  if (f.unpopularCorrect > 0) {
    const fu = choose(FANS);
    mk('fan-unpopular', { name: fu.name, handle: fu.handle }, 'torcedor', 'opinião', `O apito foi contra o ${ctx.home.name} ${f.unpopularCorrect === 1 ? 'num lance' : `em ${f.unpopularCorrect} lances`} e a torcida não gostou. Mas a avaliação técnica considerou as decisões corretas.`, { technical: false });
  }
  if (f.popularWrong > 0) {
    const ja = choose(JOURNALISTS);
    mk('journalist-favor', { name: `${ja.name} (${ja.outlet})`, handle: ja.handle }, 'jornalista', 'análise', `A avaliação técnica apontou ${plural(f.popularWrong, 'decisão errada', 'decisões erradas')} em favor do ${ctx.home.name} em ${ctx.home.name} x ${ctx.away.name}. A torcida da casa não reclamou.`, { technical: true });
  }

  // Torcedores: opinião. A reclamação do torcedor não prova erro técnico (pode vir mesmo sem nenhum erro).
  const loser = homeWin ? ctx.away : awayWin ? ctx.home : ctx.away;
  const winnerClub = homeWin ? ctx.home : awayWin ? ctx.away : ctx.home;
  const clean = f.decisions - f.correct === 0 && ctx.graves === 0;
  const complains = rng.frac() < (clean ? 0.4 : 0.85);
  const fanL = choose(FANS);
  mk('fan-l', { name: fanL.name, handle: fanL.handle }, 'torcedor', 'opinião', complains ? choose([`Esse apito hoje não dá! ${loser.name} merecia mais.`, `O árbitro nos prejudicou em ${ctx.home.name} x ${ctx.away.name}, não aceito!`]) : choose(['Perdemos, mas a culpa não é só do apito. Segue o jogo.', 'Jogo duro. Foi o que foi, bola pra frente.']), { technical: false });
  if (homeWin || awayWin) {
    const fanW = choose(FANS.filter((x) => x.handle !== fanL.handle));
    mk('fan-w', { name: fanW.name, handle: fanW.handle }, 'torcedor', 'opinião', ctx.nota >= 6.5 ? choose([`Que jogo! ${winnerClub.name} venceu e a arbitragem foi tranquila.`, `Vitória do ${winnerClub.name}! Apito sem confusão hoje.`]) : `Ganhamos, mas a arbitragem foi confusa em ${ctx.home.name} x ${ctx.away.name}.`, { technical: false });
  }
  return posts;
}

// ------------------------------------------------------------ pacote de uma partida
// ctx: { matchId, fixtureId, competitionId, competition, stage, stadium, home:{id,name}, away:{id,name}, score, nota, label,
//        categories, mistakes, hits, facts, graves, summary, season, week, unlockIds? }
export function commsForMatch(career, ctx) {
  ensureComms(career);
  const rng = makeRng(hashString(`${career.seed}:comms:${ctx.matchId}`));
  return { news: matchNews(career, ctx, rng), emails: matchEmails(career, ctx), posts: matchPosts(career, ctx, rng) };
}

// ------------------------------------------------------------ fim de temporada
export function commsForSeason(career, ended) {
  ensureComms(career);
  const date = { season: ended.number, week: 99 };
  const rng = makeRng(hashString(`${career.seed}:comms:season:${ended.number}`));
  const d = ended.division;
  const news = [];
  const emails = [];
  const posts = [];

  // Campeões das competições que o árbitro acompanha (no máximo 3, as mais importantes).
  const champs = ended.champions
    .filter((c) => career.unlocked.includes(c.competitionId))
    .sort((a, b) => getCompetition(b.competitionId).importance - getCompetition(a.competitionId).importance || getCompetition(b.competitionId).tier - getCompetition(a.competitionId).tier)
    .slice(0, 3);
  for (const ch of champs) {
    const comp = getCompetition(ch.competitionId);
    const club = getClub(ch.clubId);
    news.push({ key: `season:${ended.number}:news:champ:${comp.id}`, category: 'competicao', tone: 'neutral', variant: 'champ', source: OUTLETS[Math.floor(rng.frac() * OUTLETS.length)], headline: `${club.name} é campeão da ${comp.name}`, summary: `Título da temporada ${ended.number}, decidido nos jogos registrados no calendário.`, competitionId: comp.id, date });
    posts.push({ key: `season:${ended.number}:post:champ:${comp.id}`, author: { name: comp.name, handle: `@${comp.id}`, kind: 'oficial' }, tag: 'dado oficial', text: `Campeão da ${comp.name}: ${club.name}!`, likes: 100 + Math.floor(rng.frac() * 800), competitionId: comp.id, date });
  }

  // Decisão do comitê (promoção, rebaixamento, aviso ou permanência).
  const subject = { promoted: `Promoção: você sobe para ${d.to}`, demoted: `Rebaixamento para ${d.to}`, warning: 'Aviso do comitê', stayed: `Temporada concluída: você segue em ${d.to}`, max: 'Temporada concluída na divisão máxima' }[d.action];
  const category = d.action === 'promoted' ? 'promoção' : d.action === 'demoted' || d.action === 'warning' ? 'disciplinar' : 'comunicado';
  const sum = [`Jogos apitados: ${ended.played}.`, ended.avg === null ? 'Sem média (nenhum jogo apitado).' : `Média das notas: ${comma(ended.avg)}.`, `Erros graves: ${ended.graves}.`, `Objetivos da temporada cumpridos: ${ended.met} de ${ended.objectives.length}.`, ended.eligible ? `Bônus de reputação: +${ended.repBonus}.` : 'Sem bônus de reputação (é preciso apitar 3 jogos ou mais).'];
  emails.push({ key: `season:${ended.number}:mail:decision`, from: 'Comitê de Arbitragem', category, subject, lines: [d.reason, ...sum], criteria: d.criteria, date });
  if (champs.length) emails.push({ key: `season:${ended.number}:mail:champions`, from: 'Comitê Organizador', category: 'comunicado', subject: `Campeões da temporada ${ended.number}`, lines: champs.map((ch) => `${getCompetition(ch.competitionId).name}: ${getClub(ch.clubId).name}`), date });

  const tone = d.action === 'promoted' ? 'positive' : d.action === 'demoted' ? 'negative' : d.action === 'warning' ? 'negative' : 'neutral';
  const headline = { promoted: `${career.name} é promovido para a ${d.to}`, demoted: `${career.name} é rebaixado para a ${d.to}`, warning: `Comitê emite aviso a ${career.name} após temporada abaixo do esperado`, stayed: `${career.name} segue na ${d.to} após a temporada ${ended.number}`, max: `${career.name} encerra a temporada ${ended.number} na divisão máxima` }[d.action];
  news.push({ key: `season:${ended.number}:news:decision`, category: 'carreira', tone, variant: `season-${d.action}`, source: OUTLETS[Math.floor(rng.frac() * OUTLETS.length)], headline, summary: d.reason, date });
  if (d.action === 'promoted' || d.action === 'demoted') posts.push({ key: `season:${ended.number}:post:decision`, author: { name: 'Comitê de Arbitragem', handle: '@comite_arbitragem', kind: 'oficial' }, tag: 'dado oficial', text: d.action === 'promoted' ? `${career.name} foi promovido para a ${d.to}.` : `${career.name} foi rebaixado para a ${d.to}.`, likes: 50 + Math.floor(rng.frac() * 400), date });
  // Retrospectiva da temporada: o que o jogo lembra do ano, com perfil e números reais.
  if (ended.retro) {
    const r = ended.retro;
    news.push({ key: `season:${ended.number}:news:retro`, category: 'carreira', tone: 'neutral', variant: `retro-${r.profile.id}`, source: OUTLETS[Math.floor(rng.frac() * OUTLETS.length)], headline: `Retrospectiva da temporada ${ended.number}: ${career.name} é ${r.profile.label.toLowerCase()}`, summary: r.lines.slice(0, 2).join(' '), date });
    emails.push({ key: `season:${ended.number}:mail:retro`, from: 'Comitê de Arbitragem', category: 'comunicado', subject: `Retrospectiva da temporada ${ended.number}: ${r.profile.label}`, lines: [r.profile.text, ...r.lines], date });
  }

  // Prêmios de temporada conquistados (só os que realmente foram concedidos).
  for (const a of ended.awards || []) {
    news.push({ key: `season:${ended.number}:news:award:${a.id}`, category: 'carreira', tone: 'positive', variant: `award-${a.id}`, source: OUTLETS[Math.floor(rng.frac() * OUTLETS.length)], headline: `${career.name} conquista o prêmio ${a.name}`, summary: `Critérios cumpridos na temporada ${ended.number}: ${a.detail}.`, date });
    emails.push({ key: `season:${ended.number}:mail:award:${a.id}`, from: 'Comitê de Arbitragem', category: 'reconhecimento', subject: `Prêmio: ${a.name}`, lines: [`Você conquistou o prêmio ${a.name} na temporada ${ended.number}.`, `Critérios: ${a.detail}.`, `Recompensa: +${a.xp} XP.`], date });
    posts.push({ key: `season:${ended.number}:post:award:${a.id}`, author: { name: 'Comitê de Arbitragem', handle: '@comite_arbitragem', kind: 'oficial' }, tag: 'dado oficial', text: `${career.name} é o vencedor do prêmio ${a.name} da temporada ${ended.number}.`, likes: 60 + Math.floor(rng.frac() * 300), date });
  }
  return { news, emails, posts };
}

// ------------------------------------------------------------ objetivos (fora de uma partida, ex.: ao passar rodadas)
export function commsForObjectives(career, done, date) {
  const emails = done.map((o) => ({
    key: `mail:objective:${o.id}`,
    from: 'Comitê de Carreira',
    category: 'objetivo',
    subject: `Objetivo concluído: ${o.text}`,
    lines: [`Você concluiu o objetivo "${o.text}".`, [o.reward.xp ? `Recompensa recebida: +${o.reward.xp} XP` : '', o.reward.rep ? `+${comma(o.reward.rep)} de reputação` : ''].filter(Boolean).join(' e ') || 'Sem recompensa adicional.'],
    date,
  }));
  return { news: [], emails, posts: [] };
}

// ------------------------------------------------------------ escala semanal (convocações)
// Um e-mail por rodada, atualizado no lugar quando as convocações mudam (ex.: suspensão). Os botões da interface
// usam sempre o estado real das convocações (world.offers), nunca uma cópia: não há como processar duas vezes.
export function syncWeekEmail(career) {
  if (!Array.isArray(career.inbox) || !career.world || !career.world.offers) return;
  ensureComms(career);
  const w = career.world;
  const key = `week:${w.season}:${w.week}`;
  const offers = w.offers.items
    .map((item) => {
      const fx = w.competitions && Object.values(w.competitions).flatMap((s) => s.fixtures).find((f) => f.id === item.fixtureId);
      if (!fx) return null;
      return { fixtureId: fx.id, tag: item.tag, competition: getCompetition(fx.competitionId).name, stage: fx.stage, home: getClub(fx.home).name, away: getClub(fx.away).name, stadium: fx.stadium, importance: fx.importance };
    })
    .filter(Boolean);
  const lines = [`Você foi escalado para a rodada ${w.week}. Escolha um dos jogos abaixo, recuse ou passe a rodada.`, 'Recusar ou passar a rodada não tem custo para sua reputação nem para sua experiência.'];
  if (w.offers.restriction) lines.push(`Atenção: oportunidades limitadas nesta rodada. Motivo: ${w.offers.restriction}.`);

  const existing = career.inbox.find((m) => m.key === key);
  if (existing) {
    existing.offers = offers;
    existing.lines = lines;
    return;
  }
  publish(career, { emails: [{ key, from: 'Escala de Arbitragem', category: 'convocação', subject: `Escala da rodada ${w.week}`, lines, offers, season: w.season, week: w.week }] }, { season: w.season, week: w.week });
}

export function welcomeEmail(career, migrated = false) {
  return {
    key: 'welcome',
    from: 'Comitê de Arbitragem',
    category: 'comunicado',
    subject: migrated ? 'Central de mensagens ativada' : `Bem-vindo, ${career.name}`,
    lines: migrated
      ? ['Sua carreira agora recebe notícias, e-mails e publicações da rede social a cada partida.', 'Tudo é gerado a partir do que realmente aconteceu nos seus jogos.']
      : ['Sua carreira começa na Copa Várzea Verde. A cada rodada você recebe uma escala com até 3 jogos.', 'Depois de cada partida chegam o relatório da supervisão, notícias e a repercussão na rede social.', 'Lembre-se: opinião de torcedor não é avaliação técnica. Sua nota vem das suas decisões.'],
    date: { season: career.season.number, week: career.world ? career.world.week : 1 },
  };
}
