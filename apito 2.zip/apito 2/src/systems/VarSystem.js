// VAR (Video Assistant Referee).
//
// Três responsabilidades:
//  1. Gravar a partida (VarRecorder) e guardar, para cada lance registrado, um retrato completo do estado do jogo
//     no instante em que ele aconteceu.
//  2. Conduzir a sessão de revisão: pausa, cursor de reprodução, velocidade, câmera e seleção de lances.
//  3. Aplicar uma decisão corrigida. O jogo volta ao instante do lance (placar, cartões, expulsões, posições, bola,
//     lances pendentes e súmula), a nova decisão segue o MESMO caminho de uma decisão normal e a partida continua
//     dali. Se algo falhar no meio, o estado anterior à correção é restaurado.
//
// O relógio da partida não é rebobinado (como no futebol real, o tempo da revisão não volta): a partida recomeça
// do lance com o relógio onde estava, e o tempo necessário para a cobrança é concedido como acréscimo.
import { INCIDENT, incidentLabel, describeIncident } from './MatchRules.js';
import { TEAMS } from '../config.js';
import { playerFull, playerLabel } from '../utils/labels.js';
import VarRecorder from './VarRecorder.js';

export const VAR_SPEEDS = [0.1, 0.25, 0.5, 1, 2];
export const VAR_CAMERAS = [
  { id: 'ball', label: 'Bola' },
  { id: 'incident', label: 'Lance' },
  { id: 'player', label: 'Jogador' },
  { id: 'referee', label: 'Árbitro' },
  { id: 'field', label: 'Campo' },
];
export const VAR_FILTERS = [
  { id: 'all', label: 'Todos' },
  { id: 'lances', label: 'Lances' },
  { id: 'gols', label: 'Gols' },
  { id: 'cartoes', label: 'Cartões' },
  { id: 'bola', label: 'Bola fora' },
];

const LEAD_MS = 5000; // quanto da jogada anterior ao lance é mostrado
const MIN_LEAD_MS = 2000;
const POST_MS = 2500; // quanto depois do lance a reprodução automática segue
const RESTART_MS = 15000; // tempo de jogo garantido para a cobrança depois de uma correção
const REVIEW_LOOKBACK_MS = 6000; // ao abrir o VAR, a reprodução começa tantos segundos antes do momento atual
const RELATED_MS = 20000; // lances considerados "construção" de um gol

const CARD_NAMES = { yellow: 'amarelo', red: 'vermelho', warning: 'advertência verbal' };
const RESTART_LABEL = {
  kickoff: 'Saída de bola',
  throw_in: 'Lateral',
  corner: 'Escanteio',
  goal_kick: 'Tiro de meta',
  free_kick: 'Tiro livre',
  indirect_free_kick: 'Tiro livre indireto',
  penalty: 'Cobrança de pênalti',
};
const OUT_OF_PLAY = ['throw_in', 'corner', 'goal_kick'];
const isOffsideType = (t) => t === INCIDENT.OFFSIDE || t === INCIDENT.LEGAL_POSITION;

// Lances em que a revisão faz sentido pelas regras do VAR: possível pênalti, vermelho direto ou impedimento (gol irregular).
export function isVarEligible(inc) {
  if (!inc) return false;
  if (inc.type === INCIDENT.PENALTY || isOffsideType(inc.type)) return true;
  const red = (inc.expected && inc.expected.card === 'red') || (inc.actual && inc.actual.cards && inc.actual.cards.some((c) => c.color === 'red'));
  return !!red;
}

// Texto curto de uma escolha (falta e cartões) para o histórico de auditoria.
export function describeChoice(inc, choice) {
  const c = choice || emptyChoice();
  const parts = [];
  if (c.foul) parts.push(isOffsideType(inc.type) ? 'Impedimento marcado' : inc.type === INCIDENT.PENALTY ? 'Pênalti marcado' : 'Falta marcada');
  else parts.push('Nada marcado (o jogo segue)');
  for (const who of ['offender', 'victim']) {
    const color = c.cards && c.cards[who];
    if (color) parts.push(`${CARD_NAMES[color] || color} para #${inc[who].number}`);
  }
  return parts.join(' · ');
}

export const emptyChoice = () => ({ foul: false, cards: { offender: null, victim: null } });
const norm = (c) => ({ foul: !!c.foul, cards: { offender: (c.cards && c.cards.offender) || null, victim: (c.cards && c.cards.victim) || null } });
export const sameChoice = (a, b) => {
  const x = norm(a);
  const y = norm(b);
  return x.foul === y.foul && x.cards.offender === y.cards.offender && x.cards.victim === y.cards.victim;
};

export default class VarSystem {
  constructor(events, sim, decisions) {
    this.events = events;
    this.sim = sim;
    this.decisions = decisions;
    this.rec = new VarRecorder({ ball: sim.ball, referee: sim.referee, players: sim.allPlayers });

    this.active = false;
    this.cursor = 0;
    this.playing = false;
    this.speed = 1;
    this.camera = 'ball';
    this.selectedId = null;
    this.stopAt = null;
    this.deciding = null; // lance que o árbitro ainda está decidindo quando chamou o VAR
    this.infos = new Map(); // id do lance -> { incident, snapshot, eventId, status, original, decision }
    this.stats = { reviews: 0, kept: 0, changed: 0 };
    this.audit = []; // histórico auditável: uma linha por decisão revista (mantida ou alterada)

    events.on('incident-registered', (inc) => this.onIncident(inc));
    events.on('decision-result', (entry) => this.onDecisionResult(entry));
    events.on('goal', (g) => this.onGoal(g));
    events.on('card', (c) => this.onCard(c));
    events.on('setpiece-start', (s) => this.onRestart(s));
    events.on('whistle', () => this.mark('whistle', 'outros', 'Apito', 'O árbitro apita', sim.referee.x, sim.referee.y));
    events.on('halftime', () => this.mark('period', 'outros', 'Intervalo', 'Fim do 1º tempo', sim.ball.x, sim.ball.y));
  }

  // ---- Gravação -------------------------------------------------------------------------------------------------

  beforeStep(delta) {
    this.rec.tick(Math.min(delta, 50));
  }

  afterStep() {
    this.rec.capture(this.sim);
  }

  mark(type, category, label, detail, x, y, extra = {}) {
    const clock = this.sim.getClock();
    return this.rec.mark(type, { category, label, detail, x, y, clock: clock.text, period: this.sim.period, ...extra });
  }

  onIncident(inc) {
    // O retrato é tirado no instante do registro, antes de qualquer decisão do árbitro.
    const snapshot = { sim: this.sim.captureState(), dec: this.decisions.captureState() };
    const ev = this.mark('incident', 'lances', incidentLabel(inc), describeIncident(inc), inc.x, inc.y, {
      team: inc.offender.team,
      incidentId: inc.id,
      decision: 'Sem decisão (o jogo seguiu)',
    });
    this.infos.set(inc.id, {
      incident: inc,
      snapshot,
      eventId: ev.id,
      status: 'live',
      original: emptyChoice(),
      decision: 'Sem decisão (o jogo seguiu)',
    });
  }

  onDecisionResult(entry) {
    const info = this.infos.get(entry.incidentId);
    if (!info) return;
    const inc = info.incident;
    const cards = { offender: null, victim: null };
    for (const c of entry.actual.cards) {
      if (c.team === inc.offender.team && c.number === inc.offender.number) cards.offender = c.color;
      else if (c.team === inc.victim.team && c.number === inc.victim.number) cards.victim = c.color;
    }
    info.original = { foul: !!entry.actual.foulCalled, cards };
    info.decision = this.describeDecision(entry, inc);
    const ev = this.eventById(info.eventId);
    if (ev) ev.decision = info.decision;
  }

  describeDecision(entry, inc) {
    const a = entry.actual;
    const parts = [];
    if (a.foulCalled) parts.push(isOffsideType(inc.type) ? 'Impedimento marcado' : inc.type === INCIDENT.PENALTY ? 'Pênalti marcado' : 'Falta marcada');
    else if (a.advantage === 'success' || a.advantage === 'implicit') parts.push('Vantagem: o jogo seguiu');
    else parts.push('O jogo seguiu (nada marcado)');
    for (const c of a.cards) parts.push(`cartão ${CARD_NAMES[c.color] || c.color} para #${c.number} ${c.name || ''}`.trim());
    return parts.join(' · ');
  }

  onGoal({ team, scorer }) {
    const b = this.sim.ball;
    this.mark('goal', 'gols', 'Gol', `${TEAMS[team].name} marca${scorer ? ` (${playerLabel(scorer)})` : ''}`, b.x, b.y, { team });
  }

  onCard({ color, effective, player, secondYellow, incident }) {
    const label = secondYellow ? 'Segundo amarelo (vermelho)' : `Cartão ${effective === 'red' ? 'vermelho' : 'amarelo'}`;
    this.mark('card', 'cartoes', label, playerFull(player), player.x, player.y, { team: player.team, incidentId: incident ? incident.id : null, color });
  }

  onRestart({ type, team, x, y }) {
    this.mark('restart', OUT_OF_PLAY.includes(type) ? 'bola' : 'outros', RESTART_LABEL[type] || 'Reinício', `Para ${TEAMS[team].name}`, x, y, { team, kind: type });
  }

  eventById(id) {
    return this.rec.events.find((e) => e.id === id) || null;
  }

  infoOf(incidentId) {
    return this.infos.get(incidentId) || null;
  }

  // Acontecimentos para a lista do painel, do mais recente ao mais antigo.
  eventList(filter = 'all') {
    const out = [];
    for (let i = this.rec.events.length - 1; i >= 0; i--) {
      const ev = this.rec.events[i];
      if (filter === 'all' || ev.category === filter) out.push(ev);
    }
    return out;
  }

  // ---- Sessão de revisão ----------------------------------------------------------------------------------------

  canOpen() {
    if (this.active) return { ok: false, reason: '' };
    const sim = this.sim;
    if (sim.finished || (sim.state === 'stopped' && sim.stopReason === 'fulltime')) return { ok: false, reason: 'A partida terminou: o VAR não está mais disponível' };
    if (this.rec.length < 2) return { ok: false, reason: 'Ainda não há lances gravados' };
    return { ok: true, reason: '' };
  }

  // Pausa a partida e abre a revisão, já reproduzindo os últimos segundos de jogo.
  open({ incident = null } = {}) {
    const can = this.canOpen();
    if (!can.ok) return can;
    this.deciding = incident;
    this.rec.capture(this.sim, { force: true });
    this.active = true;
    this.stats.reviews += 1;
    this.selectedId = null;
    this.speed = 1;
    this.camera = 'ball';
    this.cursor = Math.max(0, this.rec.end - REVIEW_LOOKBACK_MS);
    this.playing = true;
    this.stopAt = this.rec.end;
    const info = incident ? this.infos.get(incident.id) : null;
    if (info) {
      this.camera = 'incident';
      this.selectEvent(info.eventId);
    }
    this.events.emit('var-open', { time: this.sim.time });
    return { ok: true, reason: '' };
  }

  // Encerra a revisão e devolve a partida exatamente de onde parou (se nada foi alterado).
  close() {
    if (!this.active) return;
    this.active = false;
    this.playing = false;
    this.stopAt = null;
    this.deciding = null;
    this.events.emit('var-close', { time: this.sim.time });
  }

  update(deltaMs) {
    if (!this.active || !this.playing) return;
    this.cursor += Math.min(deltaMs, 100) * this.speed;
    const end = this.rec.end;
    if (this.stopAt !== null && this.cursor >= this.stopAt) {
      this.cursor = Math.min(this.stopAt, end);
      this.playing = false;
      this.stopAt = null;
    } else if (this.cursor >= end) {
      this.cursor = end;
      this.playing = false;
      this.stopAt = null;
    }
  }

  // ---- Controles de reprodução ----------------------------------------------------------------------------------

  seek(t) {
    this.cursor = Math.max(0, Math.min(this.rec.end, t));
    this.stopAt = null;
  }

  step(ms) {
    this.playing = false;
    this.seek(this.cursor + ms);
  }

  togglePlay() {
    if (this.playing) {
      this.playing = false;
      this.stopAt = null;
      return;
    }
    if (this.cursor >= this.rec.end - 1) this.cursor = Math.max(0, this.rec.end - REVIEW_LOOKBACK_MS);
    this.stopAt = null;
    this.playing = true;
  }

  setSpeed(v) {
    if (VAR_SPEEDS.includes(v)) this.speed = v;
  }

  cycleSpeed(dir) {
    const i = VAR_SPEEDS.indexOf(this.speed);
    this.speed = VAR_SPEEDS[Math.max(0, Math.min(VAR_SPEEDS.length - 1, i + dir))];
  }

  setCamera(id) {
    if (VAR_CAMERAS.some((c) => c.id === id)) this.camera = id;
  }

  // Começo da jogada que leva ao instante rt: alguns segundos antes, sem passar do último reinício de jogo.
  startOfPlay(rt) {
    const boundary = this.rec.lastBoundary(rt, ['restart', 'period']);
    const bound = boundary === null ? 0 : Math.min(boundary, rt - MIN_LEAD_MS);
    return Math.max(0, rt - LEAD_MS, bound);
  }

  selectedEvent() {
    return this.selectedId === null ? null : this.eventById(this.selectedId);
  }

  // Seleciona um acontecimento da lista e reproduz a jogada, parando logo depois do lance.
  selectEvent(id) {
    const ev = this.eventById(id);
    if (!ev) return null;
    this.selectedId = id;
    this.cursor = this.startOfPlay(ev.rt);
    this.stopAt = Math.min(this.rec.end, ev.rt + POST_MS);
    this.playing = true;
    return ev;
  }

  // Volta ao início da jogada (do lance selecionado ou do ponto em que a reprodução está).
  jumpToPlayStart() {
    const ref = this.selectedEvent();
    this.cursor = this.startOfPlay(ref ? ref.rt : this.cursor);
    this.stopAt = null;
  }

  // Repete a jogada desde o início.
  replay() {
    const ref = this.selectedEvent();
    this.cursor = this.startOfPlay(ref ? ref.rt : this.cursor);
    this.stopAt = ref ? Math.min(this.rec.end, ref.rt + POST_MS) : Math.min(this.rec.end, this.cursor + LEAD_MS + POST_MS);
    this.playing = true;
  }

  // Instante atual da reprodução (já interpolado) e o relógio da partida correspondente.
  current() {
    return this.rec.sample(this.cursor);
  }

  clockAtCursor() {
    const v = this.current();
    return this.sim.clockAt(v.matchMs, v.period);
  }

  isCursorVoided() {
    return this.rec.isVoided(this.cursor);
  }

  // ---- Decisões -------------------------------------------------------------------------------------------------

  // Lances da construção de um gol (até RELATED_MS antes), no mesmo tempo de jogo.
  relatedTo(ev) {
    return this.rec.events.filter((e) => e.type === 'incident' && !e.annulled && e.period === ev.period && e.rt <= ev.rt && ev.rt - e.rt <= RELATED_MS);
  }

  // Dados do acontecimento selecionado para o painel.
  detail() {
    const ev = this.selectedEvent();
    if (!ev) return null;
    const info = ev.incidentId ? this.infos.get(ev.incidentId) : null;
    return {
      event: ev,
      info,
      canAlter: info ? this.canAlter(info.incident.id) : { ok: false, reason: 'Este acontecimento é automático (regra do jogo): só pode ser revisto.' },
      related: ev.type === 'goal' ? this.relatedTo(ev) : [],
    };
  }

  canAlter(incidentId) {
    const info = this.infos.get(incidentId);
    if (!info) return { ok: false, reason: 'Este momento não é um lance decidido pelo árbitro.' };
    if (info.status === 'void') return { ok: false, reason: 'Este lance foi desfeito por uma revisão anterior.' };
    if (this.sim.finished) return { ok: false, reason: 'A partida terminou.' };
    if (this.decisions.isDeciding()) {
      const current = this.decisions.stoppage && this.decisions.stoppage.incident;
      return { ok: false, reason: current === info.incident ? 'Este lance ainda aguarda a sua decisão: volte ao painel e decida (falta, impedimento ou seguir).' : 'Termine a decisão em andamento antes de alterar outros lances.' };
    }
    if (info.incident.period !== this.sim.period) return { ok: false, reason: 'Só é possível alterar decisões do tempo de jogo atual (você ainda pode assistir ao lance).' };
    return { ok: true, reason: '' };
  }

  // Descreve o que será desfeito se o jogo voltar ao instante do lance.
  consequences(incidentId) {
    const info = this.infos.get(incidentId);
    if (!info) return [];
    const ev = this.eventById(info.eventId);
    const out = [];
    for (const e of this.rec.events) {
      if (e.annulled || e.rt <= ev.rt) continue;
      if (e.type === 'goal') out.push(`Gol: ${e.detail} (${e.clock})`);
      else if (e.type === 'card') out.push(`${e.label}: ${e.detail} (${e.clock})`);
      else if (e.type === 'incident' && e.incidentId !== incidentId && e.decision && !e.decision.startsWith('Sem decisão')) {
        out.push(`${e.label} (${e.clock}): ${e.decision}`);
      }
    }
    return out;
  }

  // Registra a revisão no histórico de auditoria (decisão inicial, final e motivo).
  record(incidentId, kind, finalChoice, initialChoice) {
    const info = this.infos.get(incidentId);
    if (!info) return;
    const inc = info.incident;
    const ev = this.eventById(info.eventId);
    const initial = describeChoice(inc, initialChoice || info.original);
    const final = describeChoice(inc, finalChoice || initialChoice || info.original);
    this.audit.push({
      id: this.audit.length + 1,
      incidentId,
      incidentType: inc.type,
      label: incidentLabel(inc),
      clock: ev ? ev.clock : inc.clock,
      period: inc.period,
      eligible: isVarEligible(inc),
      kind, // 'keep' | 'change'
      initial,
      final,
      reason: kind === 'keep' ? 'Revisão concluída: decisão inicial mantida.' : `Decisão corrigida na revisão: de "${initial}" para "${final}".`,
    });
  }

  keepDecision(incidentId) {
    this.record(incidentId, 'keep');
    this.stats.kept += 1;
    this.events.emit('var-decision', { kind: 'keep', incidentId });
    return { ok: true, changed: false };
  }

  captureAll() {
    return { sim: this.sim.captureState(), dec: this.decisions.captureState() };
  }

  restoreAll(snap) {
    this.sim.restoreState(snap.sim);
    return this.decisions.restoreState(snap.dec);
  }

  // Altera a decisão de um lance. Devolve { ok, changed, reason? }.
  alterDecision(incidentId, choice) {
    const can = this.canAlter(incidentId);
    if (!can.ok) return { ok: false, changed: false, reason: can.reason };
    const info = this.infos.get(incidentId);
    const initialChoice = { foul: info.original.foul, cards: { ...info.original.cards } };
    if (sameChoice(info.original, choice)) return { ...this.keepDecision(incidentId), changed: false };

    const safety = this.captureAll();
    const ev = this.eventById(info.eventId);
    const nowRt = this.rec.rt;
    try {
      const annulled = [...this.infos.values()].filter((i) => i.incident.id > incidentId && i.status === 'live');
      const restored = this.restoreAll(info.snapshot);

      // A linha do tempo posterior ao lance deixa de valer (continua visível no VAR, marcada como anulada).
      this.rec.voidSegment(ev.rt, nowRt);
      for (const i of annulled) i.status = 'void';
      for (const inc of restored) {
        const i = this.infos.get(inc.id);
        if (i && i.incident.id !== incidentId) {
          i.original = emptyChoice();
          i.decision = 'Sem decisão (o jogo seguiu)';
          const e = this.eventById(i.eventId);
          if (e) e.decision = i.decision;
        }
      }

      this.sim.stopPlay('var');
      this.sim.ensureRestartTime(RESTART_MS);
      this.events.emit('var-rollback', { annulledIds: annulled.map((i) => i.incident.id), restored });
      this.decisions.applyReviewDecision(info.incident, norm(choice));
      this.rec.cutBranch(this.sim);

      this.stats.changed += 1;
      this.record(incidentId, 'change', norm(choice), initialChoice);
      this.events.emit('var-decision', { kind: 'change', incidentId });
      return { ok: true, changed: true };
    } catch (err) {
      this.restoreAll(safety);
      return { ok: false, changed: false, reason: `Não foi possível aplicar a correção (${err && err.message ? err.message : err}). O jogo foi mantido como estava.` };
    }
  }
}
