// Perfis de jogador (Upgrade 1): o árbitro reconhece o perfil pelo que o jogador FAZ na partida, não por um rótulo.
// Funções puras. A tendência a reclamar (`dissentTrait`) vem de um hash do jogador, então é sempre a mesma para a mesma
// pessoa e não mexe no sorteio da simulação. O painel só mostra o perfil depois de comportamentos observados.
import { makeRng, hashString } from '../utils/rng.js';
import { PERSISTENT_FOULS } from './MatchRules.js';

// 0,1 (calmo) a 0,9 (reclama muito). Fixo por jogador: time, número e nome.
export function dissentTrait(p) {
  return 0.1 + 0.8 * makeRng(hashString(`dissent:${p.team}:${p.number}:${p.name}`)).frac();
}

// Perfil observado e aviso de cartão perto, para o botão Informação do painel.
export function profileTags(p) {
  const tags = [];
  if ((p.suspectFalls || 0) >= 2) tags.push('costuma cair em lances duvidosos');
  if ((p.protests || 0) >= 2) tags.push('reclama muito');
  if ((p.foulsCommitted || 0) >= PERSISTENT_FOULS) tags.push('reincidente em faltas');
  if ((p.warnings || 0) >= 1) tags.push('já foi advertido');
  return tags;
}

// Quanto falta para o cartão: amarelo já visto, ou a próxima falta leve que vira amarelo por reincidência.
export function bookingEdge(p) {
  if ((p.yellowCards || 0) >= 1) return 'já tem amarelo: o próximo é vermelho';
  if ((p.foulsCommitted || 0) >= PERSISTENT_FOULS) return 'na beira do amarelo: a próxima falta já vale cartão';
  return '';
}
