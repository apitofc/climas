// Equipe de arbitragem (Upgrade 3): dois assistentes e o quarto árbitro. Funções puras e determinísticas.
//
// Regras de projeto:
//  - O jogador continua sendo o árbitro principal e a única decisão que vale é a dele; a equipe dá INFORMAÇÃO (bandeira,
//    opinião, ajuda com o banco), às vezes errada. A confiabilidade de cada membro é mostrada ao jogador.
//  - A nota continua avaliando só a decisão final. Seguir um conselho errado conta como erro; ignorar um conselho certo e
//    acertar por conta própria não custa nada.
//  - Tudo é determinístico: a mesma partida, o mesmo lance e o mesmo número de consulta dão sempre a mesma resposta (por
//    isso a revisão do VAR e o recarregar o jogo não mudam o que a equipe viu).
import { makeRng, hashString } from '../utils/rng.js';
import { FIRST, LAST } from '../data/names.js';
import { INCIDENT } from './MatchRules.js';
import { FIELD_RECT } from '../config.js';

const L = FIELD_RECT;
export const MAX_CONSULTS = 3; // consultas ao assistente por partida (cada uma para o jogo um pouco mais)
export const MAX_BENCH_CALLS = 2; // pedidos de ajuda ao quarto árbitro por partida
export const VIEW_ZONE = 70; // px da linha lateral em que o assistente tem boa visão de uma falta
export const CONSULT_COST = 2; // tensão extra: o jogo fica parado mais tempo
export const BENCH_WINDOW_MS = 6000;

export const CREW_ROLES = {
  a1: { label: 'Assistente 1', detail: 'linha lateral de cima: impedimentos, faltas perto da linha e bola fora' },
  a2: { label: 'Assistente 2', detail: 'linha lateral de baixo: impedimentos, faltas perto da linha e bola fora' },
  fo: { label: 'Quarto árbitro', detail: 'área técnica: acalma os bancos e cuida do controle técnico' },
};
export const CREW_IDS = ['a1', 'a2', 'fo'];

// Confiabilidade pela experiência (0 a 100): de 62% a 92%.
export const reliability = (exp) => 0.62 + 0.3 * Math.min(100, Math.max(0, exp)) / 100;
// Chance de a comunicação falhar (o assistente hesita e não dá opinião): de 30% (sem entrosamento) a 0% (100).
export const divergenceChance = (chemistry) => 0.3 * (1 - Math.min(100, Math.max(0, chemistry)) / 100);
export const communicationLabel = (chemistry) => (chemistry >= 70 ? 'Boa' : chemistry >= 40 ? 'Regular' : 'Divergente');
export const confidenceLabel = (acc) => (acc >= 0.85 ? 'alta' : acc >= 0.72 ? 'média' : 'baixa');

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

// Equipe nova: nomes e experiência saem da semente da carreira; a experiência já considera os jogos apitados.
export function generateCrew(seed, totalMatches = 0) {
  const rng = makeRng(hashString(`crew:${seed}`));
  const used = new Set();
  const members = {};
  for (const id of CREW_IDS) {
    let name;
    do name = `${FIRST[Math.floor(rng.frac() * FIRST.length)]} ${LAST[Math.floor(rng.frac() * LAST.length)]}`;
    while (used.has(name));
    used.add(name);
    members[id] = { id, name, exp: Math.min(100, Math.round(18 + rng.frac() * 20 + totalMatches * 3)) };
  }
  return { members, chemistry: Math.min(100, 20 + totalMatches * 3), matches: 0, stats: emptyStats() };
}

export const emptyStats = () => ({ consults: 0, followedRight: 0, followedWrong: 0, ignoredRight: 0, divergences: 0, flagsRaised: 0, flagsWrong: 0, benchCalls: 0, benchOk: 0 });

export function ensureCrew(career) {
  if (!career.crew || typeof career.crew !== 'object' || !career.crew.members) career.crew = generateCrew(career.seed, career.totalMatches || 0);
  const c = career.crew;
  for (const id of CREW_IDS) if (!c.members[id]) c.members[id] = generateCrew(`${career.seed}:${id}`, career.totalMatches || 0).members[id];
  if (!Number.isFinite(c.chemistry)) c.chemistry = 30;
  if (!Number.isFinite(c.matches)) c.matches = 0;
  c.stats = { ...emptyStats(), ...(c.stats || {}) };
  return c;
}

const assistantFor = (y) => (y < L.cy ? 'a1' : 'a2');
const distToTouchline = (y) => Math.min(Math.abs(y - L.top), Math.abs(y - L.bottom));
const isOffsideKind = (inc) => inc.type === INCIDENT.OFFSIDE || inc.type === INCIDENT.LEGAL_POSITION;

// Bandeira do assistente num lance de posição: levanta (quase) sempre num impedimento real, e às vezes erra e levanta
// sem impedimento. Só existe nos lances de impedimento.
export function flagFor(crew, incident, seed) {
  if (!isOffsideKind(incident)) return null;
  const who = assistantFor(incident.y ?? L.cy);
  const m = crew.members[who];
  const rel = reliability(m.exp);
  const truth = incident.type === INCIDENT.OFFSIDE;
  const rng = makeRng(hashString(`${seed}:${incident.id}:flag`));
  const raised = truth ? rng.frac() < rel : rng.frac() < (1 - rel) * 0.5;
  return { who, name: m.name, raised, truth, wrong: raised !== truth };
}

// Dá para consultar? Impedimento sempre (o assistente está na linha); faltas só perto da linha lateral dele; no máximo
// MAX_CONSULTS por partida.
export function consultOptions(incident, used) {
  if (used >= MAX_CONSULTS) return { available: false, reason: `limite de ${MAX_CONSULTS} consultas por partida` };
  const y = incident.y ?? L.cy;
  const near = distToTouchline(y) <= VIEW_ZONE;
  if (isOffsideKind(incident) || near) return { available: true, who: assistantFor(y), near: near || isOffsideKind(incident) };
  return { available: false, reason: 'lance longe da linha lateral: os assistentes não viram bem' };
}

// Opinião do assistente. Acerta com probabilidade (confiabilidade, mais visão); com comunicação ruim ele hesita e não dá
// opinião. n é o número da consulta na partida (para a resposta ser sempre a mesma).
export function consult(crew, incident, n, seed) {
  const opt = consultOptions(incident, 0);
  const who = opt.who || assistantFor(incident.y ?? L.cy);
  const m = crew.members[who];
  const view = opt.near ? 1 : 0.8;
  const accuracy = clamp(reliability(m.exp) * view + 0.05, 0.5, 0.97);
  const rng = makeRng(hashString(`${seed}:${incident.id}:consult:${n}`));
  const divergent = rng.frac() < divergenceChance(crew.chemistry);
  const truth = !!(incident.expected && incident.expected.foul);
  const right = rng.frac() < accuracy;
  const foul = divergent ? null : right ? truth : !truth;
  const kind = isOffsideKind(incident) ? 'impedimento' : 'falta';
  const text = divergent
    ? `${m.name} hesita e a comunicação falha: sem opinião clara.`
    : `${m.name} (confiança ${confidenceLabel(accuracy)}): ${foul ? `viu ${kind}` : `não viu ${kind}`}.`;
  return { who, name: m.name, divergent, foul, accuracy, truth, correct: foul === null ? null : foul === truth, text };
}

// Quarto árbitro acalma o banco: chance de 50% a 90% pela experiência dele.
export function benchCalm(crew, team, n, seed) {
  const fo = crew.members.fo;
  const chance = 0.5 + 0.4 * Math.min(100, fo.exp) / 100;
  const rng = makeRng(hashString(`${seed}:bench:${team}:${n}`));
  return { name: fo.name, chance, ok: rng.frac() < chance };
}

// Depois da partida: experiência, entrosamento e estatísticas. info = { consults: [{ followed, correct, divergent, who }],
// flagsRaised, flagsWrong, bench: { calls, ok } }. Idempotente por partida (applyMatch descarta repetidas).
export function crewMatchUpdate(career, info) {
  const c = ensureCrew(career);
  const st = c.stats;
  const consults = info.consults || [];
  const rightFollowed = consults.filter((x) => x.followed && x.correct === true);
  const wrongFollowed = consults.filter((x) => x.followed && x.correct === false);
  for (const id of CREW_IDS) c.members[id].exp = Math.min(100, c.members[id].exp + 6);
  for (const x of rightFollowed) c.members[x.who].exp = Math.min(100, c.members[x.who].exp + 2); // conselho bom e seguido fortalece a confiança
  c.chemistry = Math.min(100, c.chemistry + 3 + (consults.length && !wrongFollowed.length ? 2 : 0));
  c.matches += 1;
  st.consults += consults.length;
  st.followedRight += rightFollowed.length;
  st.followedWrong += wrongFollowed.length;
  st.ignoredRight += consults.filter((x) => !x.followed && x.correct === true).length;
  st.divergences += consults.filter((x) => x.divergent).length;
  st.flagsRaised += info.flagsRaised || 0;
  st.flagsWrong += info.flagsWrong || 0;
  st.benchCalls += (info.bench && info.bench.calls) || 0;
  st.benchOk += (info.bench && info.bench.ok) || 0;
  return c;
}
