import MatchMood, { TENSION_HIGH, isLateDrama } from './MatchMood.js';
import { dissentTrait } from './PlayerProfiles.js';
import { makeRng, hashString } from '../utils/rng.js';
import { flagFor, consultOptions as crewOptions, consult as crewConsult, benchCalm, MAX_BENCH_CALLS, CONSULT_COST, BENCH_WINDOW_MS } from './CrewSystem.js';
import {
  INCIDENT,
  INCIDENT_LABEL,
  CALL_RANGE,
  INCIDENT_WINDOW_MS,
  ADVANTAGE_MS,
  IMMEDIATE_FEEDBACK,
  ERROR_MESSAGES,
  errorText,
  evaluateDecision,
  incidentLabel,
  GOAL_CHECK,
  GOAL_CHECK_S,
  GOAL_CAUSE_WINDOW_MS,
  GOAL_CAUSE_TYPES,
} from './MatchRules.js';
import { playerFull } from '../utils/labels.js';

const NO_INCIDENT_STOP_MS = 1500;
const CARD_ANIM_MS = 1800;
const DECISION_ANIM_MS = 600;

const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);

export default class RefereeDecisionSystem {
  constructor(events, sim) {
    this.events = events;
    this.sim = sim;

    this.nextId = 1;
    this.pending = [];
    this.log = [];
    this.stoppage = null;
    this.cards = { home: { yellow: 0, red: 0 }, away: { yellow: 0, red: 0 } };
    this.mood = new MatchMood(); // tensão, calor dos times e humor da torcida (Upgrade 2)
    this.windowMul = { foul: 1, offside: 1 }; // treino: tempo extra para apitar
    // Equipe de arbitragem (Upgrade 3): bandeira, consultas ao assistente e ajuda do quarto árbitro.
    this.crew = null;
    this.crewSeed = '';
    this.crewLog = { consults: [], flagsRaised: 0, flagsWrong: 0, bench: { calls: 0, ok: 0 } };
    this.flagged = new Set();
    // Reclamação (Upgrade 1): depois de uma falta marcada, um jogador de perfil reclamão pode protestar e o árbitro decide.
    this.dissent = null;
    this.dissentCount = 0;
    this.lastDissentTime = -Infinity;
    this.benchWindow = { team: null, until: 0 };
    this.crowdAlert = false;
    this.lastBench = { home: -Infinity, away: -Infinity };

    // Conferência de gol: gol que veio de falta ou impedimento de quem marcou pode ser anulado pelo árbitro (tecla G),
    // com ou sem VAR. goalCheck só existe durante a pausa depois do gol.
    this.goalCheck = null;
    this.playStartedAt = 0;
    events.on('play-resumed', (e) => (this.playStartedAt = e.time));
    events.on('goal', (g) => this.onGoal(g));

    events.on('incident', (incident) => this.register(incident));
  }

  // Dados da equipe neste lance (bandeira e consulta) para a súmula, a nota explicada e a carreira.
  crewEntry(inc) {
    const flag = inc.crewFlag ? { who: inc.crewFlag.who, raised: inc.crewFlag.raised, wrong: inc.crewFlag.wrong } : null;
    let consult = null;
    if (inc.consult) {
      const followed = inc.consult.foul !== null && inc.actual.foulCalled === inc.consult.foul;
      consult = { who: inc.consult.who, foul: inc.consult.foul, correct: inc.consult.correct, divergent: inc.consult.divergent, followed };
      const rec = this.crewLog.consults.find((c) => c.incidentId === inc.id);
      if (rec) rec.followed = followed;
    }
    return flag || consult ? { flag, consult } : null;
  }

  setCrew(crew, seed) {
    this.crew = crew;
    this.crewSeed = String(seed);
  }

  // Dá para consultar o assistente neste lance? (impedimento sempre; faltas só perto da linha lateral; no máximo 3 por jogo)
  consultOptions(incident) {
    if (!this.crew) return { available: false, reason: 'sem equipe de arbitragem' };
    if (incident.consult) return { available: false, done: true, reason: 'você já consultou neste lance' };
    return crewOptions(incident, this.crewLog.consults.length);
  }

  consult(incident) {
    if (!this.consultOptions(incident).available) return incident.consult || null;
    const n = this.crewLog.consults.length;
    const res = crewConsult(this.crew, incident, n, this.crewSeed);
    incident.consult = res;
    this.crewLog.consults.push({ incidentId: incident.id, who: res.who, divergent: res.divergent, foul: res.foul, correct: res.correct, followed: null });
    this.mood.add(CONSULT_COST); // o jogo fica parado mais um pouco e os jogadores esquentam
    this.events.emit('crew-consult', res);
    return res;
  }

  // Quarto árbitro acalma o banco que acabou de reclamar (tecla B, por até 6 s depois da reclamação).
  callFourth() {
    if (!this.crew) return false;
    const w = this.benchWindow;
    if (!w.team || this.sim.time > w.until) {
      this.feedback('info', 'Nenhum banco está reclamando agora.');
      return false;
    }
    if (this.crewLog.bench.calls >= MAX_BENCH_CALLS) {
      this.feedback('info', `O quarto árbitro já ajudou ${MAX_BENCH_CALLS} vezes neste jogo.`);
      return false;
    }
    const team = w.team;
    const res = benchCalm(this.crew, team, this.crewLog.bench.calls, this.crewSeed);
    this.crewLog.bench.calls += 1;
    this.benchWindow = { team: null, until: 0 };
    if (res.ok) {
      this.crewLog.bench.ok += 1;
      this.mood.heatUp(team, -10);
      this.mood.add(-4);
      this.feedback('good', `${res.name} (quarto árbitro) acalmou o banco.`);
    } else this.feedback('bad', `${res.name} (quarto árbitro) não conseguiu acalmar o banco.`);
    this.events.emit('crew-bench', { team, ok: res.ok });
    return res.ok;
  }

  // Resumo para o resultado e a carreira.
  crewSummary() {
    return { consults: this.crewLog.consults.map((c) => ({ ...c })), flagsRaised: this.crewLog.flagsRaised, flagsWrong: this.crewLog.flagsWrong, bench: { ...this.crewLog.bench } };
  }

  setTraining(eff) {
    this.windowMul = { foul: eff.foulWindowMul, offside: eff.offsideWindowMul };
    this.mood.setTraining({ decayMul: eff.tensionDecayMul, errorMul: eff.errorTensionMul });
  }

  // ---- Conferência de gol -----------------------------------------------------------------------------------------

  // Falta ou impedimento da equipe que marcou, não apitado, no trecho de jogo corrido que levou ao gol.
  findGoalCause(team) {
    const sim = this.sim;
    const from = Math.max(this.playStartedAt, sim.time - GOAL_CAUSE_WINDOW_MS);
    const plain = (p) => ({ team: p.team, number: p.number, name: p.name });
    const cands = [];
    for (const inc of this.pending) {
      if (inc.status === 'pending') cands.push(inc);
    }
    for (const e of this.log) {
      if (e.incidentId !== null && e.period === sim.period) cands.push(e);
    }
    let best = null;
    for (const c of cands) {
      const ok = c.expected && c.expected.foul && GOAL_CAUSE_TYPES.includes(c.type) && c.offender.team === team && !c.actual.foulCalled && c.time >= from && c.time <= sim.time;
      if (ok && (!best || c.time > best.time)) best = c;
    }
    if (!best) return null;
    return { incidentId: best.incidentId ?? best.id, type: best.type, time: best.time, clock: best.clock, x: best.x, y: best.y, offender: plain(best.offender), victim: plain(best.victim) };
  }

  onGoal({ team, scorer }) {
    const sim = this.sim;
    this.goalCheck = { team, scorer: scorer || null, clock: sim.getClock().text, period: sim.period, time: sim.time, cause: this.findGoalCause(team) };
    // Pausa um pouco maior para dar tempo de decidir (a comemoração continua igual).
    sim.goalTimer = Math.max(sim.goalTimer, GOAL_CHECK_S);
  }

  isGoalCheckOpen() {
    const sim = this.sim;
    return !!(this.goalCheck && sim.state === 'stopped' && sim.stopReason === 'goal');
  }

  // O árbitro anula o gol (tecla G). Vale com ou sem infração: anular um gol válido é erro e é avaliado como tal.
  annulGoal() {
    if (!this.isGoalCheckOpen()) return false;
    const gc = this.goalCheck;
    if (!this.sim.disallowGoal(gc.team, gc.cause)) return false;
    this.closeGoalCheck(true);
    return true;
  }

  // Fim da pausa do gol sem anulação: o gol é confirmado. Só vira registro (erro) se havia infração.
  update_goalCheck() {
    if (this.goalCheck && !this.isGoalCheckOpen()) this.closeGoalCheck(false);
  }

  closeGoalCheck(annulled) {
    const gc = this.goalCheck;
    this.goalCheck = null;
    if (!gc) return;
    const irregular = !!gc.cause;
    // Gol normal confirmado: nada a avaliar (não infla a nota com acertos fáceis).
    if (!irregular && !annulled) return;

    const stub = (team) => ({ team, number: '—', name: 'equipe' });
    const scorer = gc.scorer ? { team: gc.scorer.team, number: gc.scorer.number, name: gc.scorer.name } : stub(gc.team);
    const offender = gc.cause ? gc.cause.offender : scorer;
    const victim = gc.cause ? gc.cause.victim : stub(gc.team === 'home' ? 'away' : 'home');
    const kind = gc.cause ? { light_foul: 'falta leve', serious_foul: 'falta grave', penalty: 'falta na área', offside: 'impedimento' }[gc.cause.type] : null;
    const incident = {
      expected: { foul: irregular, card: null, restart: gc.cause ? (gc.cause.type === 'offside' ? 'indirect_free_kick' : 'free_kick') : null, cardTarget: null, advantageAllowed: false },
      actual: { foulCalled: annulled, cards: [], advantage: null, decided: true },
      offender,
      victim,
    };
    const result = evaluateDecision(incident);
    const entry = {
      incidentId: null,
      type: GOAL_CHECK,
      level: 'none',
      time: gc.time,
      clock: gc.clock,
      period: gc.period,
      x: gc.cause ? gc.cause.x : null,
      y: gc.cause ? gc.cause.y : null,
      refDistance: null,
      evidence: gc.cause ? [`${kind} de ${playerFull(offender)} no lance do gol`, `infração aos ${gc.cause.clock}`] : ['nenhuma falta nem impedimento no lance do gol'],
      offender,
      victim,
      expected: incident.expected,
      actual: incident.actual,
      errors: result.errors,
      notes: result.notes,
      correct: result.correct,
      varChanged: false,
      cause: gc.cause ? { incidentId: gc.cause.incidentId, type: gc.cause.type } : null,
    };
    this.mood.onDecision(entry);
    this.log.push(entry);
    this.events.emit('goal-decision', entry);
    if (!IMMEDIATE_FEEDBACK) return;
    if (result.errors.length) this.feedback('bad', `Gol: ${result.errors.map((c) => errorText(c, GOAL_CHECK)).join(', ')}\n(${entry.evidence.join(', ')})`);
    else this.feedback('good', 'Gol anulado corretamente!');
  }

  register(incident) {
    incident.id = this.nextId++;
    incident.status = 'pending';
    // Leitura de faltas e Impedimentos (treino) dão um pouco mais de tempo para apitar. Só o tempo: a resposta certa não muda.
    const offsideLike = incident.type === INCIDENT.OFFSIDE || incident.type === INCIDENT.LEGAL_POSITION;
    const foulLike = [INCIDENT.LIGHT_FOUL, INCIDENT.SERIOUS_FOUL, INCIDENT.PENALTY].includes(incident.type);
    const mul = offsideLike ? this.windowMul.offside : foulLike ? this.windowMul.foul : 1;
    incident.expiresAt = incident.time + INCIDENT_WINDOW_MS[incident.type] * mul;
    incident.advantageUntil = null;
    incident.actual = { foulCalled: false, cards: [], advantage: null, decided: false };
    // Bandeira do assistente nos lances de impedimento (informação, às vezes errada).
    incident.crewFlag = this.crew ? flagFor(this.crew, incident, this.crewSeed) : null;
    if (incident.crewFlag && incident.crewFlag.raised) {
      if (!this.flagged.has(incident.id)) {
        this.flagged.add(incident.id);
        this.crewLog.flagsRaised += 1;
        if (incident.crewFlag.wrong) this.crewLog.flagsWrong += 1;
      }
      this.events.emit('crew-flag', { who: incident.crewFlag.who, name: incident.crewFlag.name, y: incident.y });
    }
    this.pending.push(incident);
    this.events.emit('incident-registered', incident);
  }

  nearest() {
    const ref = this.sim.referee;
    let best = null;
    let bd = CALL_RANGE;
    for (const inc of this.pending) {
      if (inc.status !== 'pending') continue;
      const d = dist(ref.x, ref.y, inc.x, inc.y);
      if (d <= bd) {
        bd = d;
        best = inc;
      }
    }
    return best;
  }

  isDeciding() {
    return !!(this.stoppage && this.stoppage.reason === 'decision');
  }

  whistle() {
    const sim = this.sim;
    if (sim.state === 'playing') {
      const inc = this.nearest();
      sim.stopPlay('whistle');
      this.events.emit('whistle', { time: sim.time });
      if (inc) {
        this.openDecision(inc, false);
      } else {
        this.stoppage = {
          reason: 'whistle',
          timer: NO_INCIDENT_STOP_MS,
          incident: null,
          whistleTime: sim.time,
          clock: sim.getClock().text,
          period: sim.period,
        };
        this.feedback('info', 'Apito sem lance');
      }
    } else if (sim.state === 'stopped' && this.stoppage && this.stoppage.reason === 'whistle') {
      this.endStoppage();
    }
  }

  openDecision(inc, forceFoul) {
    inc.status = 'called';
    this.stoppage = { reason: 'decision', timer: Infinity, incident: inc, forceFoul };
    this.events.emit('decision-needed', { incident: inc, forceFoul });
  }

  // ---- VAR ------------------------------------------------------------------------------------------------------

  captureState() {
    return {
      cards: JSON.parse(JSON.stringify(this.cards)),
      logLength: this.log.length,
      mood: this.mood.capture(),
      crewConsults: this.crewLog.consults.length,
      dissentCount: this.dissentCount,
      lastDissentTime: this.lastDissentTime,
      stoppage: this.stoppage ? { ...this.stoppage } : null,
      pending: this.pending.map((inc) => ({
        inc,
        status: inc.status,
        expiresAt: inc.expiresAt,
        advantageUntil: inc.advantageUntil,
        actual: { ...inc.actual, cards: [...inc.actual.cards] },
      })),
    };
  }

  // Volta ao estado capturado: cartões, súmula e lances pendentes. Devolve os lances que voltaram a ficar pendentes.
  restoreState(s) {
    this.goalCheck = null; // a revisão do VAR volta no tempo: a conferência de gol daquele instante deixa de valer
    for (const id of ['home', 'away']) Object.assign(this.cards[id], s.cards[id]);
    this.log.length = s.logLength;
    if (s.mood) this.mood.restore(s.mood);
    this.dissent = null; // a revisão do VAR volta no tempo: a reclamação daquele instante deixa de valer
    if (s.dissentCount !== undefined) {
      this.dissentCount = s.dissentCount;
      this.lastDissentTime = s.lastDissentTime;
    }
    if (s.crewConsults !== undefined) this.crewLog.consults.length = Math.min(this.crewLog.consults.length, s.crewConsults);
    this.stoppage = s.stoppage ? { ...s.stoppage } : null;
    this.pending = s.pending.map((e) => {
      e.inc.status = e.status;
      e.inc.expiresAt = e.expiresAt;
      e.inc.advantageUntil = e.advantageUntil;
      e.inc.actual = { ...e.actual, cards: [...e.actual.cards] };
      return e.inc;
    });
    return [...this.pending];
  }

  // Aplica a decisão tomada na revisão do VAR (o estado já foi restaurado para o instante do lance).
  // Segue o mesmo caminho de uma decisão normal: cartões, tiro livre/pênalti/bola ao chão e nota.
  applyReviewDecision(inc, choice) {
    inc.varChanged = true;
    inc.status = 'called';
    this.stoppage = { reason: 'decision', timer: Infinity, incident: inc, forceFoul: false };
    this.resolveDecision(choice);
  }

  resolveDecision(choice) {
    const s = this.stoppage;
    if (!s || s.reason !== 'decision') return;
    const inc = s.incident;

    inc.actual.decided = true;
    inc.actual.foulCalled = !!choice.foul || !!s.forceFoul;

    let shownCard = false;
    for (const who of ['offender', 'victim']) {
      const color = choice.cards?.[who];
      if (!color) continue;
      if (color !== 'warning') shownCard = true;
      this.applyCard(inc, inc[who], color);
    }

    this.stoppage = { reason: 'resolved', timer: shownCard ? CARD_ANIM_MS : DECISION_ANIM_MS, incident: inc };
    this.maybeDissent(inc);

    // Jogadores reclamam (efeito visual): quem foi punido, ou quem sofreu a falta que não foi marcada.
    if (this.sim.protest) {
      if (inc.actual.foulCalled) this.sim.protest(inc.offender.team, inc.x, inc.y);
      else if (inc.expected.foul) this.sim.protest(inc.victim.team, inc.x, inc.y);
    }
  }

  // ---- Reclamação -----------------------------------------------------------------------------------------------------

  isDissentOpen() {
    return !!this.dissent;
  }

  // Depois de uma falta marcada, um jogador da equipe punida com perfil reclamão pode protestar (no máximo 2 por jogo e
  // uma a cada 60 s). O sorteio é determinístico por lance (a revisão do VAR e o recarregar não mudam).
  maybeDissent(inc) {
    const sim = this.sim;
    if (!inc.actual.foulCalled || this.dissent || this.dissentCount >= 2 || sim.time - this.lastDissentTime < 60000) return;
    const cands = sim.players
      .filter((p) => p.team === inc.offender.team && p.role !== 'GK' && !p.sentOff && dissentTrait(p) >= 0.6)
      .sort((a, b) => dissentTrait(b) - dissentTrait(a));
    const p = cands[0];
    if (!p) return;
    const trait = dissentTrait(p);
    const chance = Math.min(0.5, trait * 0.14 + this.mood.tension / 600);
    const rng = makeRng(hashString(`${this.crewSeed || 'd'}:${inc.id}:dissent`));
    if (rng.frac() >= chance) return;

    const strong = p.protests >= 1 || p.warnings >= 1 || this.mood.tension >= 50 || trait >= 0.8;
    const evidence = strong
      ? ['gestos exagerados', 'grita com o árbitro', ...(p.warnings >= 1 ? ['já foi advertido neste jogo'] : []), ...(p.protests >= 2 ? [`reclamação persistente (${p.protests + 1}ª vez)`] : []), ...(this.mood.tension >= 50 ? ['clima quente'] : [])]
      : ['reclamação com palavras', 'tom controlado', 'primeira reclamação do jogador'];
    this.dissentCount += 1;
    this.lastDissentTime = sim.time;
    p.protests += 1;
    this.dissent = { player: p, victim: inc.victim, level: strong ? 'strong' : 'mild', evidence, time: sim.time, clock: sim.getClock().text, period: sim.period, x: inc.x, y: inc.y };
    this.events.emit('dissent-open', { player: p, level: this.dissent.level });
  }

  // Escolha do árbitro: 'ignore', 'warning' (advertência verbal) ou 'yellow'.
  resolveDissent(choice) {
    const d = this.dissent;
    if (!d || !['ignore', 'warning', 'yellow'].includes(choice)) return;
    this.dissent = null;
    const errors = [];
    if (d.level === 'mild') {
      if (choice === 'yellow') errors.push('CARD_UNWARRANTED');
    } else if (choice === 'warning') errors.push('CARD_TOO_LIGHT');
    else if (choice === 'ignore') errors.push('CARD_MISSED');

    const pseudo = { actual: { cards: [], foulCalled: false } };
    if (choice === 'warning') {
      d.player.warnings += 1;
      this.applyCard(pseudo, d.player, 'warning');
    } else if (choice === 'yellow') this.applyCard(pseudo, d.player, 'yellow');

    const plain = (p) => ({ team: p.team, number: p.number, name: p.name });
    const entry = {
      incidentId: null,
      type: 'dissent',
      level: 'none',
      time: d.time,
      clock: d.clock,
      period: d.period,
      x: d.x,
      y: d.y,
      refDistance: null,
      evidence: d.evidence,
      offender: plain(d.player),
      victim: plain(d.victim),
      expected: { foul: false, card: d.level === 'strong' ? 'yellow' : null, cardTarget: 'offender', advantageAllowed: false },
      actual: { foulCalled: false, cards: pseudo.actual.cards.map((c) => ({ team: c.player.team, number: c.player.number, name: c.player.name, color: c.color })), advantage: null, decided: true },
      errors,
      notes: [],
      correct: errors.length === 0,
      varChanged: false,
      dissent: { level: d.level, choice },
    };
    this.mood.onDecision(entry);
    this.log.push(entry);
    this.events.emit('dissent-result', entry);
    const lbl = `${playerFull(d.player)}`;
    if (errors.length) this.feedback('bad', `Reclamação de ${lbl}: ${errors.map((c) => errorText(c, 'dissent')).join(', ')}`);
    else this.feedback('good', choice === 'yellow' ? 'Reclamação punida com amarelo, certo!' : 'Reclamação resolvida, certo!');
  }

  applyCard(inc, target, color) {
    inc.actual.cards.push({ player: target, color });
    if (color === 'warning') {
      this.feedback('info', `Advertência verbal: ${playerFull(target)}`);
      return;
    }

    let effective = color;
    let secondYellow = false;
    if (color === 'yellow') {
      target.yellowCards += 1;
      if (target.yellowCards >= 2) {
        effective = 'red';
        secondYellow = true;
      }
    }
    if (effective === 'yellow') this.changePosture(target);
    this.cards[target.team][effective] += 1;
    this.events.emit('card', { color, effective, player: target, secondYellow, incident: inc });
    if (effective === 'red') this.sim.sendOff(target);
  }

  // O amarelo muda a postura do jogador: com o clima calmo ele fica mais cauteloso; com o clima quente, mais exaltado.
  changePosture(p) {
    const heated = this.mood.tension >= TENSION_HIGH;
    p.aggression = Math.max(0.05, Math.min(0.95, p.aggression + (heated ? 0.1 : -0.2)));
    this.feedback('info', `${playerFull(p)} fica ${heated ? 'mais exaltado' : 'mais cauteloso'} depois do amarelo`);
  }

  signalAdvantage() {
    const sim = this.sim;
    if (sim.state !== 'playing') return;
    const inc = this.nearest();
    if (!inc || inc.type !== INCIDENT.LIGHT_FOUL || inc.actual.advantage) {
      this.feedback('info', 'Vantagem só em falta leve');
      return;
    }
    inc.actual.advantage = 'pending';
    inc.advantageUntil = sim.time + ADVANTAGE_MS;
    this.events.emit('advantage', { incident: inc });
    this.feedback('info', 'Vantagem!');
  }

  update(delta) {
    const ms = Math.min(delta, 50);
    const sim = this.sim;

    if (sim.state === 'playing') {
      this.mood.update(ms);
      // Minutos finais decisivos: o clima não esfria enquanto o jogo estiver em aberto (Upgrade 4).
      const late = isLateDrama(sim.getClock().text, sim.score) && sim.period >= 2;
      if (this.mood.setLate(late)) this.events.emit('late-drama', { clock: sim.getClock().text, score: { ...sim.score } });
      // Pressão da torcida da casa: quando está muito irritada, o clima esquenta mais um pouco (no máximo 3 vezes).
      if (this.mood.crowd <= -45 && !this.crowdAlert && this.mood.counts.crowdPressure < 3) {
        this.crowdAlert = true;
        this.mood.counts.crowdPressure += 1;
        this.mood.add(4);
        this.events.emit('crowd-pressure', {});
      } else if (this.mood.crowd > -25) this.crowdAlert = false;
    }
    sim.heat = this.mood.heats();

    if (sim.state !== 'playing') {
      for (const inc of this.pending) {
        inc.expiresAt += ms;
        if (inc.advantageUntil !== null) inc.advantageUntil += ms;
      }
    }

    this.update_goalCheck();

    if (this.dissent && sim.finished) this.dissent = null;
    if (this.stoppage && !this.dissent) {
      this.stoppage.timer -= ms;
      if (this.stoppage.timer <= 0) this.endStoppage();
    }

    if (sim.state !== 'playing') return;
    const now = sim.time;
    for (const inc of [...this.pending]) {
      if (inc.status !== 'pending') continue;
      if (inc.actual.advantage === 'pending') {
        if (now >= inc.advantageUntil) this.resolveAdvantage(inc);
      } else if (now >= inc.expiresAt) {
        this.resolveIgnored(inc);
      }
    }
  }

  resolveAdvantage(inc) {
    const retained = this.sim.ball.lastTouchTeam === inc.victim.team;
    if (retained) {
      inc.actual.advantage = 'success';
      this.finalize(inc);
      return;
    }

    inc.actual.advantage = 'failed';
    this.sim.stopPlay('advantage');
    this.events.emit('whistle', { time: this.sim.time });
    this.feedback('info', 'Vantagem não se confirmou: falta!');
    this.openDecision(inc, true);
  }

  resolveIgnored(inc) {
    if (inc.type === INCIDENT.LIGHT_FOUL && this.sim.ball.lastTouchTeam === inc.victim.team) {
      inc.actual.advantage = 'implicit';
    }
    this.finalize(inc);
  }

  closeAll() {
    for (const inc of [...this.pending]) {
      if (inc.status !== 'pending') continue;
      if (inc.actual.advantage === 'pending') {
        const retained = this.sim.ball.lastTouchTeam === inc.victim.team;
        inc.actual.advantage = retained ? 'success' : 'failed';
        if (!retained) inc.actual.foulCalled = true;
        this.finalize(inc);
      } else {
        this.resolveIgnored(inc);
      }
    }
  }

  endStoppage() {
    const s = this.stoppage;
    this.stoppage = null;
    const sim = this.sim;
    if (!s || s.reason === 'decision') return;
    const inc = s.incident;

    // Apito sem lance próximo.
    if (!inc) {
      const whistle = {
        incidentId: null,
        type: 'unnecessary_whistle',
        time: s.whistleTime ?? sim.time,
        clock: s.clock ?? sim.getClock().text,
        period: s.period ?? sim.period,
        errors: ['WHISTLE_UNNECESSARY'],
        notes: [],
        correct: false,
      };
      this.mood.onDecision(whistle);
      this.log.push(whistle);
      this.feedback('bad', `Apito sem lance: ${ERROR_MESSAGES.WHISTLE_UNNECESSARY}`);
      sim.resumeDrop();
      return;
    }

    this.finalize(inc);

    const diverCarded = inc.actual.cards.some((c) => c.player === inc.victim && c.color !== 'warning');
    if (inc.actual.foulCalled) {
      const indirect = inc.type === INCIDENT.OFFSIDE || inc.type === INCIDENT.LEGAL_POSITION;
      const type = inc.type === INCIDENT.PENALTY ? 'penalty' : indirect ? 'indirect_free_kick' : 'free_kick';
      sim.startSetPiece(type, inc.victim.team, inc.x, inc.y);
    } else if (inc.type === INCIDENT.SIMULATION && diverCarded) {
      const other = inc.victim.team === 'home' ? 'away' : 'home';
      sim.startSetPiece('indirect_free_kick', other, inc.x, inc.y);
    } else {
      sim.resumeDrop();
    }
  }

  finalize(inc) {
    if (inc.status === 'resolved') return;
    inc.status = 'resolved';
    this.pending = this.pending.filter((p) => p !== inc);

    // Falta marcada conta para a reincidência do jogador (o contador também volta junto com o VAR).
    if (inc.actual.foulCalled && [INCIDENT.LIGHT_FOUL, INCIDENT.SERIOUS_FOUL, INCIDENT.PENALTY].includes(inc.type)) inc.offender.foulsCommitted = (inc.offender.foulsCommitted || 0) + 1;

    const result = evaluateDecision(inc);
    const entry = {
      incidentId: inc.id,
      type: inc.type,
      subtype: inc.subtype || null,
      persistent: !!inc.persistent,
      level: inc.level,
      time: inc.time,
      clock: inc.clock,
      period: inc.period,
      x: inc.x,
      y: inc.y,
      refDistance: inc.refDistance,
      evidence: inc.evidence,
      offender: { team: inc.offender.team, number: inc.offender.number, name: inc.offender.name },
      victim: { team: inc.victim.team, number: inc.victim.number, name: inc.victim.name },
      expected: inc.expected,
      actual: {
        foulCalled: inc.actual.foulCalled,
        cards: inc.actual.cards.map((c) => ({ team: c.player.team, number: c.player.number, name: c.player.name, color: c.color })),
        advantage: inc.actual.advantage,
        decided: inc.actual.decided,
      },
      errors: result.errors,
      notes: result.notes,
      correct: result.correct,
      varChanged: !!inc.varChanged,
      crew: this.crewEntry(inc),
    };
    const { crossedHot } = this.mood.onDecision(entry);
    // Comissão técnica: falta real ignorada com o clima esquentando faz o banco do time prejudicado reclamar.
    if (entry.errors.includes('FOUL_MISSED') && this.mood.tension >= 40 && entry.victim && this.sim.time - this.lastBench[entry.victim.team] > 30000) {
      this.lastBench[entry.victim.team] = this.sim.time;
      this.mood.counts.benchProtests += 1;
      this.mood.heatUp(entry.victim.team, 6);
      this.benchWindow = { team: entry.victim.team, until: this.sim.time + BENCH_WINDOW_MS };
      this.events.emit('bench-protest', { team: entry.victim.team });
    }
    this.log.push(entry);
    this.events.emit('decision-result', entry);
    if (crossedHot) this.feedback('info', 'O clima esquentou: jogadores e bancos reclamam');

    if (!IMMEDIATE_FEEDBACK) return;
    const label = incidentLabel(inc);
    if (result.errors.length) {
      const msgs = result.errors.map((c) => errorText(c, inc.type)).join(', ');
      this.feedback('bad', `${label}: ${msgs}\n(${inc.evidence.join(', ')})`);
    } else if (inc.actual.decided || inc.actual.advantage === 'success') {
      this.feedback('good', `${label}: decisão correta!`);
    }
  }

  feedback(kind, text) {
    this.events.emit('feedback', { kind, text });
  }

  getPrompt() {
    const sim = this.sim;
    if (sim.state === 'setpiece' || this.isDeciding()) return '';
    if (this.isGoalCheckOpen()) return 'GOL!  Espaço anula o gol';
    if (this.stoppage && this.stoppage.reason === 'whistle') return 'JOGO PARADO  Espaço retoma';
    if (sim.state === 'playing' && this.nearest()) return 'LANCE!  Espaço apita  V vantagem';
    return '';
  }
}