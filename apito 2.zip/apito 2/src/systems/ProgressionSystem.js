// Progressão da carreira: reputação, promoção, rebaixamento, suspensão e objetivos de carreira.
// Funções puras, sem Phaser nem navegador. Não calcula nota: usa a nota final já avaliada (RefereeGrading).
//
// Papéis distintos:
//   avaliação técnica = a nota da partida (0 a 10), calculada a partir das decisões;
//   experiência (XP)  = prática acumulada; define o nível e o título;
//   reputação (0-100) = confiança do comitê; libera copas e é um requisito para subir de divisão.
import { COMPETITIONS } from '../data/competitions.js';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const round1 = (v) => Math.round(v * 10) / 10;
const comma = (n) => String(round1(n)).replace('.', ',');
const signed = (n) => (n >= 0 ? `+${comma(n)}` : `-${comma(Math.abs(n))}`);

// Escada de divisões: as ligas, da menor para a maior. Só as ligas contam como divisão.
export const LEAGUES = COMPETITIONS.filter((c) => c.division).sort((a, b) => a.tier - b.tier);

export const PROMOTION = { minMatches: 3, maxGraves: 3, minObjectives: 2, xpBonus: 100 };
export const DEMOTION = { poorAvg: 5.0, goodAvg: 6.0, strikesToDemote: 2, repPenalty: 5 };
export const GRAVE_SEVERITY = 3; // erro "grave" = gravidade 3 ou mais na lista de erros da partida

// ------------------------------------------------------------ reputação e experiência
// Reputação: nota acima de 6 sobe, abaixo desce, multiplicado pela importância do jogo. Cada erro grave custa 0,5
// (até 3). A perda tem teto por partida: uma partida ruim isolada não apaga a progressão.
export function repBreakdown(nota, importance, graves) {
  const raw = (nota - 6) * 0.8 * importance;
  const base = clamp(raw, -4, 5);
  const penalty = Math.min(3, graves * 0.5);
  const delta = round1(clamp(base - penalty, -5, 5));
  const lines = [`Nota ${comma(nota)} (referência 6,0) com importância ${importance}: ${signed(round1(base))}${raw !== base ? ' (limite por partida)' : ''}`];
  if (penalty > 0) lines.push(`${graves} erro(s) grave(s): ${signed(-penalty)}`);
  return { delta, lines };
}

export function xpBreakdown(nota, importance) {
  const mult = 1 + 0.25 * (importance - 1);
  const xp = Math.round((10 + Math.max(0, nota - 3) * 14) * mult);
  return { xp, line: `Nota ${comma(nota)} rende ${xp} XP${importance > 1 ? ` (importância ${importance}: ×${comma(mult)})` : ''}` };
}

// Suspensão de oportunidades: por uma rodada, só jogos de importância 1. Nunca bloqueia a progressão.
export function suspensionFor({ graves, nota, previousNota }) {
  if (graves >= 4) return `${graves} erros graves na última partida`;
  if (nota < 4 && previousNota !== undefined && previousNota < 4) return 'duas partidas seguidas com nota abaixo de 4,0';
  return null;
}

// ------------------------------------------------------------ promoção e rebaixamento
export function seasonStats(season) {
  const ms = season.matches;
  const played = ms.length;
  return {
    played,
    avg: played ? ms.reduce((a, m) => a + m.nota, 0) / played : null,
    graves: ms.reduce((a, m) => a + (m.graves || 0), 0),
    whistles: ms.reduce((a, m) => a + (m.whistles || 0), 0),
  };
}

// Requisitos explícitos para subir de divisão (mostrados ao jogador durante e no fim da temporada).
export function promotionCriteria({ division, rep }, stats, objectivesMet, avgTarget) {
  if (division >= LEAGUES.length - 1) return { isMax: true, next: null, criteria: [], allMet: false };
  const next = LEAGUES[division + 1];
  const criteria = [
    { id: 'rep', ok: rep >= next.unlockRep, text: `Reputação de ${next.unlockRep} ou mais`, detail: `você tem ${comma(rep)}` },
    { id: 'avg', ok: stats.played > 0 && stats.avg >= avgTarget, text: `Média da temporada de ${comma(avgTarget)} ou mais`, detail: stats.played ? `sua média: ${comma(stats.avg)}` : 'sem jogos ainda' },
    { id: 'played', ok: stats.played >= PROMOTION.minMatches, text: `Pelo menos ${PROMOTION.minMatches} jogos apitados`, detail: `${stats.played} jogo(s)` },
    { id: 'graves', ok: stats.graves <= PROMOTION.maxGraves, text: `No máximo ${PROMOTION.maxGraves} erros graves`, detail: `${stats.graves} erro(s) grave(s)` },
    { id: 'objectives', ok: objectivesMet >= PROMOTION.minObjectives, text: `Pelo menos ${PROMOTION.minObjectives} objetivos da temporada`, detail: `${objectivesMet} cumprido(s)` },
  ];
  return { isMax: false, next, criteria, allMet: criteria.every((c) => c.ok) };
}

// Decisão de fim de temporada. Rebaixamento só acontece após duas temporadas seguidas com média abaixo de 5,0
// (uma temporada fraca gera apenas um aviso), e nunca abaixo da divisão mais baixa.
export function decideSeason({ division, rep, strikes }, stats, objectivesMet, avgTarget) {
  const promo = promotionCriteria({ division, rep }, stats, objectivesMet, avgTarget);
  const current = LEAGUES[division];
  const out = { action: 'stayed', from: current.name, to: current.name, division, strikes, repPenalty: 0, xpBonus: 0, criteria: promo.criteria, reason: '' };

  if (promo.allMet) {
    out.action = 'promoted';
    out.division = division + 1;
    out.to = promo.next.name;
    out.strikes = 0;
    out.xpBonus = PROMOTION.xpBonus;
    out.reason = `Promovido para ${promo.next.name}: todos os requisitos foram atendidos.`;
    return out;
  }

  const enough = stats.played >= PROMOTION.minMatches;
  const poor = enough && stats.avg < DEMOTION.poorAvg;
  out.strikes = poor ? strikes + 1 : enough && stats.avg >= DEMOTION.goodAvg ? 0 : strikes;

  if (poor && out.strikes >= DEMOTION.strikesToDemote && division > 0) {
    out.action = 'demoted';
    out.division = division - 1;
    out.to = LEAGUES[division - 1].name;
    out.strikes = 0;
    out.repPenalty = DEMOTION.repPenalty;
    out.reason = `Rebaixado para ${out.to}: segunda temporada seguida com média abaixo de ${comma(DEMOTION.poorAvg)}. Reputação ${signed(-DEMOTION.repPenalty)}.`;
  } else if (poor) {
    out.action = 'warning';
    out.reason =
      division === 0
        ? `Média abaixo de ${comma(DEMOTION.poorAvg)}. Na divisão mais baixa não há rebaixamento, mas é hora de melhorar.`
        : `Média abaixo de ${comma(DEMOTION.poorAvg)}: aviso ${out.strikes} de ${DEMOTION.strikesToDemote}. Outra temporada assim leva ao rebaixamento.`;
  } else if (promo.isMax) {
    out.action = 'max';
    out.reason = 'Você está na divisão máxima. Mantenha o nível.';
  } else {
    const failed = promo.criteria.filter((c) => !c.ok).map((c) => `${c.text.charAt(0).toLowerCase()}${c.text.slice(1)} (${c.detail})`);
    out.reason = `Mantido em ${current.name}. Não atendido: ${failed.join('; ')}.`;
  }
  return out;
}

// ------------------------------------------------------------ objetivos de carreira
// Só o id e o estado são salvos; texto, meta e recompensa vêm daqui. Progresso sai do histórico (nunca de contadores à parte).
const recordCompetition = (rec) => COMPETITIONS.find((c) => c.id === rec.competitionId || c.name === rec.competition);
const last = (list, n) => list.slice(0, n); // history guarda a mais recente primeiro

export const CAREER_OBJECTIVES = [
  { id: 'first', text: 'Apitar sua primeira partida', goal: 1, reward: { xp: 50, rep: 0 }, measure: (c) => c.totalMatches },
  { id: 'ten', text: 'Apitar 10 partidas', goal: 10, reward: { xp: 100, rep: 0 }, measure: (c) => c.totalMatches },
  {
    id: 'grade7',
    text: 'Média 7,0 ou mais nas últimas 5 partidas',
    goal: 7,
    reward: { xp: 0, rep: 2 },
    measure: (c) => (c.history.length >= 5 ? last(c.history, 5).reduce((a, m) => a + m.nota, 0) / 5 : 0),
    format: (v, c) => (c.history.length >= 5 ? comma(v) : `${c.history.length}/5 jogos`),
  },
  { id: 'clean', text: 'Concluir uma partida sem erros graves', goal: 1, reward: { xp: 60, rep: 0 }, measure: (c) => Math.min(1, c.history.filter((m) => m.graves === 0).length) },
  { id: 'cup', text: 'Apitar um jogo de copa', goal: 1, reward: { xp: 0, rep: 1 }, measure: (c) => Math.min(1, c.history.filter((m) => (recordCompetition(m) || {}).format === 'cup').length) },
  { id: 'top', text: 'Receber nota 9,0 ou mais em uma partida', goal: 1, reward: { xp: 0, rep: 2 }, measure: (c) => Math.min(1, c.history.filter((m) => m.nota >= 9).length) },
  // Temporada só conta se o árbitro apitou o mínimo de jogos (passar todas as rodadas não vale).
  // VAR: só conta revisão em lance típico (pênalti, vermelho ou impedimento) cuja decisão final a avaliação considerou correta.
  {
    id: 'var',
    text: 'Usar o VAR e terminar com a decisão correta em 3 lances típicos de revisão',
    goal: 3,
    reward: { xp: 80, rep: 0 },
    measure: (c) => c.history.reduce((a, m) => a + (m.var && Array.isArray(m.var.audit) ? m.var.audit.filter((r) => r.eligible && r.finalCorrect === true).length : 0), 0),
  },
  { id: 'season', text: 'Concluir uma temporada apitando 3 jogos ou mais', goal: 1, reward: { xp: 100, rep: 0 }, measure: (c) => Math.min(1, c.seasons.filter((s) => s.played >= PROMOTION.minMatches).length) },
  { id: 'promotion', text: 'Conquistar uma promoção', goal: 1, reward: { xp: 150, rep: 2 }, measure: (c) => Math.min(1, c.seasons.filter((s) => s.action === 'promoted').length) },
];

export const initialObjectives = () => CAREER_OBJECTIVES.map((o) => ({ id: o.id, status: 'active', doneAt: null, seen: true, retro: false }));

// Lista para a tela: definição + estado + progresso atual.
export function careerObjectives(career) {
  return CAREER_OBJECTIVES.map((def) => {
    const state = career.objectives.find((o) => o.id === def.id) || { id: def.id, status: 'active', doneAt: null, seen: true, retro: false };
    const value = def.measure(career);
    return { ...def, ...state, value, progress: def.format ? def.format(value, career) : `${Math.min(value, def.goal)}/${def.goal}` , ratio: clamp(value / def.goal, 0, 1) };
  });
}

// Conclui objetivos cuja meta foi atingida e entrega a recompensa uma única vez.
// retro = true (migração): marca como concluído sem recompensa, para não dar prêmio por jogos antigos.
export function completeObjectives(career, { retro = false } = {}) {
  const done = [];
  for (const def of CAREER_OBJECTIVES) {
    let state = career.objectives.find((o) => o.id === def.id);
    if (!state) {
      state = { id: def.id, status: 'active', doneAt: null, seen: true, retro: false };
      career.objectives.push(state);
    }
    if (state.status === 'done' || def.measure(career) < def.goal) continue;
    state.status = 'done';
    state.doneAt = { season: career.season.number, week: career.world ? career.world.week : 0 };
    state.retro = retro;
    state.seen = retro;
    if (!retro) {
      career.xp += def.reward.xp;
      career.rep = clamp(round1(career.rep + def.reward.rep), 0, 100);
      done.push({ id: def.id, text: def.text, reward: def.reward });
    }
  }
  return done;
}

export const unseenObjectives = (career) => career.objectives.filter((o) => o.status === 'done' && !o.seen).length;
export function markObjectivesSeen(career) {
  let changed = false;
  for (const o of career.objectives) {
    if (o.status === 'done' && !o.seen) {
      o.seen = true;
      changed = true;
    }
  }
  return changed;
}
