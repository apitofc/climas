// Condições e história de cada jogo (Upgrade 4): tempo, gramado, visibilidade, retorno de lesão, disputa de título ou de
// rebaixamento, clássico e final. Funções puras e determinísticas (a mesma partida da carreira tem sempre as mesmas condições).
//
// Regras de projeto:
//  - As condições mudam o CONTEXTO da partida (como a bola corre, quantos contatos leves surgem, a tensão de partida e o
//    que a torcida espera), nunca a nota nem as respostas certas dos lances. Cada lance continua tendo evidências
//    claras; a visibilidade reduzida só aparece como aviso nas evidências de lances distantes.
//  - Nada é aleatório de verdade: tudo sai de um hash da partida, então recarregar não muda o jogo.
import { makeRng, hashString } from '../utils/rng.js';
import { getCompetition, getClub } from '../data/competitions.js';
import { rivalryOf } from '../data/rivalries.js';
import { makeRoster } from '../data/names.js';
import { findFixture, leagueStandings } from './CalendarSystem.js';
import { isLateDrama } from './MatchMood.js';

export const WEATHER = {
  clear: { label: 'Tempo bom', ballFriction: 1, speedMul: 1, slip: 0, visibility: 1 },
  cloudy: { label: 'Nublado', ballFriction: 1, speedMul: 1, slip: 0, visibility: 1 },
  rain: { label: 'Chuva', ballFriction: 1.15, speedMul: 0.97, slip: 0.04, visibility: 0.9 },
  storm: { label: 'Chuva forte', ballFriction: 1.3, speedMul: 0.94, slip: 0.08, visibility: 0.72 },
  fog: { label: 'Neblina', ballFriction: 1, speedMul: 1, slip: 0, visibility: 0.55 },
};
export const PITCH = {
  good: { label: 'gramado bom', ballFriction: 1, speedMul: 1, slip: 0 },
  heavy: { label: 'gramado pesado', ballFriction: 0.8, speedMul: 0.95, slip: 0.05 },
  poor: { label: 'gramado irregular', ballFriction: 1, speedMul: 0.98, slip: 0.03 },
};
export const LOW_VISIBILITY = 0.8;
export const RETURN_CHANCE = 0.3;

const pickWeighted = (frac, table) => {
  let acc = 0;
  for (const [k, w] of table) {
    acc += w;
    if (frac < acc) return k;
  }
  return table[table.length - 1][0];
};

// Disputa de título ou de rebaixamento: só em liga, a partir da 3ª rodada, olhando a tabela real do momento.
function leagueStakes(world, comp, fx) {
  if (!world || !comp || !comp.division || !fx || fx.week < 3) return [];
  const state = world.competitions && world.competitions[comp.id];
  if (!state) return [];
  const table = leagueStandings(state);
  const out = [];
  const leader = table[0];
  const top = table.slice(0, 2);
  const bottom = table.slice(-2);
  for (const id of [fx.home, fx.away]) {
    const club = getClub(id);
    const row = table.find((r) => r.id === id);
    if (!row || !club || row.played === 0) continue;
    if (top.some((r) => r.id === id) && leader.pts - row.pts <= 3) out.push({ id: 'title', club: id, label: 'Disputa de título', text: `${club.name} briga pelo título da ${comp.name}.`, tension: 8 });
    else if (bottom.some((r) => r.id === id)) out.push({ id: 'relegation', club: id, label: 'Luta contra o rebaixamento', text: `${club.name} está na zona de rebaixamento da ${comp.name}.`, tension: 8 });
  }
  return out.slice(0, 2);
}

// f = { seed, competitionId, homeId, awayId, stage, week, fixtureId }. world é opcional (só a carreira tem tabela).
export function buildConditions(f, world = null) {
  const rng = makeRng(hashString(`cond:${f.seed}`));
  const weather = pickWeighted(rng.frac(), [['clear', 0.45], ['cloudy', 0.15], ['rain', 0.2], ['storm', 0.07], ['fog', 0.13]]);
  const wet = weather === 'rain' || weather === 'storm';
  const pitchRoll = rng.frac();
  const pitch = wet ? 'heavy' : pitchRoll < 0.2 ? 'poor' : 'good';
  const w = WEATHER[weather];
  const p = PITCH[pitch];
  const effects = { ballFriction: w.ballFriction * p.ballFriction, speedMul: w.speedMul * p.speedMul, slip: w.slip + p.slip };
  const visibility = w.visibility;

  const comp = getCompetition(f.competitionId);
  const storylines = [];
  const riv = rivalryOf(f.homeId, f.awayId);
  if (riv) storylines.push({ id: 'derby', label: riv.name, text: `${riv.name}: rivalidade elevada dentro e fora de campo.`, tension: 10 });
  if (/^final$/i.test(f.stage || '')) storylines.push({ id: 'final', label: 'Final', text: 'Uma final: quem perder fica sem o título.', tension: 10 });
  else if (/^semifina/i.test(f.stage || '')) storylines.push({ id: 'semifinal', label: 'Semifinal', text: 'Semifinal: quem perder está eliminado.', tension: 6 });
  const fx = world && f.fixtureId ? findFixture(world, f.fixtureId) : null;
  if (fx) storylines.push(...leagueStakes(world, comp, fx).map((s) => ({ ...s })));

  // Retorno de lesão: um jogador de linha de um dos times volta depois de ficar fora (o time e a pessoa vêm do hash).
  let injuryReturn = null;
  if (rng.frac() < RETURN_CHANCE) {
    const side = rng.frac() < 0.5 ? 'home' : 'away';
    const clubId = side === 'home' ? f.homeId : f.awayId;
    const roster = makeRoster(clubId);
    const index = 1 + Math.floor(rng.frac() * 10); // camisa 2 a 11 (o goleiro não)
    if (roster[index]) injuryReturn = { team: side, clubId, number: index + 1, name: roster[index].last };
  }
  if (injuryReturn) storylines.push({ id: 'injury_return', label: 'Retorno de lesão', text: `${injuryReturn.name} (#${injuryReturn.number}) volta de lesão em ${getClub(injuryReturn.clubId).name}.`, tension: 0 });

  const crowdFactor = riv || storylines.some((s) => ['final', 'title', 'relegation'].includes(s.id)) ? 1.5 : 1;
  const baseTension = storylines.reduce((a, s) => a + s.tension, 0);
  const bits = [w.label, p.label].filter((t, i) => i === 1 || weather !== 'clear' || pitch !== 'good');
  return {
    v: 1,
    weather,
    pitch,
    visibility,
    effects,
    storylines,
    injuryReturn,
    crowdFactor,
    baseTension,
    text: weather === 'clear' && pitch === 'good' ? 'Tempo bom, gramado bom' : weather === 'cloudy' && pitch === 'good' ? 'Nublado, gramado bom' : bits.join(', '),
  };
}

// Para testes: força o tempo da partida (?weather=storm na URL). O gramado acompanha a chuva.
export function withWeather(cond, weather) {
  if (!WEATHER[weather]) return cond;
  const wet = weather === 'rain' || weather === 'storm';
  const pitch = wet ? 'heavy' : cond.pitch === 'heavy' ? 'good' : cond.pitch;
  const w = WEATHER[weather];
  const p = PITCH[pitch];
  return {
    ...cond,
    weather,
    pitch,
    visibility: w.visibility,
    effects: { ballFriction: w.ballFriction * p.ballFriction, speedMul: w.speedMul * p.speedMul, slip: w.slip + p.slip },
    text: weather === 'clear' && pitch === 'good' ? 'Tempo bom, gramado bom' : weather === 'cloudy' && pitch === 'good' ? 'Nublado, gramado bom' : [w.label, p.label].join(', '),
  };
}

// Condições de uma partida da carreira (usa o calendário e a tabela reais) ou de uma partida rápida (só a semente).
export function conditionsFor(career, fixture) {
  const world = career ? career.world : null;
  const fx = world && fixture.fixtureId ? findFixture(world, fixture.fixtureId) : null;
  return buildConditions(
    {
      seed: fixture.seed,
      competitionId: fixture.competitionId,
      homeId: fixture.homeId || (fixture.home && fixture.home.id),
      awayId: fixture.awayId || (fixture.away && fixture.away.id),
      stage: (fx && fx.stage) || fixture.stage || '',
      week: (fx && fx.week) || fixture.week || (world ? world.week : 1),
      fixtureId: fixture.fixtureId || null,
    },
    world
  );
}

export { isLateDrama };

export const lowVisibility = (cond) => !!cond && cond.visibility < LOW_VISIBILITY;

// Resumo curto para o registro da partida, o relatório, as notícias e as publicações.
export function conditionsSummary(cond, extra = {}) {
  if (!cond) return null;
  return {
    weather: cond.weather,
    pitch: cond.pitch,
    text: cond.text,
    lowVisibility: lowVisibility(cond),
    stories: cond.storylines.map((s) => ({ id: s.id, label: s.label, text: s.text })),
    injuryReturn: cond.injuryReturn ? { team: cond.injuryReturn.team, number: cond.injuryReturn.number, name: cond.injuryReturn.name, fouled: extra.returnFouled || 0 } : null,
    late: !!extra.late,
  };
}

// Quantas faltas o jogador que voltou de lesão sofreu na partida (contadas na súmula, só as marcadas).
export function returnFouls(cond, log) {
  if (!cond || !cond.injuryReturn) return 0;
  const r = cond.injuryReturn;
  return (log || []).filter((e) => e.victim && e.victim.team === r.team && e.victim.number === r.number && e.actual && e.actual.foulCalled && e.expected && e.expected.foul).length;
}
