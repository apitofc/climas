// Memória da carreira (Upgrade 7): o jogo lembra o que aconteceu. Funções puras.
//
// Regras de projeto:
//  - Tudo que a memória guarda vem de partidas realmente apitadas (nota, súmula, rixa, placar). Nada é inventado.
//  - A memória só alimenta narrativa, convocações e a retrospectiva. Ela NUNCA altera nota, XP ou reputação de uma partida.
//  - Cada partida entra na memória uma única vez (applyMatch já descarta partidas repetidas).
import { COMPETITIONS, getCompetition, getClub } from '../data/competitions.js';
import { rivalryOf } from '../data/rivalries.js';

export const COMPLAINT_LIMIT = 4;
export const FEUD_LIMIT = 3;
export const RETRO_LIMIT = 12;
export const TRUST_MATCHES = 3;
export const TRUST_AVG = 8;

const WEEKS = 5; // rodadas por temporada (mesmo valor de WEEKS_PER_SEASON no calendário)
const other = (t) => (t === 'home' ? 'away' : 'home');
const round1 = (v) => Math.round(v * 10) / 10;
const comma = (n) => String(round1(n)).replace('.', ',');
const plural = (n, a, b) => `${n} ${n === 1 ? a : b}`;

export const emptyMemory = () => ({ clubs: {}, competitions: {}, rivalries: {} });

export function ensureMemory(career) {
  if (!career.memory || typeof career.memory !== 'object') career.memory = emptyMemory();
  for (const k of ['clubs', 'competitions', 'rivalries']) if (!career.memory[k] || typeof career.memory[k] !== 'object') career.memory[k] = {};
  if (!Array.isArray(career.retrospectives)) career.retrospectives = [];
  return career.memory;
}

// ------------------------------------------------------------ impacto de cada lado na súmula
// Decisão errada contra um lado = esse lado foi prejudicado de verdade (a avaliação técnica confirma).
// Decisão correta contra um lado = o lado pode reclamar, mas não tem razão.
export function sideImpact(log) {
  const make = () => ({ wrong: 0, correctAgainst: 0, reds: 0 });
  const out = { home: make(), away: make() };
  for (const e of log || []) {
    if (!e || e.type === 'unnecessary_whistle') continue;
    if (e.favored) {
      const harmed = other(e.favored);
      if (e.correct) out[harmed].correctAgainst += 1;
      else out[harmed].wrong += 1;
    }
    for (const c of (e.actual && e.actual.cards) || []) if (c.color === 'red' && out[c.team]) out[c.team].reds += 1;
  }
  return out;
}

// ------------------------------------------------------------ atualização depois de cada partida
// rec = registro da partida (competitionId, homeId, awayId, nota, season, week, matchId, score "a x b")
// info = { sides, feud, graves }. Devolve avisos { type, clubId?, kind?, text } para mostrar ao jogador.
export function rememberMatch(career, rec, info = {}) {
  const mem = ensureMemory(career);
  const notes = [];
  const [gh, ga] = String(rec.score || '0 x 0').split(' x ').map((n) => Number(n) || 0);
  const lost = { home: gh < ga, away: ga < gh };
  const at = { season: rec.season, week: rec.week, matchId: rec.matchId, competitionId: rec.competitionId };

  for (const side of ['home', 'away']) {
    const id = rec[`${side}Id`];
    if (!id) continue;
    const m = (mem.clubs[id] = mem.clubs[id] || { matches: 0, sumNota: 0, reds: 0, complaints: [], last: null });
    m.matches += 1;
    m.sumNota = round1(m.sumNota + rec.nota);
    m.reds += (info.sides && info.sides[side] && info.sides[side].reds) || 0;
    m.last = { ...at, nota: rec.nota };
    const imp = info.sides && info.sides[side];
    if (imp) {
      let kind = null;
      let n = 0;
      if (imp.wrong >= 1) {
        kind = 'formal';
        n = imp.wrong;
      } else if (imp.correctAgainst >= 2 && lost[side]) {
        kind = 'publica';
        n = imp.correctAgainst;
      }
      if (kind) {
        m.complaints.unshift({ ...at, kind, n });
        m.complaints.length = Math.min(m.complaints.length, COMPLAINT_LIMIT);
        const club = getClub(id);
        notes.push({ type: 'complaint', clubId: id, kind, n, text: kind === 'formal' ? `O ${club ? club.name : id} fez reclamação formal: ${plural(n, 'decisão errada contra o time', 'decisões erradas contra o time')} (a avaliação técnica confirma).` : `O ${club ? club.name : id} criticou ${plural(n, 'decisão correta', 'decisões corretas')} contra o time (a avaliação técnica discorda).` });
      }
    }
  }

  if (rec.competitionId) {
    const c = (mem.competitions[rec.competitionId] = mem.competitions[rec.competitionId] || { matches: 0, sumNota: 0, best: null, seasons: {} });
    c.matches += 1;
    c.sumNota = round1(c.sumNota + rec.nota);
    if (!c.best || rec.nota > c.best.nota) c.best = { nota: rec.nota, season: rec.season, matchId: rec.matchId };
    const s = (c.seasons[rec.season] = c.seasons[rec.season] || { matches: 0, sumNota: 0 });
    s.matches += 1;
    s.sumNota = round1(s.sumNota + rec.nota);
  }

  const riv = rivalryOf(rec.homeId, rec.awayId);
  if (riv) {
    const r = (mem.rivalries[riv.id] = mem.rivalries[riv.id] || { name: riv.name, matches: 0, cards: 0, feuds: [], lastSeason: null });
    r.matches += 1;
    r.lastSeason = rec.season;
    if (info.feud) {
      r.cards += info.feud.cards || 0;
      r.feuds.unshift({ season: rec.season, matchId: rec.matchId, a: { name: info.feud.a.name, number: info.feud.a.number }, b: { name: info.feud.b.name, number: info.feud.b.number }, count: info.feud.count, cards: info.feud.cards || 0 });
      r.feuds.length = Math.min(r.feuds.length, FEUD_LIMIT);
      notes.push({ type: 'feud', text: `A rixa entre ${info.feud.a.name} e ${info.feud.b.name} no ${riv.name} ficou registrada para os próximos encontros.` });
    }
  }
  return notes;
}

// Reconstrói a memória de uma carreira antiga a partir do histórico (só dados que existem: não há queixas de clubes
// nem rixas antes desta versão).
const clubByName = (name) => {
  for (const c of COMPETITIONS) {
    const k = c.clubs.find((x) => x.name === name);
    if (k) return k.id;
  }
  return null;
};
export function buildMemoryFromHistory(career) {
  career.memory = emptyMemory();
  const list = [...(career.history || [])].reverse();
  for (const h of list) {
    const rec = { ...h, homeId: h.homeId || clubByName(h.home), awayId: h.awayId || clubByName(h.away) };
    rememberMatch(career, rec, {});
  }
  return career.memory;
}

// ------------------------------------------------------------ o que a memória diz sobre um jogo
// f = { competitionId, homeId, awayId, stage, week }. Devolve [{ id, text, weight }]. weight 1 conta como fator de pressão.
export function memoryNotes(career, f) {
  const mem = career && career.memory;
  if (!mem) return [];
  const notes = [];
  const comp = getCompetition(f.competitionId);
  for (const id of [f.homeId, f.awayId]) {
    const m = mem.clubs && mem.clubs[id];
    const club = getClub(id);
    if (!m || !club) continue;
    const last = m.complaints && m.complaints[0];
    if (last) {
      notes.push({
        id: 'grievance',
        text: last.kind === 'formal' ? `O ${club.name} fez reclamação formal da sua arbitragem na temporada ${last.season} (${plural(last.n, 'decisão errada', 'decisões erradas')}).` : `O ${club.name} criticou publicamente a sua arbitragem na temporada ${last.season}.`,
        weight: last.kind === 'formal' ? 1 : 0,
      });
    }
  }
  const riv = rivalryOf(f.homeId, f.awayId);
  const rm = riv && mem.rivalries && mem.rivalries[riv.id];
  if (rm && rm.feuds.length) {
    const fd = rm.feuds[0];
    notes.push({ id: 'rivalry', text: `Na última vez neste clássico (temporada ${fd.season}), ${fd.a.name} e ${fd.b.name} se estranharam ${fd.count} vezes.`, weight: 0 });
  }
  const decisive = /^final$/i.test(f.stage || '') || /^semifina/i.test(f.stage || '') || (comp && comp.division && f.week >= WEEKS) || !!riv;
  if (decisive) {
    for (const id of [f.homeId, f.awayId]) {
      const m = mem.clubs && mem.clubs[id];
      const club = getClub(id);
      if (m && club && m.matches >= 1) notes.push({ id: 'reencounter', text: `Reencontro: você já apitou o ${club.name} ${plural(m.matches, 'vez', 'vezes')} (média ${comma(m.sumNota / m.matches)}).`, weight: 0 });
    }
  }
  const cm = mem.competitions && mem.competitions[f.competitionId];
  if (cm && cm.matches >= 2 && comp) notes.push({ id: 'competition', text: `${comp.name}: sua média é ${comma(cm.sumNota / cm.matches)} em ${cm.matches} jogos.`, weight: 0 });
  return notes;
}

// ------------------------------------------------------------ convocação de confiança (boa fase)
// As 3 últimas partidas com média 8,0 ou mais e nenhum erro grave: a comissão destaca o jogo mais importante da semana.
export function goodFormTrust(career) {
  const last = (career.history || []).slice(0, TRUST_MATCHES);
  if (last.length < TRUST_MATCHES) return { trusted: false, avg: null, n: last.length };
  const avg = last.reduce((a, m) => a + m.nota, 0) / last.length;
  const graves = last.reduce((a, m) => a + (m.graves || 0), 0);
  return { trusted: avg >= TRUST_AVG && graves === 0, avg: round1(avg), n: last.length };
}

// ------------------------------------------------------------ retrospectiva da temporada
const PROFILES = [
  { id: 'polemico', label: 'Temporada polêmica', test: (s) => s.graves >= 3, text: 'Muitos erros graves marcaram o ano: a imprensa e os clubes lembram.' },
  { id: 'cirurgico', label: 'Cirúrgico', test: (s) => s.played >= 4 && s.graves === 0 && s.avg >= 8, text: 'Nenhum erro grave e média altíssima: o ano de um árbitro de elite.' },
  { id: 'regional', label: 'Árbitro regional', test: (s) => s.regional >= 2 && s.regional / s.played >= 0.5, text: 'O ano foi dominado pelas copas da sua região.' },
  { id: 'copas', label: 'Especialista em copas', test: (s) => s.cups >= 2 && s.cups / s.played >= 0.5 && s.avg >= 7, text: 'Foi nos mata-matas que você mais apareceu, e bem.' },
  { id: 'classicos', label: 'Veterano de clássicos', test: (s) => s.derbies >= 2, text: 'Você encarou os grandes clássicos e segurou a pressão.' },
  { id: 'pulso', label: 'Pulso firme', test: (s) => s.played >= 3 && (s.yellow + s.red) / s.played >= 4 && s.avg >= 6.5, text: 'Muitos cartões, quase sempre os certos: jogo sob controle.' },
  { id: 'regular', label: 'Temporada regular', test: () => true, text: 'Um ano de consolidação, sem grandes extremos.' },
];

export function seasonRetrospective(career, season, { decision = null, awards = [], repBonus = 0 } = {}) {
  const ms = season.matches || [];
  const played = ms.length;
  const avg = played ? ms.reduce((a, m) => a + m.nota, 0) / played : null;
  const sorted = [...ms].sort((a, b) => b.nota - a.nota);
  const pick = (m) => (m ? { nota: m.nota, competition: m.competition, vs: `${m.home} x ${m.away}`, score: m.score, round: m.round } : null);
  const facts = (m) => m.extras || {};
  const sum = (fn) => ms.reduce((a, m) => a + fn(m), 0);

  const byComp = new Map();
  for (const m of ms) {
    const cur = byComp.get(m.competition) || { name: m.competition, played: 0, sum: 0 };
    cur.played += 1;
    cur.sum += m.nota;
    byComp.set(m.competition, cur);
  }
  const clubs = new Map();
  for (const m of ms) for (const id of [m.homeId, m.awayId]) if (id) clubs.set(id, (clubs.get(id) || 0) + 1);
  const topClubs = [...clubs.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([id, n]) => ({ name: (getClub(id) || { name: id }).name, played: n }));

  const stats = {
    played,
    avg: avg === null ? 0 : avg,
    graves: sum((m) => m.graves || 0),
    yellow: sum((m) => facts(m).yellow || 0),
    red: sum((m) => facts(m).red || 0),
    cups: ms.filter((m) => (getCompetition(m.competitionId) || {}).format === 'cup').length,
    regional: ms.filter((m) => (getCompetition(m.competitionId) || {}).region).length,
    derbies: ms.filter((m) => m.context && m.context.tags && m.context.tags.includes('rivalry')).length,
  };
  const profile = PROFILES.find((p) => p.test(stats));

  const complaints = Object.values(career.memory ? career.memory.clubs : {}).reduce((a, c) => a + c.complaints.filter((x) => x.season === season.number).length, 0);
  const feuds = Object.values(career.memory ? career.memory.rivalries : {}).reduce((a, r) => a + r.feuds.filter((x) => x.season === season.number).length, 0);
  const events = (career.events || []).filter((e) => e.date && e.date.season === season.number).length;

  const retro = {
    season: season.number,
    division: decision ? decision.from : career.division,
    played,
    avg: avg === null ? null : round1(avg),
    best: pick(sorted[0]),
    worst: played > 1 ? pick(sorted[sorted.length - 1]) : null,
    graves: stats.graves,
    yellow: stats.yellow,
    red: stats.red,
    varReviews: sum((m) => (m.var ? m.var.reviews : 0)),
    repDelta: round1(sum((m) => m.rep || 0) + repBonus),
    xp: sum((m) => m.xp || 0),
    byCompetition: [...byComp.values()].map((c) => ({ name: c.name, played: c.played, avg: round1(c.sum / c.played) })),
    topClubs,
    complaints,
    feuds,
    events,
    awards: awards.map((a) => a.name),
    action: decision ? decision.action : null,
    to: decision ? decision.to : null,
    reason: decision ? decision.reason : null,
    profile: { id: profile.id, label: profile.label, text: profile.text },
    lines: [],
  };

  const L = retro.lines;
  if (!played) L.push('Temporada sem partidas apitadas.');
  else {
    L.push(`Você apitou ${plural(played, 'jogo', 'jogos')} com média ${comma(retro.avg)} e ${plural(retro.graves, 'erro grave', 'erros graves')}.`);
    if (retro.best) L.push(`Melhor jogo: ${retro.best.vs} (${retro.best.competition}), nota ${comma(retro.best.nota)}.`);
    if (retro.worst) L.push(`Jogo mais difícil: ${retro.worst.vs} (${retro.worst.competition}), nota ${comma(retro.worst.nota)}.`);
    if (retro.byCompetition.length > 1) {
      const top = [...retro.byCompetition].sort((a, b) => b.avg - a.avg)[0];
      L.push(`Melhor competição: ${top.name}, média ${comma(top.avg)} em ${plural(top.played, 'jogo', 'jogos')}.`);
    }
    if (topClubs.length && topClubs[0].played >= 2) L.push(`Clube que você mais encontrou: ${topClubs[0].name} (${topClubs[0].played} jogos).`);
    if (complaints) L.push(`${plural(complaints, 'clube reclamou', 'clubes reclamaram')} da sua arbitragem durante o ano.`);
    if (feuds) L.push(`${plural(feuds, 'rixa entre jogadores marcou', 'rixas entre jogadores marcaram')} os clássicos.`);
    if (retro.awards.length) L.push(`Prêmios: ${retro.awards.join(', ')}.`);
  }
  if (decision && decision.reason) L.push(decision.reason);
  return retro;
}
