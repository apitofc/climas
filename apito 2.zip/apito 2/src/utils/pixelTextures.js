import { POSE } from '../data/poses.js';

export { POSE };
const BASE = {
  skin: '#f0c08a',
  hair: '#3b2a1c',
  shoe: '#f4f4f4',
  eye: '#161616',
};

const kit = (shirt, armShirt, accent, shorts, sock) => ({ ...BASE, shirt, armShirt, accent, shorts, sock });

export const PALETTES = {
  referee: kit('#161616', '#2e2e2e', '#c8ff2e', '#161616', '#161616'),
  home: kit('#d63a3a', '#e26060', '#ffffff', '#f2f2f2', '#d63a3a'),
  away: kit('#2f6fd6', '#5a8fe0', '#ffffff', '#f2f2f2', '#2f6fd6'),
  gkHome: kit('#8a3fd6', '#a566e0', '#e8d8ff', '#222222', '#8a3fd6'),
  gkAway: kit('#f08a1c', '#f4a64e', '#fff0d8', '#222222', '#f08a1c'),
};

export const REFEREE_FRAME_W = 12;
export const REFEREE_FRAME_H = 16;
const REFEREE_DIRS = 3;
const REFEREE_STEPS = 3;

// Poses especiais (quadros depois dos 9 de caminhada): comemoração, reclamação, chute e sinal do árbitro.
const POSE_COUNT = 4;

function drawPose(ctx, ox, pose, pal) {
  const r = (x, y, w, h, color) => {
    ctx.fillStyle = color;
    ctx.fillRect(ox + x, y, w, h);
  };
  const clear = (x, y, w, h) => ctx.clearRect(ox + x, y, w, h);

  if (pose === 'kick') {
    drawPerson(ctx, ox, 2, 0, pal);
    clear(3, 12, 9, 4);
    r(4, 12, 2, 3, pal.sock);
    r(4, 15, 2, 1, pal.shoe);
    r(6, 12, 2, 2, pal.sock);
    r(8, 13, 2, 1, pal.sock);
    r(10, 13, 2, 1, pal.shoe);
    return;
  }

  drawPerson(ctx, ox, 0, 0, pal);
  clear(1, 6, 1, 4);
  clear(10, 6, 1, 4);
  if (pose === 'cheer') {
    r(1, 1, 1, 5, pal.armShirt);
    r(1, 0, 1, 1, pal.skin);
    r(10, 1, 1, 5, pal.armShirt);
    r(10, 0, 1, 1, pal.skin);
  } else if (pose === 'protest') {
    r(0, 6, 2, 1, pal.armShirt);
    r(0, 5, 1, 1, pal.skin);
    r(10, 6, 2, 1, pal.armShirt);
    r(11, 5, 1, 1, pal.skin);
  } else {
    // signal: braço esquerdo normal e braço direito levantado
    r(1, 6, 1, 3, pal.armShirt);
    r(1, 9, 1, 1, pal.skin);
    r(10, 1, 1, 5, pal.armShirt);
    r(10, 0, 1, 1, pal.skin);
  }
}

function drawPerson(ctx, ox, dir, step, pal) {
  const r = (x, y, w, h, color) => {
    ctx.fillStyle = color;
    ctx.fillRect(ox + x, y, w, h);
  };
  const leg = (x, h, w = 2, shoeW = 2) => {
    r(x, 12, w, h - 1, pal.sock);
    r(x, 12 + h - 1, shoeW, 1, pal.shoe);
  };

  if (dir === 2) {
    r(3, 0, 6, 2, pal.hair);
    r(5, 2, 4, 3, pal.skin);
    r(3, 2, 2, 3, pal.hair);
    r(7, 3, 1, 1, pal.eye);

    r(3, 5, 6, 5, pal.shirt);
    r(3, 7, 6, 1, pal.accent);

    const armX = step === 1 ? 6 : step === 2 ? 4 : 5;
    r(armX, 6, 2, 3, pal.armShirt);
    r(armX, 9, 2, 1, pal.skin);

    r(3, 10, 6, 2, pal.shorts);

    if (step === 0) {
      leg(4, 4, 2, 2);
      leg(6, 4, 2, 3);
    } else if (step === 1) {
      leg(3, 4, 2, 2);
      leg(7, 3, 2, 3);
    } else {
      leg(7, 4, 2, 3);
      leg(3, 3, 2, 2);
    }
    return;
  }

  if (dir === 0) {
    r(3, 0, 6, 2, pal.hair);
    r(3, 2, 6, 3, pal.skin);
    r(4, 3, 1, 1, pal.eye);
    r(7, 3, 1, 1, pal.eye);
  } else {
    r(3, 0, 6, 5, pal.hair);
  }

  r(2, 5, 8, 5, pal.shirt);
  r(2, 7, 8, 1, pal.accent);
  if (dir === 0) r(5, 5, 2, 1, pal.accent);

  const ly = step === 1 ? 7 : 6;
  const ry = step === 2 ? 7 : 6;
  r(1, ly, 1, 3, pal.armShirt);
  r(1, ly + 3, 1, 1, pal.skin);
  r(10, ry, 1, 3, pal.armShirt);
  r(10, ry + 3, 1, 1, pal.skin);

  r(3, 10, 6, 2, pal.shorts);

  leg(3, step === 1 ? 3 : 4);
  leg(7, step === 2 ? 3 : 4);
}

export function createPersonTexture(scene, key, pal) {
  if (scene.textures.exists(key)) return;

  const walkFrames = REFEREE_DIRS * REFEREE_STEPS;
  const total = walkFrames + POSE_COUNT;
  const tex = scene.textures.createCanvas(key, REFEREE_FRAME_W * total, REFEREE_FRAME_H);
  const ctx = tex.getContext();

  for (let dir = 0; dir < REFEREE_DIRS; dir++) {
    for (let step = 0; step < REFEREE_STEPS; step++) {
      const index = dir * REFEREE_STEPS + step;
      drawPerson(ctx, index * REFEREE_FRAME_W, dir, step, pal);
      tex.add(index, 0, index * REFEREE_FRAME_W, 0, REFEREE_FRAME_W, REFEREE_FRAME_H);
    }
  }
  ['cheer', 'protest', 'kick', 'signal'].forEach((pose, i) => {
    const index = walkFrames + i;
    drawPose(ctx, index * REFEREE_FRAME_W, pose, pal);
    tex.add(index, 0, index * REFEREE_FRAME_W, 0, REFEREE_FRAME_W, REFEREE_FRAME_H);
  });
  tex.refresh();
}

const hexToRgb = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const colorDistance = (a, b) => {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  return Math.hypot(r1 - r2, g1 - g2, b1 - b2);
};
const lighten = (hex, amount) =>
  '#' +
  hexToRgb(hex)
    .map((v) => Math.min(255, Math.round(v + (255 - v) * amount)).toString(16).padStart(2, '0'))
    .join('');

const GK_COLORS = ['#8a3fd6', '#f08a1c', '#d63fa8', '#1fb5b5'];

export function createTeamTextures(scene, homeClub, awayClub) {
  const awayShirt = colorDistance(homeClub.shirt, awayClub.shirt) < 110 ? awayClub.alt : awayClub.shirt;
  const shirts = [homeClub.shirt, awayShirt];
  const free = GK_COLORS.filter((c) => shirts.every((s) => colorDistance(c, s) >= 110));
  const pool = free.length >= 2 ? free : GK_COLORS;

  const fromClub = (club, shirt) => kit(shirt, lighten(shirt, 0.2), club.accent, club.shorts, shirt);
  const gkKit = (c) => kit(c, lighten(c, 0.2), '#ffffff', '#222222', c);

  const defs = {
    player_home: fromClub(homeClub, homeClub.shirt),
    player_away: fromClub(awayClub, awayShirt),
    gk_home: gkKit(pool[0]),
    gk_away: gkKit(pool[1]),
  };
  for (const [key, pal] of Object.entries(defs)) {
    if (scene.textures.exists(key)) scene.textures.remove(key);
    createPersonTexture(scene, key, pal);
  }
}

export function createAllPersonTextures(scene) {
  createPersonTexture(scene, 'referee', PALETTES.referee);
  createPersonTexture(scene, 'player_home', PALETTES.home);
  createPersonTexture(scene, 'player_away', PALETTES.away);
  createPersonTexture(scene, 'gk_home', PALETTES.gkHome);
  createPersonTexture(scene, 'gk_away', PALETTES.gkAway);
}

export function createBallTextures(scene) {
  if (!scene.textures.exists('ball')) {
    const tex = scene.textures.createCanvas('ball', 5, 5);
    const ctx = tex.getContext();
    ctx.fillStyle = '#f7f7f2';
    ctx.fillRect(1, 0, 3, 1);
    ctx.fillRect(0, 1, 5, 3);
    ctx.fillRect(1, 4, 3, 1);
    ctx.fillStyle = '#3a3a3a';
    ctx.fillRect(2, 2, 1, 1);
    ctx.fillRect(1, 1, 1, 1);
    tex.refresh();
  }
  if (!scene.textures.exists('ball_shadow')) {
    const tex = scene.textures.createCanvas('ball_shadow', 5, 2);
    const ctx = tex.getContext();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.fillRect(1, 0, 3, 1);
    ctx.fillRect(0, 1, 5, 1);
    tex.refresh();
  }
}

export function createShadowTexture(scene) {
  if (scene.textures.exists('shadow')) return;
  const tex = scene.textures.createCanvas('shadow', 10, 4);
  const ctx = tex.getContext();
  ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.fillRect(2, 0, 6, 1);
  ctx.fillRect(0, 1, 10, 2);
  ctx.fillRect(2, 3, 6, 1);
  tex.refresh();
}
export function refereePalette(look) {
  return {
    skin: look.skin,
    hair: look.hair,
    shoe: '#f4f4f4',
    eye: '#161616',
    shirt: look.shirt,
    armShirt: lighten(look.shirt, 0.2),
    accent: look.accent,
    shorts: look.shirt,
    sock: look.shirt,
  };
}

// Recria a textura do árbitro com a aparência escolhida na carreira.
export function createRefereeTexture(scene, look) {
  if (scene.textures.exists('referee')) scene.textures.remove('referee');
  createPersonTexture(scene, 'referee', refereePalette(look));
}

// Miniatura (data URL) usada na tela de criação do árbitro. Retorna '' se o navegador não permitir.
export function lookPreviewUrl(look, scale = 5) {
  try {
    const small = document.createElement('canvas');
    small.width = REFEREE_FRAME_W;
    small.height = REFEREE_FRAME_H;
    drawPerson(small.getContext('2d'), 0, 0, 0, refereePalette(look));
    const big = document.createElement('canvas');
    big.width = REFEREE_FRAME_W * scale;
    big.height = REFEREE_FRAME_H * scale;
    const ctx = big.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(small, 0, 0, big.width, big.height);
    return big.toDataURL();
  } catch (e) {
    return '';
  }
}
