import { TEAMS } from '../config.js';

export const playerLabel = (p) => (p.name ? `#${p.number} ${p.name}` : `#${p.number}`);
export const playerFull = (p) => `${playerLabel(p)} (${TEAMS[p.team].name})`;
