// Áudio sintetizado com Web Audio (sem arquivos de som): apito, chute, gol, cartão e torcida.
// Falha em silêncio se o navegador bloquear. A opção de silenciar é lembrada entre as partidas.
const MUTE_KEY = 'apitodojogo:muted';

let ctx = null;
let master = null;
let noiseBuf = null;
let crowd = null;
let muted = readMuted();

function readMuted() {
  try {
    return window.localStorage.getItem(MUTE_KEY) === '1';
  } catch (e) {
    return false;
  }
}

function engine() {
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return null;
  if (!ctx) {
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = muted ? 0 : 0.9;
    master.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

export const isMuted = () => muted;

export function setMuted(value) {
  muted = value;
  try {
    window.localStorage.setItem(MUTE_KEY, value ? '1' : '0');
  } catch (e) {
    // sem armazenamento: vale só nesta sessão
  }
  if (ctx && master) master.gain.setTargetAtTime(value ? 0 : 0.9, ctx.currentTime, 0.03);
  return muted;
}

export const toggleMuted = () => setMuted(!muted);

function noiseBuffer(c) {
  if (!noiseBuf) {
    noiseBuf = c.createBuffer(1, c.sampleRate * 2, c.sampleRate);
    const data = noiseBuf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  }
  return noiseBuf;
}

function tone(c, { type = 'sine', from, to = from, start = 0, dur, vol, vibrato = 0 }) {
  const t = c.currentTime + start;
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(from, t);
  if (to !== from) osc.frequency.linearRampToValueAtTime(to, t + dur);
  if (vibrato) {
    const lfo = c.createOscillator();
    const lfoGain = c.createGain();
    lfo.frequency.setValueAtTime(vibrato, t);
    lfoGain.gain.setValueAtTime(140, t);
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);
    lfo.start(t);
    lfo.stop(t + dur + 0.05);
  }
  gain.gain.setValueAtTime(0, t);
  gain.gain.linearRampToValueAtTime(vol, t + 0.015);
  gain.gain.setValueAtTime(vol, t + Math.max(0.02, dur - 0.1));
  gain.gain.linearRampToValueAtTime(0, t + dur);
  osc.connect(gain);
  gain.connect(master);
  osc.start(t);
  osc.stop(t + dur + 0.05);
}

function noiseBurst(c, { start = 0, dur, vol, filter = 'highpass', freq = 1500, q = 0.7 }) {
  const t = c.currentTime + start;
  const src = c.createBufferSource();
  src.buffer = noiseBuffer(c);
  const f = c.createBiquadFilter();
  f.type = filter;
  f.frequency.value = freq;
  f.Q.value = q;
  const gain = c.createGain();
  gain.gain.setValueAtTime(0, t);
  gain.gain.linearRampToValueAtTime(vol, t + Math.min(0.02, dur / 3));
  gain.gain.linearRampToValueAtTime(0, t + dur);
  src.connect(f);
  f.connect(gain);
  gain.connect(master);
  src.start(t);
  src.stop(t + dur + 0.05);
}

function safe(fn) {
  if (muted) return;
  try {
    const c = engine();
    if (c) fn(c);
  } catch (e) {
    // sem áudio: ignora
  }
}

// kind: 'long' (falta, cartão), 'short' (reinício) ou 'final' (três apitos: intervalo e fim de jogo)
export function playWhistle(kind = 'long') {
  safe((c) => {
    const blast = (start, dur) => tone(c, { type: 'sine', from: 2700, start, dur, vol: 0.16, vibrato: 28 });
    if (kind === 'final') [0, 0.65, 1.3].forEach((s) => blast(s, 0.5));
    else blast(0, kind === 'short' ? 0.2 : 0.55);
  });
}

export function playKick(strength = 0.6) {
  safe((c) => {
    tone(c, { type: 'sine', from: 150, to: 55, dur: 0.09, vol: 0.28 * strength });
    noiseBurst(c, { dur: 0.05, vol: 0.12 * strength, freq: 1800 });
  });
}

export function playGoal() {
  safe((c) => {
    noiseBurst(c, { dur: 2.6, vol: 0.32, filter: 'bandpass', freq: 750, q: 0.6 });
    tone(c, { type: 'triangle', from: 392, dur: 0.35, vol: 0.1 });
    tone(c, { type: 'triangle', from: 523, start: 0.38, dur: 0.5, vol: 0.1 });
  });
}

export function playCard() {
  safe((c) => {
    tone(c, { type: 'triangle', from: 880, to: 700, dur: 0.09, vol: 0.14 });
    tone(c, { type: 'triangle', from: 880, to: 700, start: 0.12, dur: 0.09, vol: 0.14 });
  });
}

export function playBlip() {
  safe((c) => tone(c, { type: 'square', from: 620, dur: 0.05, vol: 0.05 }));
}

// Torcida de fundo: ruído filtrado em volume baixo, que cresce nos lances de perigo e nos gols.
const CROWD_BASE = 0.035;

export function startCrowd() {
  if (crowd) return;
  try {
    const c = engine();
    if (!c) return;
    const src = c.createBufferSource();
    src.buffer = noiseBuffer(c);
    src.loop = true;
    const f = c.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = 520;
    f.Q.value = 0.5;
    const gain = c.createGain();
    gain.gain.value = CROWD_BASE;
    src.connect(f);
    f.connect(gain);
    gain.connect(master);
    src.start();
    crowd = { src, gain };
  } catch (e) {
    crowd = null;
  }
}

export function crowdSwell(amount, ms) {
  if (!crowd || !ctx) return;
  const now = ctx.currentTime;
  crowd.gain.gain.cancelScheduledValues(now);
  crowd.gain.gain.setTargetAtTime(CROWD_BASE + amount, now, 0.08);
  crowd.gain.gain.setTargetAtTime(CROWD_BASE, now + ms / 1000, 0.5);
}

export function stopCrowd() {
  if (!crowd) return;
  try {
    crowd.gain.gain.setTargetAtTime(0, ctx.currentTime, 0.1);
    crowd.src.stop(ctx.currentTime + 0.5);
  } catch (e) {
    // já parado
  }
  crowd = null;
}
